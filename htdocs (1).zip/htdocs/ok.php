<?php
echo "SURA OK — PHP works. Time: " . date('Y-m-d H:i:s');
