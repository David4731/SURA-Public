/* SURA RMS: les navigations internes sont gérées par ajax-navigation.js. */
(function () {
  'use strict';
  document.documentElement.classList.add('page-enter-active');
})();
