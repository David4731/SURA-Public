/**
 * SURA RMS — navigation AJAX sans rechargement complet.
 * Les pages PHP restent compatibles avec les liens directs, l'historique et les formulaires classiques.
 */
(function () {
  'use strict';
  if (window.__sulaAjaxNavigation) return;
  window.__sulaAjaxNavigation = true;

  var busy = false;
  var currentController = null;

  function shouldIgnoreLink(a, event) {
    if (!a || !a.href || event.defaultPrevented || event.button !== 0 ||
        event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return true;
    if (a.target && a.target !== '_self') return true;
    if (a.hasAttribute('download') || a.dataset.noAjax !== undefined) return true;
    if (a.hasAttribute('data-bs-toggle') || a.closest('[data-bs-toggle]')) return true;
    if (/^(mailto:|tel:|javascript:)/i.test(a.getAttribute('href') || '')) return true;
    if (a.getAttribute('href').charAt(0) === '#') return true;
    var u;
    try { u = new URL(a.href, location.href); } catch (_) { return true; }
    if (u.origin !== location.origin) return true;
    if (/\.(pdf|zip|csv|xlsx?|docx?|png|jpe?g|webp)(?:$|\\?)/i.test(u.pathname)) return true;
    if (/\/(logout|report_pdf|invoice_pdf)\.php$/i.test(u.pathname)) return true;
    return false;
  }

  function runScripts(container) {
    Array.prototype.slice.call(container.querySelectorAll('script')).forEach(function (oldScript) {
      var script = document.createElement('script');
      Array.prototype.slice.call(oldScript.attributes).forEach(function (attr) {
        script.setAttribute(attr.name, attr.value);
      });
      script.text = oldScript.textContent;
      oldScript.parentNode.replaceChild(script, oldScript);
    });
  }

  function updatePage(html, url, push) {
    var parsed = new DOMParser().parseFromString(html, 'text/html');
    if (!parsed || !parsed.body) throw new Error('Page invalide');
    // Les pages de connexion et les pages hors application doivent rester en navigation normale.
    var newMain = parsed.querySelector('main.sula-main');
    var oldMain = document.querySelector('main.sula-main');
    if (!newMain || !oldMain) {
      location.href = url;
      return;
    }
    var newTitle = parsed.querySelector('title');
    if (newTitle) document.title = newTitle.textContent;
    var newBody = parsed.body;
    // Remplacer la zone principale et mettre à jour les éléments de navigation qui changent de page.
    oldMain.innerHTML = newMain.innerHTML;
    var newSidebar = parsed.querySelector('#sulaSidebar');
    var oldSidebar = document.querySelector('#sulaSidebar');
    if (newSidebar && oldSidebar) oldSidebar.innerHTML = newSidebar.innerHTML;
    var newMobileNav = parsed.querySelector('#sulaMobileNav');
    var oldMobileNav = document.querySelector('#sulaMobileNav');
    if (newMobileNav && oldMobileNav) oldMobileNav.innerHTML = newMobileNav.innerHTML;
    document.querySelectorAll('.modal.ajax-transient').forEach(function (el) { el.remove(); });
    // Re-exécuter les scripts de la zone chargée; scripts externes déjà présents ne sont pas rechargés.
    runScripts(oldMain);
    document.dispatchEvent(new Event('DOMContentLoaded', { bubbles: true }));
    if (push) history.pushState({ sulaAjax: true }, '', url);
    document.documentElement.classList.remove('page-exit');
    document.documentElement.classList.add('page-enter-active');
    window.scrollTo({ top: 0, behavior: 'instant' });
    document.dispatchEvent(new CustomEvent('sula:page-loaded', { detail: { url: url } }));
    busy = false;
  }

  function navigate(url, push) {
    if (busy) return;
    busy = true;
    if (currentController) currentController.abort();
    currentController = window.AbortController ? new AbortController() : null;
    var options = {
      method: 'GET',
      headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'text/html' },
      credentials: 'same-origin'
    };
    if (currentController) options.signal = currentController.signal;
    document.documentElement.classList.add('sula-ajax-loading');
    fetch(url, options).then(function (response) {
      var type = response.headers.get('content-type') || '';
      if (!response.ok) throw new Error('HTTP ' + response.status);
      if (type.indexOf('text/html') === -1) {
        location.href = url;
        return null;
      }
      return response.text();
    }).then(function (html) {
      if (html !== null) updatePage(html, url, push);
    }).catch(function (err) {
      if (err.name !== 'AbortError') location.href = url;
      busy = false;
    }).finally(function () {
      document.documentElement.classList.remove('sula-ajax-loading');
    });
  }

  document.addEventListener('click', function (e) {
    var a = e.target.closest('a');
    if (shouldIgnoreLink(a, e)) return;
    e.preventDefault();
    navigate(a.href, true);
  });

  // Les formulaires GET (filtres/recherche) restent dans la page.
  document.addEventListener('submit', function (e) {
    var form = e.target;
    if (!(form instanceof HTMLFormElement) || e.defaultPrevented) return;
    if (form.dataset.noAjax !== undefined || form.target === '_blank' ||
        form.hasAttribute('download') || form.enctype === 'multipart/form-data') return;
    var method = (form.method || 'get').toUpperCase();
    var action = form.action || location.href;
    var url;
    try { url = new URL(action, location.href); } catch (_) { return; }
    if (url.origin !== location.origin) return;
    if (/\/(report_pdf|invoice_pdf)\.php$/i.test(url.pathname) ||
        /(?:export|download|print|pdf)/i.test(form.getAttribute('action') || '')) return;

    e.preventDefault();
    if (method === 'GET') {
      var params = new URLSearchParams(new FormData(form));
      params.forEach(function (_, key) { url.searchParams.delete(key); });
      new FormData(form).forEach(function (value, key) {
        if (typeof value === 'string') url.searchParams.append(key, value);
      });
      navigate(url.toString(), true);
      return;
    }

    if (busy) return;
    busy = true;
    document.documentElement.classList.add('sula-ajax-loading');
    var submitter = e.submitter;
    var data = new FormData(form);
    if (submitter && submitter.name) data.append(submitter.name, submitter.value);
    fetch(url.toString(), {
      method: method,
      body: data,
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'XMLHttpRequest', 'Accept': 'text/html' }
    }).then(function (response) {
      var type = response.headers.get('content-type') || '';
      if (!response.ok) throw new Error('HTTP ' + response.status);
      if (type.indexOf('text/html') === -1) { location.href = response.url; return null; }
      return response.text().then(function (html) { return { html: html, url: response.url }; });
    }).then(function (result) {
      if (result) updatePage(result.html, result.url, true);
    }).catch(function () { form.dataset.noAjax = 'true'; form.submit(); })
      .finally(function () { document.documentElement.classList.remove('sula-ajax-loading'); busy = false; });
  });

  window.addEventListener('popstate', function () {
    navigate(location.href, false);
  });
})();
