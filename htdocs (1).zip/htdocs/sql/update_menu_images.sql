-- Associer les images aux plats (après upload des fichiers dans /uploads/)
UPDATE menus SET image = 'bibimbap.jpg' WHERE name = 'Bibimbap';
UPDATE menus SET image = 'kimchi.jpg' WHERE name = 'Kimchi';
UPDATE menus SET image = 'tteokbokki.jpg' WHERE name = 'Tteokbokki';
UPDATE menus SET image = 'poulet.jpg' WHERE name LIKE 'Poulet%';
UPDATE menus SET image = 'jus.jpg' WHERE name LIKE 'Jus%';
UPDATE menus SET image = 'cocktail.jpg' WHERE name LIKE 'Soju%' OR name LIKE '%Cocktail%';
