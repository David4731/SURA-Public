-- SURA RMS - Fonctionnalités complètes
-- Exécuter ligne par ligne si une erreur "Duplicate column" apparaît

-- 1. Colonnes paiement détaillées sur orders
ALTER TABLE orders ADD COLUMN payment_method VARCHAR(50) NULL;
ALTER TABLE orders ADD COLUMN payer_name VARCHAR(100) NULL;
ALTER TABLE orders ADD COLUMN payer_phone VARCHAR(30) NULL;

-- 2. Colonnes paiement sur invoices
ALTER TABLE invoices ADD COLUMN payment_method VARCHAR(50) NULL;
ALTER TABLE invoices ADD COLUMN payer_name VARCHAR(100) NULL;
ALTER TABLE invoices ADD COLUMN payer_phone VARCHAR(30) NULL;

-- 3. stock_min
ALTER TABLE menus ADD COLUMN stock_min INT NOT NULL DEFAULT 5;

-- 4. Mouvements de stock
CREATE TABLE IF NOT EXISTS stock_movements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  menu_id INT NOT NULL,
  type ENUM('entree','sortie','ajustement','vente') NOT NULL,
  quantite INT NOT NULL,
  motif VARCHAR(255) NULL,
  user_id INT NULL,
  order_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. Dépenses
CREATE TABLE IF NOT EXISTS expenses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  category ENUM('achat_stock','salaires','loyer','utilities','autre') NOT NULL DEFAULT 'autre',
  expense_date DATE NOT NULL,
  notes TEXT NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Images menus
UPDATE menus SET image = 'bibimbap.jpg' WHERE name = 'Bibimbap';
UPDATE menus SET image = 'kimchi.jpg' WHERE name = 'Kimchi';
UPDATE menus SET image = 'tteokbokki.jpg' WHERE name = 'Tteokbokki';
UPDATE menus SET image = 'poulet.jpg' WHERE name LIKE 'Poulet%';
UPDATE menus SET image = 'jus.jpg' WHERE name LIKE 'Jus%';
UPDATE menus SET image = 'cocktail.jpg' WHERE name LIKE 'Soju%' OR name LIKE '%Cocktail%';
