-- Nouvelles catégories pour routage
-- food -> kitchen | bread/coffee -> bakery | drinks/alcohol -> bar

ALTER TABLE menus MODIFY category ENUM(
  'entree','plat','grill','pain','cafe','boisson','openbar','autre'
) NOT NULL DEFAULT 'plat';

-- Station cible sur chaque ligne de commande (optionnel, dérivable de la catégorie)
ALTER TABLE order_items ADD COLUMN station ENUM('kitchen','bakery','bar','counter') NULL;

-- Sample bakery items
INSERT INTO menus (name, description, category, price, stock, available) VALUES
('Pain maison', 'Pain frais du jour', 'pain', 2000, 40, 1),
('Café expresso', 'Café serré', 'cafe', 3000, 100, 1),
('Café au lait', 'Café crémeux', 'cafe', 4000, 80, 1)
ON DUPLICATE KEY UPDATE name=name;
