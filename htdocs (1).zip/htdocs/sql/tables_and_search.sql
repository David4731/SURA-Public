-- Tables / partitions du restaurant
CREATE TABLE IF NOT EXISTS restaurant_tables (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(30) NOT NULL UNIQUE,
  label VARCHAR(100) NOT NULL,
  zone ENUM('salle','terrasse','vip','bar','autre') NOT NULL DEFAULT 'salle',
  capacity INT NOT NULL DEFAULT 4,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  notes VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT IGNORE INTO restaurant_tables (code, label, zone, capacity) VALUES
('T1', 'Table 1', 'salle', 2),
('T2', 'Table 2', 'salle', 4),
('T3', 'Table 3', 'salle', 4),
('T4', 'Table 4', 'salle', 6),
('T5', 'Table 5', 'salle', 8),
('TR1', 'Terrasse 1', 'terrasse', 4),
('TR2', 'Terrasse 2', 'terrasse', 6),
('VIP1', 'Salon VIP', 'vip', 10),
('BAR1', 'Comptoir Bar', 'bar', 3);

-- Lier réservation à une table (optionnel)
ALTER TABLE reservations ADD COLUMN table_id INT NULL;
