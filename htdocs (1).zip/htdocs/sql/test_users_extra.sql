-- Comptes testeurs supplémentaires (mot de passe = password)
-- Hash bcrypt = même que les comptes démo ($2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi)
SET NAMES utf8mb4;

INSERT INTO users (name, email, password, role, status)
SELECT 'Serveur 2', 'serveur2@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'server', 1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM users WHERE email='serveur2@sula.mg');

INSERT INTO users (name, email, password, role, status)
SELECT 'Checker 2', 'checker2@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'checker', 1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM users WHERE email='checker2@sula.mg');

INSERT INTO users (name, email, password, role, status)
SELECT 'Cuisine 2', 'cuisine2@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'kitchen', 1
FROM DUAL WHERE NOT EXISTS (SELECT 1 FROM users WHERE email='cuisine2@sula.mg');

-- S'assurer que le comptable s'appelle Lalatiana
UPDATE users SET name='Lalatiana' WHERE email='comptable@sula.mg';
