-- SURA Luxury RMS — Chat, Notifications, Tables, Session jour
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS restaurant_tables (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  capacity INT NOT NULL DEFAULT 2,
  status ENUM('free','occupied','reserved') NOT NULL DEFAULT 'free',
  current_order_id INT NULL,
  guest_name VARCHAR(100) NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS chat_messages (
  id INT AUTO_INCREMENT PRIMARY KEY,
  channel VARCHAR(50) NOT NULL DEFAULT 'general',
  user_id INT NULL,
  sender_name VARCHAR(100) NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_channel_time (channel, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL COMMENT 'NULL = all staff',
  type VARCHAR(40) NOT NULL DEFAULT 'info',
  title VARCHAR(200) NOT NULL,
  body TEXT,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_read (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS service_sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  session_date DATE NOT NULL UNIQUE,
  status ENUM('open','closed') NOT NULL DEFAULT 'open',
  opened_by INT NULL,
  closed_by INT NULL,
  opened_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  closed_at TIMESTAMP NULL,
  notes TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed tables
INSERT IGNORE INTO restaurant_tables (id, name, capacity, status) VALUES
(1, 'T1', 2, 'free'),
(2, 'T2', 4, 'free'),
(3, 'T3', 2, 'free'),
(4, 'T4', 6, 'free'),
(5, 'T5', 2, 'free'),
(6, 'T6 VIP', 8, 'free'),
(7, 'T7', 4, 'free'),
(8, 'T8', 4, 'free'),
(9, 'Salon Privé', 12, 'free'),
(10, 'Terrasse 1', 4, 'free');

-- Open today's session if none
INSERT IGNORE INTO service_sessions (session_date, status)
VALUES (CURDATE(), 'open');
