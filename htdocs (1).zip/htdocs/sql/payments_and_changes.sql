-- ============================================================
-- SURA RMS — Paiements + demandes de modification/annulation
-- À exécuter une fois sur la base existante
-- ============================================================

SET NAMES utf8mb4;

-- Références de paiement (MVola / Orange / Airtel / Virement)
CREATE TABLE IF NOT EXISTS payment_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NULL,
  reservation_id INT NULL,
  method ENUM('mvola','orange_money','airtel_money','virement','cash','autre') NOT NULL DEFAULT 'mvola',
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  reference VARCHAR(40) NOT NULL,
  payer_name VARCHAR(100) NULL,
  payer_phone VARCHAR(30) NULL,
  status ENUM('pending','awaiting_proof','confirmed','failed','cancelled') NOT NULL DEFAULT 'pending',
  external_id VARCHAR(100) NULL COMMENT 'ID transaction API si disponible',
  proof_note TEXT NULL COMMENT 'Note / n° transaction client',
  confirmed_by INT NULL,
  confirmed_at DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uk_reference (reference),
  INDEX idx_order (order_id),
  INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Demandes de modification / annulation (Serveur ↔ Checker)
CREATE TABLE IF NOT EXISTS order_change_requests (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  requested_by INT NOT NULL,
  request_type ENUM('modify','cancel') NOT NULL,
  reason TEXT NULL,
  proposed_data TEXT NULL COMMENT 'JSON des changements proposés (items, table, etc.)',
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  reviewed_by INT NULL,
  reviewed_at DATETIME NULL,
  review_note TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_order_status (order_id, status),
  INDEX idx_pending (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Colonnes utiles sur orders si absentes
-- (MySQL < 8 n'a pas IF NOT EXISTS sur ADD COLUMN → on ignore les erreurs)
-- ALTER TABLE orders ADD COLUMN payment_ref VARCHAR(40) NULL AFTER payment_method;
-- ALTER TABLE orders ADD COLUMN last_change_request_id INT NULL;
