-- SURA reporting improvements
-- Execute once in the SURA database. Existing one-day events default to their event_date.
ALTER TABLE events ADD COLUMN end_date DATE NULL AFTER event_date;
UPDATE events SET end_date = event_date WHERE end_date IS NULL;
