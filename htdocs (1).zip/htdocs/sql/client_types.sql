-- Types de client (individu, famille, association, entreprise…)
SET NAMES utf8mb4;
ALTER TABLE orders ADD COLUMN client_type VARCHAR(40) NULL DEFAULT 'individu' AFTER client_name;
ALTER TABLE reservations ADD COLUMN client_type VARCHAR(40) NULL DEFAULT 'individu' AFTER client_name;
ALTER TABLE customers ADD COLUMN client_type VARCHAR(40) NULL DEFAULT 'individu' AFTER name;
ALTER TABLE customers ADD COLUMN organization VARCHAR(150) NULL AFTER client_type;
