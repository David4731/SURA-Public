-- SURA : file d'impression distante (à importer une seule fois)
CREATE TABLE IF NOT EXISTS print_jobs (
 id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
 job_uuid CHAR(36) NOT NULL UNIQUE,
 invoice_id INT NOT NULL,
 requested_by INT NULL,
 status ENUM('queued','processing','printed','error') NOT NULL DEFAULT 'queued',
 attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
 agent_id VARCHAR(80) NULL,
 error_message TEXT NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 started_at DATETIME NULL,
 completed_at DATETIME NULL,
 INDEX idx_print_status_created(status,created_at),
 INDEX idx_print_invoice(invoice_id),
 CONSTRAINT fk_print_invoice FOREIGN KEY(invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
