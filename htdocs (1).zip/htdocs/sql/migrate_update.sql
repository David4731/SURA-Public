-- ============================================================
-- SURA RMS - Migration SQL (pour base déjà existante)
-- Exécuter dans phpMyAdmin si vous avez déjà importé l'ancien schema
-- ============================================================

-- 1. Ajouter colonne image aux menus
ALTER TABLE menus 
  ADD COLUMN IF NOT EXISTS image VARCHAR(255) NULL AFTER available;

-- 2. Ajouter date/heure de livraison aux commandes
ALTER TABLE orders 
  ADD COLUMN IF NOT EXISTS delivery_date DATETIME NULL AFTER client_address;

-- Note: created_at existe déjà (TIMESTAMP) → heure de commande disponible
-- Si votre MySQL ne supporte pas IF NOT EXISTS sur ADD COLUMN, utilisez :

-- Version alternative (sans IF NOT EXISTS) :
-- ALTER TABLE menus ADD COLUMN image VARCHAR(255) NULL AFTER available;
-- ALTER TABLE orders ADD COLUMN delivery_date DATETIME NULL AFTER client_address;

-- 3. Vérification
-- DESCRIBE menus;
-- DESCRIBE orders;
