-- ============================================================
-- SURA Luxury RMS — Installation SQL COMPLÈTE (base neuve)
-- MySQL 5.7+ / MariaDB / InfinityFree
-- Importer ce fichier UNE SEULE FOIS sur une base vide
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- -------------------- USERS --------------------
DROP TABLE IF EXISTS stock_movements;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS invoices;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS chat_messages;
DROP TABLE IF EXISTS service_sessions;
DROP TABLE IF EXISTS restaurant_tables;
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS dish_proposals;
DROP TABLE IF EXISTS events;
DROP TABLE IF EXISTS expenses;
DROP TABLE IF EXISTS client_feedback;
DROP TABLE IF EXISTS menus;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','stock_manager','checker','accountant','server','kitchen') NOT NULL DEFAULT 'server',
  status TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------- MENUS --------------------
CREATE TABLE menus (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  category ENUM('entree','plat','grill','pain','cafe','boisson','openbar','autre') NOT NULL DEFAULT 'plat',
  price DECIMAL(12,2) NOT NULL DEFAULT 0,
  stock INT NOT NULL DEFAULT 0,
  stock_min INT NOT NULL DEFAULT 5,
  available TINYINT(1) NOT NULL DEFAULT 1,
  image VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------- ORDERS --------------------
CREATE TABLE orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  order_type ENUM('dine_in','delivery') NOT NULL DEFAULT 'dine_in',
  table_no VARCHAR(20) NULL,
  client_name VARCHAR(100) NULL,
  client_phone VARCHAR(30) NULL,
  client_address TEXT NULL,
  delivery_date DATETIME NULL,
  total DECIMAL(12,2) NOT NULL DEFAULT 0,
  status ENUM('pending','approved','preparing','ready','completed','cancelled') NOT NULL DEFAULT 'pending',
  payment_status ENUM('not_paid','partial','paid') NOT NULL DEFAULT 'not_paid',
  payment_method VARCHAR(50) NULL,
  payer_name VARCHAR(100) NULL,
  payer_phone VARCHAR(30) NULL,
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  approved_at DATETIME NULL,
  completed_at DATETIME NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  menu_id INT NULL,
  item_name VARCHAR(150) NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  unit_price DECIMAL(12,2) NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL,
  station ENUM('kitchen','bakery','bar','counter') NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (menu_id) REFERENCES menus(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------- INVOICES --------------------
CREATE TABLE invoices (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  invoice_number VARCHAR(50) NOT NULL UNIQUE,
  total DECIMAL(12,2) NOT NULL,
  payment_method VARCHAR(50) NULL,
  payment_status ENUM('not_paid','partial','paid') NOT NULL DEFAULT 'not_paid',
  payer_name VARCHAR(100) NULL,
  payer_phone VARCHAR(30) NULL,
  paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------- RESERVATIONS --------------------
CREATE TABLE reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_name VARCHAR(100) NOT NULL,
  client_phone VARCHAR(30) NULL,
  guests INT NOT NULL DEFAULT 2,
  reservation_date DATE NOT NULL,
  reservation_time TIME NOT NULL,
  table_partition VARCHAR(50) NULL,
  table_id INT NULL,
  payment_status ENUM('not_paid','partial','paid') NOT NULL DEFAULT 'not_paid',
  paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  status ENUM('pending','confirmed','cancelled','completed') NOT NULL DEFAULT 'pending',
  notes TEXT NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------- DISH PROPOSALS --------------------
CREATE TABLE dish_proposals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  proposed_by INT NULL,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  suggested_price DECIMAL(12,2) NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  reviewed_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (proposed_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------- EVENTS --------------------
CREATE TABLE events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  event_date DATE NOT NULL,
  capacity INT NULL,
  package_desc TEXT,
  deposit_status ENUM('not_paid','partial','paid') NOT NULL DEFAULT 'not_paid',
  status ENUM('planned','confirmed','done','cancelled') NOT NULL DEFAULT 'planned',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------- EXPENSES --------------------
CREATE TABLE expenses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  category VARCHAR(80) NULL,
  expense_date DATE NOT NULL,
  notes TEXT NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------- STOCK MOVEMENTS --------------------
CREATE TABLE stock_movements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  menu_id INT NOT NULL,
  type VARCHAR(40) NOT NULL DEFAULT 'ajustement',
  quantite INT NOT NULL,
  motif VARCHAR(255) NULL,
  user_id INT NULL,
  order_id INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (menu_id) REFERENCES menus(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------- TABLES RESTAURANT --------------------
CREATE TABLE restaurant_tables (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(50) NULL,
  code VARCHAR(30) NOT NULL UNIQUE,
  label VARCHAR(100) NOT NULL,
  zone ENUM('salle','terrasse','vip','bar','autre') NOT NULL DEFAULT 'salle',
  capacity INT NOT NULL DEFAULT 4,
  space_type ENUM('table','salle','partition') NOT NULL DEFAULT 'table',
  status ENUM('free','occupied','reserved') NOT NULL DEFAULT 'free',
  current_order_id INT NULL,
  guest_name VARCHAR(100) NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  notes VARCHAR(255) NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------- NOTIFICATIONS --------------------
CREATE TABLE notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL COMMENT 'NULL = toute l equipe',
  type VARCHAR(40) NOT NULL DEFAULT 'info',
  title VARCHAR(200) NOT NULL,
  body TEXT,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_user_read (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------- SESSION DE SERVICE (1 jour) --------------------
CREATE TABLE service_sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  session_date DATE NOT NULL UNIQUE,
  status ENUM('open','closed') NOT NULL DEFAULT 'open',
  opened_by INT NULL,
  closed_by INT NULL,
  opened_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  closed_at TIMESTAMP NULL,
  notes TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- -------------------- AVIS CLIENTS --------------------
CREATE TABLE client_feedback (
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_name VARCHAR(100) NULL,
  rating TINYINT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- DONNEES INITIALES
-- Mot de passe pour TOUS les comptes : password
-- Hash bcrypt : $2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi
-- ============================================================

INSERT INTO users (id, name, email, password, role) VALUES
(1, 'Administrateur', 'admin@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
(2, 'Checker SURA', 'checker@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'checker'),
(3, 'Stock Manager', 'stock@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'stock_manager'),
(4, 'Comptable', 'comptable@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'accountant'),
(5, 'Serveur', 'serveur@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'server'),
(6, 'Cuisine', 'cuisine@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'kitchen');

-- (replaced below)


INSERT INTO service_sessions (session_date, status, opened_by)
VALUES (CURDATE(), 'open', 1);

INSERT INTO menus (name, description, category, price, stock, stock_min, available, image) VALUES
('Bibimbap', 'Riz melange coreen aux legumes', 'plat', 15000, 30, 5, 1, 'bibimbap.jpg'),
('Kimchi', 'Chou fermente epice', 'entree', 5000, 40, 5, 1, 'kimchi.jpg'),
('Tteokbokki', 'Gateaux de riz sauce gochujang', 'plat', 12000, 25, 5, 1, 'tteokbokki.jpg'),
('Poulet grille', 'Poulet marine style malgache', 'grill', 18000, 20, 5, 1, 'poulet.jpg'),
('Jus de fruits', 'Jus frais du jour', 'boisson', 4000, 50, 10, 1, 'jus.jpg'),
('Cocktail Soju', 'Cocktail signature', 'openbar', 10000, 30, 5, 1, 'cocktail.jpg'),
('Pain maison', 'Pain frais du jour', 'pain', 2000, 40, 10, 1, NULL),
('Cafe expresso', 'Cafe serre', 'cafe', 3000, 100, 20, 1, NULL),
('Cafe au lait', 'Cafe cremeux', 'cafe', 4000, 80, 15, 1, NULL);

INSERT INTO notifications (user_id, type, title, body) VALUES
(NULL, 'info', 'Bienvenue sur SURA Luxury RMS', 'Systeme pret. Session du jour ouverte.');

-- Fin


-- Espaces SURA: 2 salles + terrasse + 50 tables
DELETE FROM restaurant_tables;
INSERT INTO restaurant_tables (code, label, name, zone, space_type, capacity, status) VALUES
('SALLE1', 'Salle 1 (Restaurant)', 'Salle 1', 'salle', 'salle', 25, 'free'),
('SALLE2', 'Salle 2 (Restaurant)', 'Salle 2', 'salle', 'salle', 25, 'free'),
('TERRASSE', 'Terrasse — Open-Bar & Grillades', 'Terrasse', 'terrasse', 'salle', 50, 'free');
INSERT INTO restaurant_tables (code, label, name, zone, space_type, capacity, status) VALUES
('T1', 'Table 1 — Salle 1', 'T1', 'salle', 'table', 6, 'free'),
('T2', 'Table 2 — Salle 1', 'T2', 'salle', 'table', 6, 'free'),
('T3', 'Table 3 — Salle 1', 'T3', 'salle', 'table', 6, 'free'),
('T4', 'Table 4 — Salle 1', 'T4', 'salle', 'table', 6, 'free'),
('T5', 'Table 5 — Salle 1', 'T5', 'salle', 'table', 6, 'free'),
('T6', 'Table 6 — Salle 1', 'T6', 'salle', 'table', 6, 'free'),
('T7', 'Table 7 — Salle 1', 'T7', 'salle', 'table', 6, 'free'),
('T8', 'Table 8 — Salle 1', 'T8', 'salle', 'table', 6, 'free'),
('T9', 'Table 9 — Salle 1', 'T9', 'salle', 'table', 6, 'free'),
('T10', 'Table 10 — Salle 1', 'T10', 'salle', 'table', 6, 'free'),
('T11', 'Table 11 — Salle 1', 'T11', 'salle', 'table', 6, 'free'),
('T12', 'Table 12 — Salle 1', 'T12', 'salle', 'table', 6, 'free'),
('T13', 'Table 13 — Salle 1', 'T13', 'salle', 'table', 6, 'free'),
('T14', 'Table 14 — Salle 1', 'T14', 'salle', 'table', 6, 'free'),
('T15', 'Table 15 — Salle 1', 'T15', 'salle', 'table', 6, 'free'),
('T16', 'Table 16 — Salle 1', 'T16', 'salle', 'table', 6, 'free'),
('T17', 'Table 17 — Salle 1', 'T17', 'salle', 'table', 6, 'free'),
('T18', 'Table 18 — Salle 1', 'T18', 'salle', 'table', 6, 'free'),
('T19', 'Table 19 — Salle 1', 'T19', 'salle', 'table', 6, 'free'),
('T20', 'Table 20 — Salle 1', 'T20', 'salle', 'table', 6, 'free'),
('T21', 'Table 21 — Salle 2', 'T21', 'salle', 'table', 6, 'free'),
('T22', 'Table 22 — Salle 2', 'T22', 'salle', 'table', 6, 'free'),
('T23', 'Table 23 — Salle 2', 'T23', 'salle', 'table', 6, 'free'),
('T24', 'Table 24 — Salle 2', 'T24', 'salle', 'table', 6, 'free'),
('T25', 'Table 25 — Salle 2', 'T25', 'salle', 'table', 6, 'free'),
('T26', 'Table 26 — Salle 2', 'T26', 'salle', 'table', 6, 'free'),
('T27', 'Table 27 — Salle 2', 'T27', 'salle', 'table', 6, 'free'),
('T28', 'Table 28 — Salle 2', 'T28', 'salle', 'table', 6, 'free'),
('T29', 'Table 29 — Salle 2', 'T29', 'salle', 'table', 6, 'free'),
('T30', 'Table 30 — Salle 2', 'T30', 'salle', 'table', 6, 'free'),
('T31', 'Table 31 — Salle 2', 'T31', 'salle', 'table', 6, 'free'),
('T32', 'Table 32 — Salle 2', 'T32', 'salle', 'table', 6, 'free'),
('T33', 'Table 33 — Salle 2', 'T33', 'salle', 'table', 6, 'free'),
('T34', 'Table 34 — Salle 2', 'T34', 'salle', 'table', 6, 'free'),
('T35', 'Table 35 — Salle 2', 'T35', 'salle', 'table', 6, 'free'),
('T36', 'Table 36 — Terrasse', 'T36', 'terrasse', 'table', 6, 'free'),
('T37', 'Table 37 — Terrasse', 'T37', 'terrasse', 'table', 6, 'free'),
('T38', 'Table 38 — Terrasse', 'T38', 'terrasse', 'table', 6, 'free'),
('T39', 'Table 39 — Terrasse', 'T39', 'terrasse', 'table', 6, 'free'),
('T40', 'Table 40 — Terrasse', 'T40', 'terrasse', 'table', 6, 'free'),
('T41', 'Table 41 — Terrasse', 'T41', 'terrasse', 'table', 6, 'free'),
('T42', 'Table 42 — Terrasse', 'T42', 'terrasse', 'table', 6, 'free'),
('T43', 'Table 43 — Terrasse', 'T43', 'terrasse', 'table', 6, 'free'),
('T44', 'Table 44 — Terrasse', 'T44', 'terrasse', 'table', 6, 'free'),
('T45', 'Table 45 — Terrasse', 'T45', 'terrasse', 'table', 6, 'free'),
('T46', 'Table 46 — Terrasse', 'T46', 'terrasse', 'table', 6, 'free'),
('T47', 'Table 47 — Terrasse', 'T47', 'terrasse', 'table', 6, 'free'),
('T48', 'Table 48 — Terrasse', 'T48', 'terrasse', 'table', 6, 'free'),
('T49', 'Table 49 — Terrasse', 'T49', 'terrasse', 'table', 6, 'free'),
('T50', 'Table 50 — Terrasse', 'T50', 'terrasse', 'table', 6, 'free'),
('P1-S1', 'Partition Salle 1 · T1-T4', 'Partition S1-A', 'salle', 'partition', 24, 'free'),
('P2-S1', 'Partition Salle 1 · T5-T8', 'Partition S1-B', 'salle', 'partition', 24, 'free'),
('P3-S1', 'Partition Salle 1 · T9-T12', 'Partition S1-C', 'salle', 'partition', 24, 'free'),
('P1-S2', 'Partition Salle 2 · T21-T24', 'Partition S2-A', 'salle', 'partition', 24, 'free'),
('P2-S2', 'Partition Salle 2 · T25-T28', 'Partition S2-B', 'salle', 'partition', 24, 'free'),
('P1-TR', 'Partition Terrasse · T36-T40', 'Partition Terrasse A', 'terrasse', 'partition', 30, 'free'),
('P2-TR', 'Partition Terrasse · T41-T45', 'Partition Terrasse B', 'terrasse', 'partition', 30, 'free');
