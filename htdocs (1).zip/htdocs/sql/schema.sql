-- SURA Restaurant Management System - Database Schema
-- Compatible MySQL 5.7+ / MariaDB (InfinityFree)

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','stock_manager','checker','accountant','server','kitchen') NOT NULL DEFAULT 'server',
  status TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS menus (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  category ENUM('entree','plat','grill','boisson','openbar','autre') NOT NULL DEFAULT 'plat',
  price DECIMAL(12,2) NOT NULL DEFAULT 0,
  stock INT NOT NULL DEFAULT 0,
  available TINYINT(1) NOT NULL DEFAULT 1,
  image VARCHAR(255) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS orders (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  order_type ENUM('dine_in','delivery') NOT NULL DEFAULT 'dine_in',
  table_no VARCHAR(20) NULL,
  client_name VARCHAR(100) NULL,
  client_phone VARCHAR(30) NULL,
  client_address TEXT NULL,
  delivery_date DATETIME NULL,
  total DECIMAL(12,2) NOT NULL DEFAULT 0,
  status ENUM('pending','approved','preparing','ready','completed','cancelled') NOT NULL DEFAULT 'pending',
  payment_status ENUM('not_paid','partial','paid') NOT NULL DEFAULT 'not_paid',
  notes TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  approved_at DATETIME NULL,
  completed_at DATETIME NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS order_items (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  menu_id INT NULL,
  item_name VARCHAR(150) NOT NULL,
  quantity INT NOT NULL DEFAULT 1,
  unit_price DECIMAL(12,2) NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
  FOREIGN KEY (menu_id) REFERENCES menus(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS invoices (
  id INT AUTO_INCREMENT PRIMARY KEY,
  order_id INT NOT NULL,
  invoice_number VARCHAR(50) NOT NULL UNIQUE,
  total DECIMAL(12,2) NOT NULL,
  payment_method VARCHAR(50) NULL,
  payment_status ENUM('not_paid','partial','paid') NOT NULL DEFAULT 'not_paid',
  paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS reservations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  client_name VARCHAR(100) NOT NULL,
  client_phone VARCHAR(30) NULL,
  guests INT NOT NULL DEFAULT 2,
  reservation_date DATE NOT NULL,
  reservation_time TIME NOT NULL,
  table_partition VARCHAR(50) NULL,
  payment_status ENUM('not_paid','partial','paid') NOT NULL DEFAULT 'not_paid',
  paid_amount DECIMAL(12,2) NOT NULL DEFAULT 0,
  status ENUM('pending','confirmed','cancelled','completed') NOT NULL DEFAULT 'pending',
  notes TEXT NULL,
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS dish_proposals (
  id INT AUTO_INCREMENT PRIMARY KEY,
  proposed_by INT NULL,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  suggested_price DECIMAL(12,2) NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  reviewed_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (proposed_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (reviewed_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200) NOT NULL,
  event_date DATE NOT NULL,
  capacity INT NULL,
  package_desc TEXT,
  deposit_status ENUM('not_paid','partial','paid') NOT NULL DEFAULT 'not_paid',
  status ENUM('planned','confirmed','done','cancelled') NOT NULL DEFAULT 'planned',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default users (password = "password")
INSERT INTO users (name, email, password, role) VALUES
('Administrateur', 'admin@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin'),
('Checker SURA', 'checker@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'checker'),
('Stock Manager', 'stock@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'stock_manager'),
('Comptable', 'comptable@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'accountant'),
('Serveur 1', 'serveur@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'server'),
('Cuisine', 'cuisine@sula.mg', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'kitchen');

-- Sample menu
INSERT INTO menus (name, description, category, price, stock, available) VALUES
('Bibimbap', 'Bol de riz coréen garni', 'plat', 25000, 50, 1),
('Kimchi', 'Chou fermenté épicé', 'entree', 8000, 30, 1),
('Tteokbokki', 'Gâteaux de riz épicés', 'plat', 12000, 40, 1),
('Poulet grillé', 'Grillade SURA', 'grill', 18000, 25, 1),
('Jus naturel', 'Boisson fraîche', 'boisson', 5000, 100, 1),
('Soju / Cocktail', 'Open-bar', 'openbar', 15000, 60, 1);

SET FOREIGN_KEY_CHECKS = 1;
