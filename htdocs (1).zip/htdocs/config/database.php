<?php
/**
 * SULA RMS - Database configuration
 * InfinityFree: use the MySQL credentials from your control panel
 */
define('DB_HOST', 'sql312.infinityfree.com');
define('DB_NAME', 'if0_43273418_SULA_FinalTest');
define('DB_USER', 'if0_43273418');       // <-- vérifie le vrai username dans le panneau
define('DB_PASS', 'SULAkm100');      // <-- mets ton vrai mot de passe MySQL
define('DB_CHARSET', 'utf8mb4');

function getPDO() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => true,  // safer on free hosts
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            // Show clear error instead of blank 500
            http_response_code(500);
            die('<h2>Erreur base de données</h2><p>Vérifiez config/database.php</p><pre>' . htmlspecialchars($e->getMessage()) . '</pre>');
        }
    }
    return $pdo;
}
