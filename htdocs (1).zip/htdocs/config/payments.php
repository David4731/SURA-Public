<?php
/**
 * SURA RMS — Configuration des paiements mobiles & virement
 * Madagascar : MVola (Telma), Orange Money, Airtel Money
 *
 * Pour une intégration API officielle (merchant) :
 * - MVola  : https://www.mvola.mg / API Merchant Telma
 * - Orange : Orange Money Merchant API
 * - Airtel : Airtel Money Merchant
 * Renseignez les clés ci-dessous quand vous aurez un compte marchand.
 * En attendant, le flux "référence de paiement + confirmation manuelle" fonctionne.
 */

return [
    // Numéros marchands affichés aux clients
    'merchant' => [
        'mvola' => [
            'label'   => 'MVola',
            'number'  => '038 24 541 74',
            'number_raw' => '0382454174',
            'color'   => 'mvola',
            'hint'    => 'Envoyez le montant puis indiquez la référence SURA-XXXX',
        ],
        'orange_money' => [
            'label'   => 'Orange Money',
            'number'  => '032 00 000 00', // à remplacer par le vrai numéro SURA
            'number_raw' => '0320000000',
            'color'   => 'orange',
            'hint'    => 'Transfert Orange Money vers ce numéro',
        ],
        'airtel_money' => [
            'label'   => 'Airtel Money',
            'number'  => '033 00 000 00', // à remplacer
            'number_raw' => '0330000000',
            'color'   => 'airtel',
            'hint'    => 'Transfert Airtel Money vers ce numéro',
        ],
        'virement' => [
            'label'   => 'Virement bancaire',
            'bank'    => 'BOA / BNI / MCB',
            'iban'    => '', // RIB / compte à compléter
            'account_name' => 'SURA Restaurant',
            'hint'    => 'Virement avec libellé = référence SURA-XXXX',
        ],
        'cash' => [
            'label'   => 'Cash',
            'hint'    => 'Paiement à la livraison / au restaurant',
        ],
    ],

    // Clés API (laisser vide = mode manuel / référence)
    'api' => [
        'mvola' => [
            'enabled'     => false,
            'consumer_key'    => '',
            'consumer_secret' => '',
            'merchant_number' => '0382454174',
            'callback_url'    => '', // https://votre-domaine/ajax/payment_callback.php
        ],
        'orange_money' => [
            'enabled' => false,
            'api_key' => '',
            'merchant_id' => '',
        ],
        'airtel_money' => [
            'enabled' => false,
            'api_key' => '',
            'merchant_id' => '',
        ],
    ],

    // Préfixe des références de paiement générées
    'ref_prefix' => 'SURA',
];
