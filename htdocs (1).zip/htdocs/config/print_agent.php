<?php
// Secret d'authentification du PC d'impression. Garder ce fichier hors dépôt public.
define('SURA_PRINT_AGENT_TOKEN', '2KSVNMpC2tQRJ8ZRH7BL9d4t0X6oeFjqqrnTANvuxBCSGcai5JJUMg');
