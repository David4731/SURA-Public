<?php
/**
 * Public JSON: free tables/salles/partitions for a given date (+ optional time)
 */
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/database.php';

$date = $_GET['date'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    $date = date('Y-m-d');
}

try {
    $pdo = getPDO();
    $spaces = [];
    try {
        $spaces = $pdo->query("SELECT id, code, label, name, zone, space_type, capacity, status FROM restaurant_tables WHERE is_active=1 ORDER BY space_type, zone, code")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $spaces = $pdo->query("SELECT id, code, label, name, zone, capacity, status FROM restaurant_tables ORDER BY code")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($spaces as &$s) {
            if (!isset($s['space_type'])) $s['space_type'] = 'table';
        }
        unset($s);
    }

    // Codes taken by confirmed or pending reservations that day
    $taken = [];
    try {
        $st = $pdo->prepare("SELECT space_codes, table_partition, reserve_type FROM reservations WHERE reservation_date=? AND status IN ('pending','confirmed')");
        $st->execute([$date]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $csv = $r['space_codes'] ?? '';
            if ($csv === '' && !empty($r['table_partition'])) {
                // try extract code-like tokens
                $csv = $r['table_partition'];
            }
            if (($r['reserve_type'] ?? '') === 'all_salles' || strpos($csv, 'ALL_SALLES') !== false) {
                $taken['ALL_SALLES'] = true;
                continue;
            }
            foreach (preg_split('/[,;]+/', $csv) as $c) {
                $c = trim($c);
                if ($c !== '') $taken[$c] = true;
                // also mark first token before space
                if (preg_match('/\b(T\d+|SALLE\d+|TERRASSE|P[\w\-]+)\b/i', $c, $m)) {
                    $taken[strtoupper($m[1])] = true;
                }
            }
        }
    } catch (Exception $e) {}

    $allBlocked = !empty($taken['ALL_SALLES']);
    $free = ['salle' => [], 'table' => [], 'partition' => []];
    foreach ($spaces as $s) {
        $code = $s['code'];
        $type = $s['space_type'] ?? 'table';
        if (!isset($free[$type])) $free[$type] = [];
        $isTaken = $allBlocked || !empty($taken[$code]) || !empty($taken[strtoupper($code)]);
        // also if currently reserved/occupied status and date is today
        if ($date === date('Y-m-d') && in_array($s['status'] ?? 'free', ['reserved', 'occupied'], true)) {
            $isTaken = true;
        }
        if ($isTaken) continue;
        $free[$type][] = [
            'code' => $code,
            'label' => $s['label'] ?? $s['name'] ?? $code,
            'zone' => $s['zone'] ?? '',
            'capacity' => (int)($s['capacity'] ?? 6),
            'space_type' => $type,
        ];
    }

    echo json_encode([
        'ok' => true,
        'date' => $date,
        'free' => $free,
        'counts' => [
            'salle' => count($free['salle']),
            'table' => count($free['table']),
            'partition' => count($free['partition']),
        ],
    ], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage()]);
}
