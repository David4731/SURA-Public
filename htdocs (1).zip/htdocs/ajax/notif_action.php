<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'auth']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'method']);
    exit;
}

$pdo = getPDO();
$user = currentUser();
$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;
$action = $input['action'] ?? '';
$id = (int)($input['id'] ?? 0);

try {
    if ($action === 'read' && $id > 0) {
        // Mark one as read (own or broadcast)
        $st = $pdo->prepare(
            "UPDATE notifications SET is_read=1
             WHERE id=? AND (user_id IS NULL OR user_id=?)"
        );
        $st->execute([$id, $user['id']]);
        echo json_encode(['ok' => true]);
        exit;
    }

    if ($action === 'read_all') {
        $st = $pdo->prepare(
            "UPDATE notifications SET is_read=1
             WHERE (user_id IS NULL OR user_id=?) AND is_read=0"
        );
        $st->execute([$user['id']]);
        echo json_encode(['ok' => true]);
        exit;
    }

    if ($action === 'delete' && $id > 0) {
        // Delete only if owned or broadcast (staff can delete broadcast)
        $st = $pdo->prepare(
            "DELETE FROM notifications WHERE id=? AND (user_id IS NULL OR user_id=?)"
        );
        $st->execute([$id, $user['id']]);
        echo json_encode(['ok' => true]);
        exit;
    }

    echo json_encode(['error' => 'invalid_action']);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
