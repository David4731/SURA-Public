<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin', 'checker']);

$pdo = getPDO();
$user = currentUser();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'method']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Close today's session
    $pdo->prepare("UPDATE service_sessions SET status='closed', closed_by=?, closed_at=NOW() WHERE session_date=CURDATE() AND status='open'")
        ->execute([$user['id']]);

    // Free all tables
    $pdo->exec("UPDATE restaurant_tables SET status='free', current_order_id=NULL, guest_name=NULL");

    // Open new session for today (or tomorrow if already closed today)
    $pdo->prepare("INSERT INTO service_sessions (session_date, status, opened_by) VALUES (CURDATE(), 'open', ?)
                   ON DUPLICATE KEY UPDATE status='open', opened_by=?, opened_at=NOW(), closed_at=NULL, closed_by=NULL")
        ->execute([$user['id'], $user['id']]);

    // Notification
    $pdo->prepare("INSERT INTO notifications (user_id, type, title, body) VALUES (NULL, 'session', 'Session réinitialisée', ?)")
        ->execute(['Nouvelle session de service ouverte par ' . $user['name']]);

    $pdo->commit();
    echo json_encode(['ok' => true, 'message' => 'Session du jour réinitialisée. Tables libérées.']);
} catch (Exception $e) {
    if ($pdo->inTransaction()) { try { $pdo->rollBack(); } catch (Exception $rb) {} }
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
