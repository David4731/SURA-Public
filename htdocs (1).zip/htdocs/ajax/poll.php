<?php
/**
 * Real-time poll endpoint — returns JSON updates (orders, tables, chat, notifs)
 */
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

if (!isLoggedIn()) {
    http_response_code(401);
    echo json_encode(['error' => 'auth']);
    exit;
}

$pdo = getPDO();
$user = currentUser();
$since = isset($_GET['since']) ? (int)$_GET['since'] : 0;
$channel = preg_replace('/[^a-zA-Z0-9_-]/', '', $_GET['channel'] ?? 'general');

$out = [
    'ts' => time(),
    'orders' => [],
    'tables' => [],
    'notifications' => [],
    'unread' => 0,
    'session' => null,
];

try {
    // Recent orders (last 30)
    $out['orders'] = $pdo->query(
        "SELECT id, table_no, client_name, total, status, payment_status, order_type, created_at
         FROM orders ORDER BY id DESC LIMIT 30"
    )->fetchAll(PDO::FETCH_ASSOC);

    // Tables status
    try {
        $out['tables'] = $pdo->query("SELECT * FROM restaurant_tables ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $out['tables'] = [];
    }

    // Chat messages since
    try {
        if ($since > 0) {
            $st = $pdo->prepare("SELECT id, channel, sender_name, message, created_at FROM chat_messages WHERE channel=? AND id>? ORDER BY id ASC LIMIT 50");
            $st->execute([$channel, $since]);
        } else {
            $st = $pdo->prepare("SELECT id, channel, sender_name, message, created_at FROM chat_messages WHERE channel=? ORDER BY id DESC LIMIT 40");
            $st->execute([$channel]);
        }
        $msgs = $st->fetchAll(PDO::FETCH_ASSOC);
        if ($since === 0) $msgs = array_reverse($msgs);
        $out['chat'] = $msgs;
    } catch (Exception $e) {
        $out['chat'] = [];
    }

    // Notifications
    try {
        $st = $pdo->prepare(
            "SELECT id, type, title, body, is_read, created_at FROM notifications
             WHERE (user_id IS NULL OR user_id=?) ORDER BY id DESC LIMIT 30"
        );
        $st->execute([$user['id']]);
        $out['notifications'] = $st->fetchAll(PDO::FETCH_ASSOC);
        $st2 = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE (user_id IS NULL OR user_id=?) AND is_read=0");
        $st2->execute([$user['id']]);
        $out['unread'] = (int)$st2->fetchColumn();
    } catch (Exception $e) {
        $out['notifications'] = [];
    }

    // Service session today
    try {
        $st = $pdo->query("SELECT * FROM service_sessions WHERE session_date=CURDATE() LIMIT 1");
        $out['session'] = $st->fetch(PDO::FETCH_ASSOC) ?: null;
    } catch (Exception $e) {
        $out['session'] = null;
    }
} catch (Exception $e) {
    $out['error'] = $e->getMessage();
}


    // Notify checker: reservations whose time has arrived (once)
    try {
        $due = $pdo->query("SELECT * FROM reservations WHERE status='confirmed'
          AND reservation_date = CURDATE()
          AND reservation_time <= CURTIME()
          AND ADDTIME(reservation_time, '00:30:00') >= CURTIME()")->fetchAll();
        foreach ($due as $r) {
            $title = 'Reservation en cours #' . $r['id'];
            $chk = $pdo->prepare("SELECT id FROM notifications WHERE title=? AND DATE(created_at)=CURDATE() LIMIT 1");
            $chk->execute([$title]);
            if (!$chk->fetch()) {
                $pdo->prepare("INSERT INTO notifications (user_id, type, title, body, is_read) VALUES (NULL,'reservation',?,?,0)")
                    ->execute([
                        $title,
                        ($r['client_name'] ?? '') . ' — ' . ($r['table_partition'] ?? $r['space_codes'] ?? '') .
                        ' — ' . $r['reservation_date'] . ' ' . substr($r['reservation_time'], 0, 5) .
                        ' — Le checker peut liberer apres service'
                    ]);
                // mark spaces reserved NOW
                $csv = $r['space_codes'] ?? '';
                if ($csv) {
                    foreach (explode(',', $csv) as $c) {
                        $c = trim($c);
                        if ($c === '' || $c === 'ALL_SALLES') continue;
                        $pdo->prepare("UPDATE restaurant_tables SET status='reserved', guest_name=? WHERE code=?")->execute([$r['client_name'] ?? '', $c]);
                    }
                }
            }
        }
    } catch (Exception $e) {}


echo json_encode($out, JSON_UNESCAPED_UNICODE);
