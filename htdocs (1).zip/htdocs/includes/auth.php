<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/lang.php';

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: /index.php');
        exit;
    }
}

function requireRole($roles) {
    requireLogin();
    if (!is_array($roles)) $roles = [$roles];
    if (!in_array($_SESSION['role'], $roles)) {
        header('Location: /pages/dashboard.php?error=access');
        exit;
    }
}

function currentUser() {
    return [
        'id'   => $_SESSION['user_id'] ?? null,
        'name' => $_SESSION['name'] ?? '',
        'role' => $_SESSION['role'] ?? '',
        'email'=> $_SESSION['email'] ?? '',
    ];
}

function roleLabel($role) {
    $map = [
        'admin' => t('admin'),
        'stock_manager' => t('stock_manager'),
        'checker' => t('checker'),
        'accountant' => t('accountant'),
        'server' => t('server'),
        'kitchen' => t('kitchen_role'),
    ];
    return $map[$role] ?? $role;
}
