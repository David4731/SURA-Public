<?php
/**
 * Routage des postes SURA
 * Food -> kitchen | Bread & Coffee -> bakery | Drinks & Alcohol -> bar
 */
function stationForCategory(string $category): string {
    $map = [
        'entree'  => 'kitchen',
        'plat'    => 'kitchen',
        'grill'   => 'kitchen',
        'autre'   => 'kitchen',
        'pain'    => 'bakery',
        'cafe'    => 'bakery',
        'boisson' => 'bar',
        'openbar' => 'bar',
    ];
    return $map[$category] ?? 'kitchen';
}

function stationLabel(string $station): string {
    $labels = [
        'kitchen' => 'Cuisine',
        'bakery'  => 'Boulangerie',
        'bar'     => 'Bar (véranda)',
        'counter' => 'Comptoir',
    ];
    return $labels[$station] ?? $station;
}

function categoryLabel(string $cat): string {
    $labels = [
        'entree'  => 'Entrée',
        'plat'    => 'Plat',
        'grill'   => 'Grillade',
        'pain'    => 'Pain',
        'cafe'    => 'Café',
        'boisson' => 'Boisson',
        'openbar' => 'Alcool / Open-bar',
        'autre'   => 'Autre',
    ];
    return $labels[$cat] ?? $cat;
}
