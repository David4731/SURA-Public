<?php
/**
 * Session de service = 1 jour calendaire.
 * S'assure qu'une session "open" existe pour aujourd'hui.
 * Change automatiquement à minuit (nouvelle date = nouvelle session).
 */
function sulaEnsureTodaySession(PDO $pdo, $openedBy = null): array {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS service_sessions (
          id INT AUTO_INCREMENT PRIMARY KEY,
          session_date DATE NOT NULL UNIQUE,
          status ENUM('open','closed') NOT NULL DEFAULT 'open',
          opened_by INT NULL,
          closed_by INT NULL,
          opened_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
          closed_at TIMESTAMP NULL,
          notes TEXT
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Exception $e) {}

    $today = date('Y-m-d');
    try {
        $st = $pdo->prepare("SELECT * FROM service_sessions WHERE session_date = ? LIMIT 1");
        $st->execute([$today]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            // Si session d'hier encore "open", la clôturer
            try {
                $pdo->prepare("UPDATE service_sessions SET status='closed', closed_at=NOW() WHERE session_date < ? AND status='open'")
                    ->execute([$today]);
            } catch (Exception $e) {}
            return $row;
        }
        // Créer session du jour
        $pdo->prepare("INSERT INTO service_sessions (session_date, status, opened_by) VALUES (?, 'open', ?)")
            ->execute([$today, $openedBy]);
        $st->execute([$today]);
        return $st->fetch(PDO::FETCH_ASSOC) ?: ['session_date' => $today, 'status' => 'open'];
    } catch (Exception $e) {
        return ['session_date' => $today, 'status' => 'open', 'error' => $e->getMessage()];
    }
}

function sulaCurrentSessionLabel(PDO $pdo): string {
    $s = sulaEnsureTodaySession($pdo);
    $d = $s['session_date'] ?? date('Y-m-d');
    $st = $s['status'] ?? 'open';
    return 'Session ' . date('d/m/Y', strtotime($d)) . ($st === 'open' ? ' · Ouverte' : ' · Clôturée');
}
