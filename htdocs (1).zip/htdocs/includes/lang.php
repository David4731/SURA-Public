<?php
/**
 * i18n SURA RMS — fr, en, mg, ko
 * Session + cookie pour que l’espace client garde la langue
 */
if (session_status() === PHP_SESSION_NONE) {
    // Cookie de session plus fiable (sous-dossiers / hébergeurs partagés)
    if (PHP_VERSION_ID >= 70300) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    } else {
        session_set_cookie_params(0, '/');
    }
    session_start();
}

$supported = ['fr', 'en', 'mg', 'ko'];
$default = 'fr';

// 1) ?lang=xx a priorité
if (isset($_GET['lang']) && in_array($_GET['lang'], $supported, true)) {
    $_SESSION['lang'] = $_GET['lang'];
    // Cookie 30 jours — backup si la session expire
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    if (PHP_VERSION_ID >= 70300) {
        setcookie('sula_lang', $_GET['lang'], [
            'expires' => time() + 60 * 60 * 24 * 30,
            'path' => '/',
            'secure' => $secure,
            'httponly' => false,
            'samesite' => 'Lax',
        ]);
    } else {
        setcookie('sula_lang', $_GET['lang'], time() + 60 * 60 * 24 * 30, '/');
    }
}

// 2) Session
if (isset($_SESSION['lang']) && in_array($_SESSION['lang'], $supported, true)) {
    $currentLang = $_SESSION['lang'];
}
// 3) Cookie
elseif (isset($_COOKIE['sula_lang']) && in_array($_COOKIE['sula_lang'], $supported, true)) {
    $currentLang = $_COOKIE['sula_lang'];
    $_SESSION['lang'] = $currentLang;
}
// 4) Défaut
else {
    $currentLang = $default;
}

$langFile = __DIR__ . '/../lang/' . $currentLang . '.php';
if (!file_exists($langFile)) {
    $langFile = __DIR__ . '/../lang/fr.php';
}
$translations = require $langFile;
if (!is_array($translations)) {
    $translations = [];
}

if (!function_exists('t')) {
    function t($key, $replace = []) {
        global $translations;
        $text = isset($translations[$key]) ? $translations[$key] : $key;
        if ($replace) {
            foreach ($replace as $k => $v) {
                $text = str_replace(':' . $k, $v, $text);
            }
        }
        return $text;
    }
}

if (!function_exists('currentLang')) {
    function currentLang() {
        global $currentLang;
        return $currentLang;
    }
}

if (!function_exists('langFlags')) {
    function langFlags() {
        return [
            'fr' => '🇫🇷 Français',
            'en' => '🇬🇧 English',
            'mg' => '🇲🇬 Malagasy',
            'ko' => '🇰🇷 한국어',
        ];
    }
}

/** Construit une URL vers la page courante avec une autre langue */
if (!function_exists('sulaLangUrl')) {
    function sulaLangUrl(string $code): string {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $path = parse_url($uri, PHP_URL_PATH) ?: '/';
        $query = [];
        $qs = parse_url($uri, PHP_URL_QUERY);
        if ($qs) {
            parse_str($qs, $query);
        }
        // Conserver aussi $_GET (parfois plus fiable)
        foreach ($_GET as $k => $v) {
            if ($k === 'lang') continue;
            if (!isset($query[$k])) $query[$k] = $v;
        }
        $query['lang'] = $code;
        return $path . '?' . http_build_query($query);
    }
}
