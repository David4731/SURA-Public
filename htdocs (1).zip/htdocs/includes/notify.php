<?php
/**
 * Create a team notification (visible to all if user_id is null)
 */
function sulaNotify(PDO $pdo, string $title, string $body = '', string $type = 'info', $userId = null): void
{
    try {
        $pdo->prepare('INSERT INTO notifications (user_id, type, title, body, is_read) VALUES (?,?,?,?,0)')
            ->execute([$userId, $type, $title, $body]);
    } catch (Exception $e) {
        // table may not exist yet
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS notifications (
              id INT AUTO_INCREMENT PRIMARY KEY,
              user_id INT NULL,
              type VARCHAR(40) NOT NULL DEFAULT 'info',
              title VARCHAR(200) NOT NULL,
              body TEXT,
              is_read TINYINT(1) NOT NULL DEFAULT 0,
              created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->prepare('INSERT INTO notifications (user_id, type, title, body, is_read) VALUES (?,?,?,?,0)')
                ->execute([$userId, $type, $title, $body]);
        } catch (Exception $e2) {}
    }
}
