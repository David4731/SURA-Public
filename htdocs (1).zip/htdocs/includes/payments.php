<?php
/**
 * Helpers paiements SURA
 */
function sulaPaymentConfig(): array {
    static $cfg = null;
    if ($cfg === null) {
        $path = __DIR__ . '/../config/payments.php';
        $cfg = file_exists($path) ? (require $path) : [];
    }
    return $cfg;
}

function sulaPaymentMethods(): array {
    $cfg = sulaPaymentConfig();
    return $cfg['merchant'] ?? [];
}

function sulaGeneratePaymentRef(string $prefix = ''): string {
    $cfg = sulaPaymentConfig();
    $p = $prefix !== '' ? $prefix : ($cfg['ref_prefix'] ?? 'SURA');
    return strtoupper($p) . '-' . date('ymd') . '-' . strtoupper(substr(bin2hex(random_bytes(3)), 0, 6));
}

/**
 * Crée une demande de paiement liée à une commande
 */
function sulaCreatePaymentRequest(PDO $pdo, int $orderId, float $amount, string $method, ?string $payerName = null, ?string $payerPhone = null): array {
    $allowed = ['mvola','orange_money','airtel_money','virement','cash','autre'];
    if (!in_array($method, $allowed, true)) $method = 'cash';
    $ref = sulaGeneratePaymentRef();
    // Ne pas exécuter de DDL au milieu d'une transaction (commit implicite MySQL)
    if (!$pdo->inTransaction()) {
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS payment_requests (
              id INT AUTO_INCREMENT PRIMARY KEY,
              order_id INT NULL,
              reservation_id INT NULL,
              method VARCHAR(40) NOT NULL DEFAULT 'mvola',
              amount DECIMAL(12,2) NOT NULL DEFAULT 0,
              reference VARCHAR(40) NOT NULL,
              payer_name VARCHAR(100) NULL,
              payer_phone VARCHAR(30) NULL,
              status VARCHAR(30) NOT NULL DEFAULT 'pending',
              external_id VARCHAR(100) NULL,
              proof_note TEXT NULL,
              confirmed_by INT NULL,
              confirmed_at DATETIME NULL,
              created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
              UNIQUE KEY uk_reference (reference)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        } catch (Exception $e) {}
    }

    $st = $pdo->prepare('INSERT INTO payment_requests (order_id, method, amount, reference, payer_name, payer_phone, status) VALUES (?,?,?,?,?,?,?)');
    $st->execute([$orderId, $method, $amount, $ref, $payerName, $payerPhone, $method === 'cash' ? 'pending' : 'awaiting_proof']);
    return ['id' => (int)$pdo->lastInsertId(), 'reference' => $ref, 'method' => $method, 'amount' => $amount];
}

/**
 * Instructions affichées au client selon le mode
 */
function sulaPaymentInstructions(string $method, string $ref, float $amount): string {
    $merchants = sulaPaymentMethods();
    $m = $merchants[$method] ?? null;
    $amt = number_format($amount, 0, ',', ' ') . ' Ar';
    if ($method === 'cash') {
        return "Paiement en espèces à la livraison / au restaurant. Montant : $amt. Réf. : $ref";
    }
    if ($method === 'virement') {
        $bank = $m['bank'] ?? 'Banque';
        $acc = $m['account_name'] ?? 'SURA';
        $iban = $m['iban'] ?? '(RIB à confirmer)';
        return "Virement $bank — Bénéficiaire : $acc — Compte : $iban — Montant : $amt — Libellé obligatoire : $ref";
    }
    $num = $m['number'] ?? '—';
    $label = $m['label'] ?? $method;
    return "Envoyez $amt via $label vers $num. Indiquez la référence $ref dans le message / motif du transfert.";
}
