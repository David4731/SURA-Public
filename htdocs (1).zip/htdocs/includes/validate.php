<?php
/**
 * Validation téléphone Madagascar (MVola / Orange / Airtel)
 * Compatible PHP 7.4+
 */
function sulaNormalizePhone($phone) {
    $d = preg_replace('/\D+/', '', (string)$phone);
    if (strpos($d, '261') === 0 && strlen($d) >= 12) {
        $d = '0' . substr($d, 3);
    } elseif (strlen($d) === 9 && isset($d[0]) && $d[0] === '3') {
        $d = '0' . $d;
    }
    return $d;
}

function sulaIsValidMgPhone($phone) {
    $d = sulaNormalizePhone($phone);
    // 10 chiffres: 03X XXX XX XX — opérateurs 032–039
    return (bool)preg_match('/^0(3[2-9])\d{7}$/', $d);
}

function sulaFormatPhone($phone) {
    $d = sulaNormalizePhone($phone);
    if (strlen($d) === 10) {
        return substr($d, 0, 3) . ' ' . substr($d, 3, 2) . ' ' . substr($d, 5, 3) . ' ' . substr($d, 8, 2);
    }
    return (string)$phone;
}
