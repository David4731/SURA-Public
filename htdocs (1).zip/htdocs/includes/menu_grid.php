<?php
/**
 * Grille de cartes menu / stock (style luxury)
 *
 * Variables attendues :
 *   $menus          array
 *   $categories     array code => label (optionnel)
 *   $menuGridMode   'order' | 'manage' | 'stock'  (défaut manage)
 *   $menuGridShowTable  bool — afficher le tableau sous la grille (défaut true pour manage/stock)
 */
if (!isset($menus) || !is_array($menus)) return;
if (!isset($categories) || !is_array($categories)) {
    $categories = [
        'entree' => 'Entrées', 'plat' => 'Plats', 'grill' => 'Grillades',
        'pain' => 'Pains', 'cafe' => 'Cafés', 'boisson' => 'Boissons',
        'openbar' => 'Open-Bar', 'dessert' => 'Desserts', 'autre' => 'Autre',
    ];
}
$mode = $menuGridMode ?? 'manage';
$showTable = $menuGridShowTable ?? in_array($mode, ['manage', 'stock'], true);

$byCat = [];
foreach ($menus as $m) {
    $byCat[$m['category'] ?? 'autre'][] = $m;
}
?>
<style>
.sula-menu-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 1rem;
  width: 100%;
}
.sula-menu-card {
  position: relative;
  border-radius: 1rem;
  overflow: hidden;
  background: #121215;
  border: 1px solid rgba(212,175,55,.25);
  display: flex;
  flex-direction: column;
  min-width: 0;
  transition: border-color .2s, transform .2s, box-shadow .2s;
}
.sula-menu-card:hover {
  border-color: rgba(212,175,55,.6);
  transform: translateY(-2px);
  box-shadow: 0 12px 28px rgba(0,0,0,.22);
}
.sula-menu-card .img-wrap {
  position: relative;
  width: 100%;
  aspect-ratio: 4 / 3;
  overflow: hidden;
  background: #1a1a1e;
}
.sula-menu-card .img-wrap img {
  width: 100%; height: 100%; object-fit: cover; display: block;
}
.sula-menu-card .img-placeholder {
  width: 100%; height: 100%; display: flex; align-items: center; justify-content: center;
  font-size: 2rem; font-weight: 700; color: rgba(212,175,55,.35);
  background: linear-gradient(135deg, #1a1a1e, #0a0a0c);
}
.sula-menu-card .badge-stock {
  position: absolute; top: .65rem; right: .65rem;
  font-size: .7rem; font-weight: 700; padding: .25rem .55rem;
  border-radius: 999px; color: #0a0a0c; z-index: 2;
}
.sula-menu-card .badge-stock.ok { background: #34d399; }
.sula-menu-card .badge-stock.low { background: #f87171; color: #fff; }
.sula-menu-card .badge-stock.mid { background: #fbbf24; }
.sula-menu-card .badge-cat {
  position: absolute; bottom: .65rem; left: .65rem;
  font-size: .65rem; font-weight: 700; letter-spacing: .06em; text-transform: uppercase;
  padding: .2rem .5rem; border-radius: .4rem;
  background: rgba(10,10,12,.75); color: #e2e8f0; border: 1px solid rgba(255,255,255,.15);
}
.sula-menu-card .body {
  padding: .9rem 1rem 1rem; flex: 1; display: flex; flex-direction: column; min-width: 0;
}
.sula-menu-card .title {
  font-family: 'Playfair Display', serif; font-size: 1.05rem; font-weight: 600;
  color: #f1f5f9; margin: 0 0 .35rem; line-height: 1.25;
  display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;
}
.sula-menu-card .price { font-size: 1.15rem; font-weight: 700; color: #d4af37; margin-bottom: .75rem; }
.sula-menu-card .actions { margin-top: auto; }
.sula-menu-card .qty-row { display: flex; align-items: center; gap: .4rem; flex-wrap: wrap; }
.sula-menu-card .qty-row input {
  width: 64px; text-align: center; background: #0a0a0c; border: 1px solid rgba(212,175,55,.3);
  color: #f1f5f9; border-radius: .5rem; padding: .35rem;
}
html[data-theme="light"] .sula-menu-card { background: #fff; border-color: rgba(183,138,40,.3); }
html[data-theme="light"] .sula-menu-card .title { color: #1c1917; }
html[data-theme="light"] .sula-menu-card .qty-row input { background: #fff; color: #1c1917; }
.sula-menu-section-title {
  font-size: .75rem; text-transform: uppercase; letter-spacing: .12em;
  color: #d4af37; font-weight: 700; margin: 1.5rem 0 .75rem;
}
/* Small screens: compact horizontal cards, one dish per row. */
@media (max-width: 575.98px) {
  .sula-menu-grid { grid-template-columns: minmax(0, 1fr); gap: .7rem; }
  .sula-menu-card { flex-direction: row; align-items: stretch; }
  .sula-menu-card .img-wrap { width: 108px; min-width: 108px; max-width: 108px; aspect-ratio: 1 / 1; height: auto; flex-shrink: 0; }
  .sula-menu-card .body { padding: .65rem .8rem; justify-content: center; }
  .sula-menu-card .title { font-size: .95rem; }
  .sula-menu-card .price { font-size: 1rem; margin-bottom: .4rem; }
  .sula-menu-card .badge-stock { top: .35rem; right: .35rem; font-size: .58rem; padding: .15rem .35rem; }
  .sula-menu-card .badge-cat { bottom: .35rem; left: .35rem; font-size: .5rem; padding: .1rem .3rem; }
}
@media (min-width: 576px) and (max-width: 991.98px) {
  .sula-menu-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); gap: .85rem; }
}
@media (max-width: 360px) {
  .sula-menu-card .img-wrap { width: 88px; min-width: 88px; max-width: 88px; }
  .sula-menu-card .body { padding: .55rem .6rem; }
}
</style>

<?php if ($mode === 'order'): ?>
  <?php foreach ($byCat as $cat => $list): ?>
    <div class="sula-menu-section-title"><?= htmlspecialchars($categories[$cat] ?? $cat) ?></div>
    <div class="sula-menu-grid mb-3">
      <?php foreach ($list as $m):
        $stock = (int)($m['stock'] ?? 0);
        $min = (int)($m['stock_min'] ?? 5);
        $stockClass = $stock <= 0 ? 'low' : ($stock <= $min ? 'mid' : 'ok');
      ?>
        <div class="sula-menu-card">
          <div class="img-wrap">
            <?php if (!empty($m['image'])): ?>
              <img src="/uploads/<?= htmlspecialchars($m['image']) ?>" alt="" loading="lazy"
                   onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
              <div class="img-placeholder" style="display:none"><?= strtoupper(substr($m['name'],0,2)) ?></div>
            <?php else: ?>
              <div class="img-placeholder"><?= strtoupper(substr($m['name'],0,2)) ?></div>
            <?php endif; ?>
            <span class="badge-stock <?= $stockClass ?>">Stock: <?= $stock ?></span>
            <span class="badge-cat"><?= htmlspecialchars($categories[$cat] ?? $cat) ?></span>
          </div>
          <div class="body">
            <h4 class="title"><?= htmlspecialchars($m['name']) ?></h4>
            <div class="price"><?= number_format((float)$m['price'], 0, ',', ' ') ?> Ar</div>
            <div class="actions qty-row">
              <?php if ($stock <= 0): ?>
                <span class="badge bg-danger">Épuisé — indisponible</span>
                <input type="number" name="items[<?= (int)$m['id'] ?>]" min="0" max="0" value="0"
                       class="qty-input" data-id="<?= (int)$m['id'] ?>" data-price="<?= (float)$m['price'] ?>"
                       data-stock="0" disabled aria-label="Plat épuisé">
                <button type="button" class="btn btn-sm btn-outline-secondary add-btn" data-id="<?= (int)$m['id'] ?>" disabled>+</button>
              <?php else: ?>
                <input type="number" name="items[<?= (int)$m['id'] ?>]" min="0" max="<?= $stock ?>" value="0"
                       class="qty-input" data-id="<?= (int)$m['id'] ?>" data-price="<?= (float)$m['price'] ?>"
                       data-stock="<?= $stock ?>">
                <button type="button" class="btn btn-sm btn-outline-warning add-btn" data-id="<?= (int)$m['id'] ?>" data-stock="<?= $stock ?>">+</button>
              <?php endif; ?>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>

<?php else: /* manage | stock */ ?>
  <div class="sula-menu-grid mb-4">
    <?php foreach ($menus as $m):
      $stock = (int)($m['stock'] ?? 0);
      $min = (int)($m['stock_min'] ?? 5);
      $stockClass = $stock <= 0 ? 'low' : ($stock <= $min ? 'mid' : 'ok');
      $cat = $m['category'] ?? 'autre';
    ?>
      <div class="sula-menu-card">
        <div class="img-wrap">
          <?php if (!empty($m['image'])): ?>
            <img src="/uploads/<?= htmlspecialchars($m['image']) ?>" alt="" loading="lazy"
                 onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
            <div class="img-placeholder" style="display:none"><?= strtoupper(substr($m['name'],0,2)) ?></div>
          <?php else: ?>
            <div class="img-placeholder"><?= strtoupper(substr($m['name'],0,2)) ?></div>
          <?php endif; ?>
          <span class="badge-stock <?= $stockClass ?>">Stock: <?= $stock ?></span>
          <span class="badge-cat"><?= htmlspecialchars($categories[$cat] ?? $cat) ?></span>
        </div>
        <div class="body">
          <h4 class="title"><?= htmlspecialchars($m['name']) ?></h4>
          <div class="price"><?= number_format((float)$m['price'], 0, ',', ' ') ?> Ar</div>
          <?php if ($mode === 'manage'): ?>
            <div class="actions d-flex flex-wrap gap-1">
              <a href="?edit=<?= (int)$m['id'] ?>" class="btn btn-sm btn-outline-warning flex-grow-1">
                <i class="fa-solid fa-pen"></i> Stock Manager : Modifier
              </a>
              <button type="button" class="btn btn-sm btn-outline-success" data-bs-toggle="modal" data-bs-target="#stockModal<?= (int)$m['id'] ?>" title="Ajuster">±</button>
              <form method="post" class="d-inline" onsubmit="return confirm('Supprimer ?')">
                <input type="hidden" name="delete" value="1">
                <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                <button class="btn btn-sm btn-outline-danger">×</button>
              </form>
            </div>
          <?php else: ?>
            <div class="actions small text-slate-400">
              Min: <?= $min ?> · <?= !empty($m['available']) ? 'Dispo' : 'Off' ?>
              <a href="/pages/menus.php?edit=<?= (int)$m['id'] ?>" class="btn btn-sm btn-outline-warning w-100 mt-2">
                <i class="fa-solid fa-pen"></i> Modifier
              </a>
            </div>
          <?php endif; ?>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
<?php endif; ?>

<?php if ($showTable && $mode !== 'order'): ?>
<div class="glass-card rounded-2xl p-3 border border-gold-500/20 mt-2">
  <h5 class="font-serif text-gold-300 mb-2 text-sm">Liste détaillée</h5>
  <div class="table-responsive">
    <table class="table table-sm align-middle mb-0">
      <thead>
        <tr>
          <th></th>
          <th>Nom</th>
          <th>Cat.</th>
          <th>Prix</th>
          <th>Stock</th>
          <th>Min</th>
          <?php if ($mode === 'manage'): ?><th></th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($menus as $m):
        $stock = (int)($m['stock'] ?? 0);
        $min = (int)($m['stock_min'] ?? 5);
      ?>
        <tr class="<?= $stock <= $min ? 'table-warning' : '' ?>">
          <td style="width:44px">
            <?php if (!empty($m['image'])): ?>
              <img src="/uploads/<?= htmlspecialchars($m['image']) ?>" alt="" style="width:36px;height:36px;object-fit:cover;border-radius:6px">
            <?php else: ?>
              <div class="bg-dark text-center rounded" style="width:36px;height:36px;line-height:36px;font-size:11px"><?= strtoupper(substr($m['name'],0,2)) ?></div>
            <?php endif; ?>
          </td>
          <td><strong><?= htmlspecialchars($m['name']) ?></strong><?php if (empty($m['available'])): ?> <span class="badge bg-secondary">Off</span><?php endif; ?></td>
          <td class="small"><?= htmlspecialchars($categories[$m['category'] ?? ''] ?? ($m['category'] ?? '')) ?></td>
          <td><?= number_format((float)$m['price'], 0, ',', ' ') ?></td>
          <td><strong><?= $stock ?></strong></td>
          <td class="small text-muted"><?= $min ?></td>
          <?php if ($mode === 'manage'): ?>
          <td class="text-nowrap">
            <a href="?edit=<?= (int)$m['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-pencil"></i></a>
          </td>
          <?php endif; ?>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>
