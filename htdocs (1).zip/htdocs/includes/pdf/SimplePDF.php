<?php
/**
 * SURA Professional PDF (A4) — tables, headers, CEO-style reports
 * Pure PHP, no extensions required (InfinityFree compatible)
 */
class SimplePDF
{
    private $pages = [];
    private $current = '';
    private $w = 595.28;
    private $h = 841.89;
    private $x = 40;
    private $y = 800;
    private $fontSize = 10;
    private $lineHeight = 13;
    private $marginL = 40;
    private $marginR = 40;
    private $marginT = 40;
    private $marginB = 40;
    private $pageNum = 0;

    public function __construct()
    {
        $this->addPage();
    }

    public function addPage()
    {
        if ($this->current !== '') {
            $this->pages[] = $this->current;
        }
        $this->current = '';
        $this->pageNum++;
        $this->x = $this->marginL;
        $this->y = $this->h - $this->marginT;
        $this->fontSize = 10;
        $this->lineHeight = 13;
    }

    public function setFontSize($s)
    {
        $this->fontSize = (float)$s;
        $this->lineHeight = max(11, $this->fontSize + 3);
    }

    private function esc($s)
    {
        $s = (string)$s;
        if (function_exists('iconv')) {
            $c = @iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $s);
            if ($c !== false) $s = $c;
        }
        return str_replace(['\\', '(', ')'], ['\\\\', '\\(', '\\)'], $s);
    }

    private function ensureSpace($need = 20)
    {
        if ($this->y < $this->marginB + $need) {
            $this->addPage();
        }
    }

    public function setFillColor($r, $g, $b)
    {
        $this->current .= sprintf("%.3F %.3F %.3F rg\n", $r / 255, $g / 255, $b / 255);
    }

    public function setDrawColor($r, $g, $b)
    {
        $this->current .= sprintf("%.3F %.3F %.3F RG\n", $r / 255, $g / 255, $b / 255);
    }

    public function setTextColor($r, $g, $b)
    {
        $this->current .= sprintf("%.3F %.3F %.3F rg\n", $r / 255, $g / 255, $b / 255);
    }

    public function rect($x, $y, $w, $h, $style = 'S')
    {
        // PDF y is bottom-up; our $y is top-down cursor at baseline-ish
        $this->current .= sprintf("%.2F %.2F %.2F %.2F re %s\n", $x, $y, $w, $h, $style);
    }

    public function textAt($x, $y, $str, $size = null)
    {
        $size = $size ?? $this->fontSize;
        $this->current .= sprintf(
            "BT /F1 %.2F Tf %.2F %.2F Td (%s) Tj ET\n",
            $size,
            $x,
            $y,
            $this->esc($str)
        );
    }

    public function cell($text, $moveDown = true)
    {
        $this->ensureSpace();
        $this->textAt($this->x, $this->y, $text);
        if ($moveDown) {
            $this->y -= $this->lineHeight;
            $this->x = $this->marginL;
        }
    }

    public function ln($n = 1)
    {
        $this->y -= $this->lineHeight * $n;
        $this->x = $this->marginL;
    }

    public function hr($color = [212, 175, 55])
    {
        $this->setDrawColor($color[0], $color[1], $color[2]);
        $this->current .= sprintf("%.2F %.2F m %.2F %.2F l S\n", $this->marginL, $this->y + 2, $this->w - $this->marginR, $this->y + 2);
        $this->current .= "0 0 0 RG\n";
        $this->y -= 8;
    }

    /** Header band for CEO reports */
    public function reportHeader($title, $subtitle = '', $period = '')
    {
        // Gold top bar
        $this->setFillColor(18, 18, 21);
        $this->rect(0, $this->h - 55, $this->w, 55, 'F');
        $this->setFillColor(212, 175, 55);
        $this->rect(0, $this->h - 58, $this->w, 3, 'F');

        $this->setTextColor(212, 175, 55);
        $this->textAt(40, $this->h - 28, 'SURA LUXURY RMS', 14);
        $this->setTextColor(241, 245, 249);
        $this->textAt(40, $this->h - 44, 'Olympia Tanjombato  |  MVola 038 24 541 74', 8);

        $this->y = $this->h - 75;
        $this->setTextColor(28, 25, 23);
        $this->setFontSize(18);
        $this->cell($title);
        $this->setFontSize(10);
        if ($subtitle !== '') {
            $this->setTextColor(100, 100, 100);
            $this->cell($subtitle);
        }
        if ($period !== '') {
            $this->setTextColor(120, 113, 108);
            $this->cell('Periode : ' . $period . '   |   Genere le ' . date('d/m/Y H:i'));
        }
        $this->setTextColor(0, 0, 0);
        $this->ln(0.3);
        $this->hr();
        $this->ln(0.2);
    }

    public function sectionTitle($text)
    {
        $this->ensureSpace(30);
        $this->setFillColor(212, 175, 55);
        $this->rect($this->marginL, $this->y - 4, 4, 14, 'F');
        $this->setTextColor(28, 25, 23);
        $this->setFontSize(12);
        $this->textAt($this->marginL + 10, $this->y, $text, 12);
        $this->y -= 18;
        $this->setFontSize(10);
        $this->setTextColor(0, 0, 0);
    }

    /** KPI boxes in a row (up to 4) */
    public function kpiRow(array $items)
    {
        $this->ensureSpace(50);
        $n = max(1, count($items));
        $gap = 8;
        $boxW = ($this->w - $this->marginL - $this->marginR - $gap * ($n - 1)) / $n;
        $boxH = 42;
        $yBox = $this->y - $boxH;
        $x = $this->marginL;
        foreach ($items as $it) {
            $this->setFillColor(250, 247, 240);
            $this->setDrawColor(212, 175, 55);
            $this->rect($x, $yBox, $boxW, $boxH, 'FD');
            $this->setTextColor(120, 113, 108);
            $this->textAt($x + 8, $yBox + 28, $it['label'] ?? '', 8);
            $this->setTextColor(28, 25, 23);
            $this->textAt($x + 8, $yBox + 12, $it['value'] ?? '', 12);
            $x += $boxW + $gap;
        }
        $this->y = $yBox - 12;
        $this->setTextColor(0, 0, 0);
        $this->current .= "0 0 0 RG\n";
    }

    /**
     * Modern table
     * $headers = ['Col1','Col2']
     * $rows = [['a','b'], ...]
     * $widths = [200, 150] in points (optional)
     * $aligns = ['L','R'] optional
     */
    public function table(array $headers, array $rows, array $widths = null, array $aligns = null)
    {
        $cols = count($headers);
        if ($cols < 1) return;
        $usable = $this->w - $this->marginL - $this->marginR;
        if (!$widths || count($widths) !== $cols) {
            $widths = array_fill(0, $cols, $usable / $cols);
        }
        $rowH = 16;
        $aligns = $aligns ?? array_fill(0, $cols, 'L');

        $drawHeader = function () use ($headers, $widths, $cols, $rowH) {
            $this->ensureSpace($rowH + 10);
            $x = $this->marginL;
            $y = $this->y - $rowH;
            $this->setFillColor(28, 25, 23);
            $this->rect($this->marginL, $y, array_sum($widths), $rowH, 'F');
            $this->setTextColor(212, 175, 55);
            $xx = $x;
            for ($i = 0; $i < $cols; $i++) {
                $this->textAt($xx + 4, $y + 5, mb_substr($headers[$i], 0, 40), 9);
                $xx += $widths[$i];
            }
            $this->y = $y - 1;
            $this->setTextColor(0, 0, 0);
        };

        $drawHeader();

        $alt = false;
        foreach ($rows as $row) {
            if ($this->y < $this->marginB + $rowH + 5) {
                $this->addPage();
                $drawHeader();
                $alt = false;
            }
            $y = $this->y - $rowH;
            if ($alt) {
                $this->setFillColor(245, 241, 232);
                $this->rect($this->marginL, $y, array_sum($widths), $rowH, 'F');
            }
            $this->setDrawColor(230, 220, 200);
            $this->rect($this->marginL, $y, array_sum($widths), $rowH, 'S');
            $this->setTextColor(40, 40, 40);
            $xx = $this->marginL;
            for ($i = 0; $i < $cols; $i++) {
                $val = isset($row[$i]) ? (string)$row[$i] : '';
                $val = mb_substr($val, 0, 42);
                $tx = $xx + 4;
                if (($aligns[$i] ?? 'L') === 'R') {
                    // rough right align
                    $tx = $xx + $widths[$i] - 4 - strlen($val) * ($this->fontSize * 0.45);
                    $tx = max($xx + 2, $tx);
                }
                $this->textAt($tx, $y + 5, $val, 9);
                $xx += $widths[$i];
            }
            $this->y = $y;
            $alt = !$alt;
        }
        $this->y -= 10;
        $this->setTextColor(0, 0, 0);
        $this->current .= "0 0 0 RG\n";
    }


    /**
     * Vertical bar chart
     * $data = [['label'=>'Lun','value'=>10,'color'=>[212,175,55]], ...]
     */
    public function barChart(array $data, $title = '', $maxHeight = 120)
    {
        if (!$data) return;
        $this->ensureSpace($maxHeight + 50);
        if ($title !== '') {
            $this->sectionTitle($title);
        }
        $maxVal = 0;
        foreach ($data as $d) {
            $maxVal = max($maxVal, (float)($d['value'] ?? 0));
        }
        if ($maxVal <= 0) $maxVal = 1;

        $n = count($data);
        $gap = 6;
        $usable = $this->w - $this->marginL - $this->marginR;
        $barW = min(48, ($usable - $gap * ($n - 1)) / max(1, $n));
        $baseY = $this->y - $maxHeight;
        $x = $this->marginL;

        // axis line
        $this->setDrawColor(200, 200, 200);
        $this->current .= sprintf("%.2F %.2F m %.2F %.2F l S\n", $this->marginL, $baseY, $this->w - $this->marginR, $baseY);

        $colors = [
            [212, 175, 55],
            [28, 25, 23],
            [52, 211, 153],
            [248, 113, 113],
            [96, 165, 250],
            [251, 146, 60],
            [167, 139, 250],
            [244, 114, 182],
        ];

        foreach ($data as $i => $d) {
            $val = (float)($d['value'] ?? 0);
            $h = ($val / $maxVal) * $maxHeight;
            $c = $d['color'] ?? $colors[$i % count($colors)];
            $this->setFillColor($c[0], $c[1], $c[2]);
            $this->rect($x, $baseY, $barW, max(1, $h), 'F');
            // value on top
            $this->setTextColor(60, 60, 60);
            $labelVal = isset($d['display']) ? $d['display'] : (string)(int)$val;
            $this->textAt($x, $baseY + $h + 4, mb_substr($labelVal, 0, 10), 7);
            // label under
            $this->setTextColor(100, 100, 100);
            $this->textAt($x, $baseY - 10, mb_substr($d['label'] ?? '', 0, 12), 7);
            $x += $barW + $gap;
        }
        $this->y = $baseY - 24;
        $this->setTextColor(0, 0, 0);
        $this->current .= "0 0 0 RG\n";
    }

    /**
     * Horizontal bar chart for rankings
     * $data = [['label'=>'Produit','value'=>100], ...]
     */
    public function hBarChart(array $data, $title = '', $barMaxW = 280)
    {
        if (!$data) return;
        $this->ensureSpace(count($data) * 18 + 40);
        if ($title !== '') {
            $this->sectionTitle($title);
        }
        $maxVal = 0;
        foreach ($data as $d) {
            $maxVal = max($maxVal, (float)($d['value'] ?? 0));
        }
        if ($maxVal <= 0) $maxVal = 1;

        $colors = [
            [212, 175, 55],
            [183, 138, 40],
            [52, 211, 153],
            [96, 165, 250],
            [248, 113, 113],
            [251, 146, 60],
        ];
        $labelW = 140;
        foreach ($data as $i => $d) {
            $this->ensureSpace(20);
            $val = (float)($d['value'] ?? 0);
            $w = max(2, ($val / $maxVal) * $barMaxW);
            $c = $d['color'] ?? $colors[$i % count($colors)];
            $y = $this->y - 12;
            $this->setTextColor(40, 40, 40);
            $this->textAt($this->marginL, $y + 2, mb_substr($d['label'] ?? '', 0, 22), 8);
            $this->setFillColor($c[0], $c[1], $c[2]);
            $this->rect($this->marginL + $labelW, $y, $w, 10, 'F');
            $this->setTextColor(80, 80, 80);
            $disp = isset($d['display']) ? $d['display'] : (string)(int)$val;
            $this->textAt($this->marginL + $labelW + $w + 4, $y + 2, $disp, 7);
            $this->y -= 16;
        }
        $this->y -= 6;
        $this->setTextColor(0, 0, 0);
    }

    /** Color legend */
    public function legend(array $items)
    {
        $x = $this->marginL;
        $y = $this->y - 8;
        foreach ($items as $it) {
            $c = $it['color'] ?? [200, 200, 200];
            $this->setFillColor($c[0], $c[1], $c[2]);
            $this->rect($x, $y, 8, 8, 'F');
            $this->setTextColor(60, 60, 60);
            $this->textAt($x + 12, $y + 1, $it['label'] ?? '', 8);
            $x += 90;
            if ($x > $this->w - 100) {
                $x = $this->marginL;
                $y -= 14;
            }
        }
        $this->y = $y - 16;
        $this->setTextColor(0, 0, 0);
    }

    public function footerNote($text = '')
    {
        $this->setTextColor(140, 140, 140);
        $this->textAt($this->marginL, 30, $text !== '' ? $text : 'SURA Restaurant - Document confidentiel - Usage interne direction', 7);
        $this->textAt($this->w - $this->marginR - 40, 30, 'Page ' . $this->pageNum, 7);
        $this->setTextColor(0, 0, 0);
    }

    public function output($filename = 'document.pdf', $dest = 'D')
    {
        // stamp footer on each page content before freeze - simple: append to current page only
        // Rebuild: add footer to each page stream at end
        if ($this->current !== '') {
            $this->pages[] = $this->current;
            $this->current = '';
        }
        // Add page numbers in a second pass
        foreach ($this->pages as $i => &$content) {
            $p = $i + 1;
            $content .= sprintf("BT /F1 7 Tf 40 30 Td (%s) Tj ET\n", $this->esc('SURA - Confidentiel direction'));
            $content .= sprintf("BT /F1 7 Tf %.2F 30 Td (%s) Tj ET\n", $this->w - 80, $this->esc('Page ' . $p . '/' . count($this->pages)));
        }
        unset($content);

        $pdf = $this->build();
        if ($dest === 'S') return $pdf;
        $disp = ($dest === 'I') ? 'inline' : 'attachment';
        header('Content-Type: application/pdf');
        header('Content-Disposition: ' . $disp . '; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($pdf));
        header('Cache-Control: private, max-age=0, must-revalidate');
        echo $pdf;
        exit;
    }

    private function build()
    {
        $out = "%PDF-1.4\n";
        $offsets = [0];
        $fontId = 0;
        $pageMeta = [];
        $obj = 3;

        foreach ($this->pages as $content) {
            $pageMeta[] = ['c' => $obj, 'p' => $obj + 1];
            $obj += 2;
        }
        $fontId = $obj;

        $kids = [];
        foreach ($pageMeta as $pm) $kids[] = $pm['p'] . ' 0 R';
        $pagesObj = '<< /Type /Pages /Kids [' . implode(' ', $kids) . '] /Count ' . count($kids) . ' >>';

        $offsets[1] = strlen($out);
        $out .= "1 0 obj\n<< /Type /Catalog /Pages 2 0 R >>\nendobj\n";
        $offsets[2] = strlen($out);
        $out .= "2 0 obj\n$pagesObj\nendobj\n";

        foreach ($this->pages as $i => $content) {
            $cId = $pageMeta[$i]['c'];
            $pId = $pageMeta[$i]['p'];
            $len = strlen($content);
            $offsets[$cId] = strlen($out);
            $out .= "$cId 0 obj\n<< /Length $len >>\nstream\n$content\nendstream\nendobj\n";
            $offsets[$pId] = strlen($out);
            $out .= "$pId 0 obj\n<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {$this->w} {$this->h}] /Contents $cId 0 R /Resources << /Font << /F1 $fontId 0 R >> >> >>\nendobj\n";
        }

        $offsets[$fontId] = strlen($out);
        $out .= "$fontId 0 obj\n<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\nendobj\n";

        $xref = strlen($out);
        $max = $fontId;
        $out .= "xref\n0 " . ($max + 1) . "\n0000000000 65535 f \n";
        for ($i = 1; $i <= $max; $i++) {
            $out .= sprintf("%010d 00000 n \n", $offsets[$i] ?? 0);
        }
        $out .= "trailer\n<< /Size " . ($max + 1) . " /Root 1 0 R >>\nstartxref\n$xref\n%%EOF\n";
        return $out;
    }
}
