<?php
/**
 * Types de client SURA
 */
function sulaClientTypes(): array {
    $map = [
        'individu'     => 'ctype_individu',
        'famille'      => 'ctype_famille',
        'couple'       => 'ctype_couple',
        'groupe'       => 'ctype_groupe',
        'association'  => 'ctype_association',
        'entreprise'   => 'ctype_entreprise',
        'institution'  => 'ctype_institution',
        'ecole'        => 'ctype_ecole',
        'hotel'        => 'ctype_hotel',
        'autre'        => 'ctype_autre',
    ];
    $fallback = [
        'individu' => 'Individu / Particulier', 'famille' => 'Famille', 'couple' => 'Couple',
        'groupe' => "Groupe d'amis", 'association' => 'Association / ONG',
        'entreprise' => 'Entreprise / Société', 'institution' => 'Institution / Administration',
        'ecole' => 'École / Université', 'hotel' => 'Hôtel / Hébergement', 'autre' => 'Autre',
    ];
    $out = [];
    foreach ($map as $code => $key) {
        $label = function_exists('t') ? t($key) : $fallback[$code];
        if ($label === $key) $label = $fallback[$code];
        $out[$code] = $label;
    }
    return $out;
}

function sulaClientTypeLabel(?string $code): string {
    if ($code === null || $code === '') return '—';
    $types = sulaClientTypes();
    return $types[$code] ?? $code;
}

function sulaNormalizeClientType(?string $code): string {
    $types = sulaClientTypes();
    $code = strtolower(trim((string)$code));
    return isset($types[$code]) ? $code : 'individu';
}

/** Assure la colonne client_type sur orders / reservations / customers */
function sulaEnsureClientTypeColumn(PDO $pdo): void {
    foreach ([
        "ALTER TABLE orders ADD COLUMN client_type VARCHAR(40) NULL DEFAULT 'individu' AFTER client_name",
        "ALTER TABLE reservations ADD COLUMN client_type VARCHAR(40) NULL DEFAULT 'individu' AFTER client_name",
        "ALTER TABLE customers ADD COLUMN client_type VARCHAR(40) NULL DEFAULT 'individu' AFTER name",
        "ALTER TABLE customers ADD COLUMN organization VARCHAR(150) NULL AFTER client_type",
    ] as $sql) {
        try { $pdo->exec($sql); } catch (Exception $e) {}
    }
}
