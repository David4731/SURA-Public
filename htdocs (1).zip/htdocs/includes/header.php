<?php
if (!isset($pageTitle)) $pageTitle = t('app_name');
$user = currentUser();
$flags = langFlags();
$cur = currentLang();
// Session journalière automatique (1 jour = 1 session)
try {
    require_once __DIR__ . '/session_day.php';
    $sulaSession = sulaEnsureTodaySession(getPDO(), $user['id'] ?? null);
    $sulaSessionLabel = sulaCurrentSessionLabel(getPDO());
} catch (Exception $e) {
    $sulaSessionLabel = 'Session ' . date('d/m/Y');
}

// Detect current page for active nav
$script = basename($_SERVER['SCRIPT_NAME'] ?? '');
$activeNav = 'dashboard';
if (strpos($script, 'menu') !== false || strpos($script, 'stock') !== false) $activeNav = 'menu-stock';
elseif (strpos($script, 'reservation') !== false) $activeNav = 'reservations';
elseif (strpos($script, 'events') !== false) $activeNav = 'events';
elseif (strpos($script, 'order') !== false) $activeNav = 'orders';
elseif (strpos($script, 'report') !== false || strpos($script, 'invoice') !== false || strpos($script, 'expense') !== false) $activeNav = 'reports';
elseif (strpos($script, 'station') !== false || strpos($script, 'kitchen') !== false) $activeNav = 'stations';
elseif (strpos($script, 'user') !== false || strpos($script, 'event') !== false) $activeNav = 'admin';
?>
<!DOCTYPE html>
<html lang="<?= $cur ?>" class="h-full" data-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
  <title><?= htmlspecialchars($pageTitle) ?> · SURA Luxury RMS</title>
  <!-- Tailwind CSS CDN -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- FontAwesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <!-- Bootstrap Icons (legacy) -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <!-- Google Fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Bootstrap (for forms/modals compatibility) -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/css/style.css" rel="stylesheet">

  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            gold: {
              300: '#f6e05e',
              400: '#ecc94b',
              500: '#d4af37',
              600: '#b78a28',
              700: '#976e1a',
            },
            onyx: {
              800: '#1A1A1E',
              900: '#121215',
              950: '#0A0A0C',
            }
          },
          fontFamily: {
            serif: ['Playfair Display', 'serif'],
            sans: ['Plus Jakarta Sans', 'sans-serif'],
          }
        }
      }
    }
  </script>
  <style>
    ::-webkit-scrollbar { width: 6px; height: 6px; }
    ::-webkit-scrollbar-track { background: rgba(18, 18, 21, 0.6); }
    ::-webkit-scrollbar-thumb { background: rgba(212, 175, 55, 0.3); border-radius: 4px; }
    ::-webkit-scrollbar-thumb:hover { background: rgba(212, 175, 55, 0.6); }
    .glass-card {
      background: rgba(26, 26, 30, 0.72);
      backdrop-filter: blur(16px);
      -webkit-backdrop-filter: blur(16px);
      border: 1px solid rgba(212, 175, 55, 0.15);
    }
    .glass-card-gold {
      background: linear-gradient(135deg, rgba(212, 175, 55, 0.12) 0%, rgba(26, 26, 30, 0.8) 100%);
      backdrop-filter: blur(16px);
      border: 1px solid rgba(212, 175, 55, 0.3);
    }
    .glass-nav {
      background: rgba(10, 10, 12, 0.85);
      backdrop-filter: blur(20px);
      border-bottom: 1px solid rgba(212, 175, 55, 0.2);
    }
    .gold-gradient-text {
      background: linear-gradient(135deg, #FFF1C5 0%, #D4AF37 50%, #976E1A 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      background-clip: text;
    }
    .gold-border-glow { box-shadow: 0 0 15px rgba(212, 175, 55, 0.2); }
    /* Bootstrap override for dark luxury */
    body { background: #0A0A0C !important; color: #f1f5f9 !important; font-family: 'Plus Jakarta Sans', sans-serif !important; }
    .form-control, .form-select { background: #0A0A0C !important; border-color: rgba(212,175,55,0.25) !important; color: #f1f5f9 !important; border-radius: 12px !important; }
    .form-control:focus, .form-select:focus { border-color: #d4af37 !important; box-shadow: 0 0 0 3px rgba(212,175,55,0.15) !important; }
    .btn-primary, .btn-danger { background: linear-gradient(135deg, #b78a28, #d4af37) !important; border: none !important; color: #0A0A0C !important; font-weight: 700; border-radius: 12px !important; }
    .btn-outline-primary, .btn-outline-danger, .btn-outline-light { border-color: rgba(212,175,55,0.4) !important; color: #d4af37 !important; border-radius: 12px !important; }
    .btn-outline-primary:hover, .btn-outline-danger:hover { background: rgba(212,175,55,0.15) !important; color: #f6e05e !important; }
    .table { --bs-table-bg: transparent; --bs-table-color: #e2e8f0; color: #e2e8f0; }
    .table th { color: #94a3b8; font-size: 0.7rem; text-transform: uppercase; letter-spacing: 0.05em; border-color: rgba(212,175,55,0.12) !important; }
    .table td { border-color: rgba(212,175,55,0.08) !important; }
    .card { background: rgba(26,26,30,0.72) !important; border: 1px solid rgba(212,175,55,0.15) !important; border-radius: 16px !important; color: #f1f5f9 !important; }
    .modal-content { background: rgba(26,26,30,0.95) !important; border: 1px solid rgba(212,175,55,0.3) !important; color: #f1f5f9; border-radius: 16px !important; }

    /* Fix modals trapped in overflow parents */
    .modal { z-index: 200000 !important; }
    .modal-backdrop { z-index: 199990 !important; }
    .modal.show { display: block !important; pointer-events: auto !important; }
    .modal-dialog { pointer-events: auto !important; z-index: 200001 !important; }
    .modal-content, .modal-content * { pointer-events: auto !important; }
    .modal-body input, .modal-body select, .modal-body textarea, .modal-body button {
      pointer-events: auto !important;
      position: relative;
      z-index: 200002;
    }
    #sulaApproveModal {
      z-index: 200000 !important;
      pointer-events: auto !important;
    }
    #sulaApproveModal > div {
      pointer-events: auto !important;
      position: relative;
      z-index: 200001;
    }
    #sulaApproveModal input, #sulaApproveModal select, #sulaApproveModal button, #sulaApproveModal label {
      pointer-events: auto !important;
    }

    .alert-danger { background: rgba(239,68,68,0.12); border-color: rgba(239,68,68,0.25); color: #fca5a5; }
    .alert-success { background: rgba(16,185,129,0.12); border-color: rgba(16,185,129,0.25); color: #6ee7b7; }
    .badge.bg-light { background: rgba(212,175,55,0.15) !important; color: #d4af37 !important; }
    .nav-btn.active, .nav-btn:hover { color: #d4af37 !important; background: rgba(212,175,55,0.1); }
  </style>

  <style id="sura-theme-css">
    /* DARK (default) */
    html[data-theme="dark"] body { background: #0A0A0C !important; color: #f1f5f9 !important; }
    /* LIGHT */
    html[data-theme="light"] body {
      background: #f3efe6 !important;
      color: #1c1917 !important;
    }
    html[data-theme="light"] body::before { opacity: 0.03 !important; }
    html[data-theme="light"] .glass-nav,
    html[data-theme="light"] .glass-card,
    html[data-theme="light"] .card,
    html[data-theme="light"] .stat-card,
    html[data-theme="light"] .glass-card-gold {
      background: #ffffff !important;
      border-color: rgba(183,138,40,0.28) !important;
      color: #1c1917 !important;
      box-shadow: 0 4px 20px rgba(0,0,0,0.06) !important;
    }
    html[data-theme="light"] .text-slate-100,
    html[data-theme="light"] .text-slate-200,
    html[data-theme="light"] .text-slate-300,
    html[data-theme="light"] h1,
    html[data-theme="light"] h2,
    html[data-theme="light"] h3,
    html[data-theme="light"] h4,
    html[data-theme="light"] h5 {
      color: #1c1917 !important;
    }
    html[data-theme="light"] .text-slate-400,
    html[data-theme="light"] .text-slate-500,
    html[data-theme="light"] .text-muted {
      color: #78716c !important;
    }
    html[data-theme="light"] input,
    html[data-theme="light"] select,
    html[data-theme="light"] textarea,
    html[data-theme="light"] .form-control,
    html[data-theme="light"] .form-select,
    html[data-theme="light"] .sula-search {
      background: #fff !important;
      color: #1c1917 !important;
      border-color: rgba(183,138,40,0.4) !important;
    }
    html[data-theme="light"] .table,
    html[data-theme="light"] .table td,
    html[data-theme="light"] .table th {
      color: #1c1917 !important;
    }
    html[data-theme="light"] .table thead th {
      background: #faf7f2 !important;
    }
    html[data-theme="light"] footer {
      background: #fff !important;
      color: #57534e !important;
      border-color: rgba(183,138,40,0.2) !important;
    }
    html[data-theme="light"] .nav-btn { color: #57534e !important; }
    html[data-theme="light"] .nav-btn.text-gold-400,
    html[data-theme="light"] .nav-btn:hover { color: #b78a28 !important; }
    html[data-theme="light"] .bg-onyx-900\/80,
    html[data-theme="light"] .bg-onyx-900\/90,
    html[data-theme="light"] [class*="bg-onyx"] {
      background-color: #ffffff !important;
    }
    html[data-theme="light"] #notifDropdown,
    html[data-theme="light"] #sulaApproveModal > div {
      background: #fff !important;
      color: #1c1917 !important;
    }
    html[data-theme="light"] .dropdown-menu {
      background: #fff !important;
      color: #1c1917 !important;
    }
    html[data-theme="light"] .dropdown-item { color: #1c1917 !important; }
    html[data-theme="light"] .dropdown-item:hover { background: #f5f0e6 !important; }
    .dropdown-menu { z-index: 300002 !important; }
  .dropdown { z-index: 300000; }
  header.glass-nav { z-index: 100000; position: relative; }
</style>

</head>
<body class="bg-onyx-950 text-slate-100 font-sans h-full overflow-x-hidden flex flex-col relative selection:bg-gold-500 selection:text-black">
<script>
(function(){
  try {
    var th = localStorage.getItem('sura-theme') || 'dark';
    document.documentElement.setAttribute('data-theme', th);
  } catch(e) {
    document.documentElement.setAttribute('data-theme', 'dark');
  }
})();
</script>

  <!-- Background Image with Overlay -->
  <div class="fixed inset-0 z-0 pointer-events-none">
    <img src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=2000&q=80" alt="Luxury Interior" class="w-full h-full object-cover opacity-20 filter saturate-150">
    <div class="absolute inset-0 bg-gradient-to-t from-onyx-950 via-onyx-950/80 to-onyx-950/60"></div>
  </div>

  <!-- App Wrapper -->
  <div class="relative z-10 flex flex-col h-screen overflow-hidden">

    <!-- TOP NAVBAR -->
    <header class="glass-nav h-20 px-4 md:px-8 flex items-center justify-between shrink-0 relative" style="z-index:100000">
      <!-- Logo & Title -->
      <div class="flex items-center space-x-4">
        <div class="w-12 h-12 rounded-full border border-gold-500/50 flex items-center justify-center bg-onyx-900 shadow-lg gold-border-glow overflow-hidden p-0.5">
          <img src="/assets/img/sura-logo.png" alt="SURA" class="w-full h-full object-contain">
        </div>
        <div>
          <h1 class="font-serif text-xl md:text-2xl font-bold tracking-wide gold-gradient-text">SURA <span class="text-xs font-sans tracking-widest text-gold-400 font-normal uppercase block md:inline md:ml-2">Luxury RMS</span></h1>
          <p class="text-xs text-slate-400 hidden sm:block">Restaurant & Stock Operations Center</p>
        </div>
      </div>

      <!-- Right Action Items -->
      <div class="flex items-center space-x-2 md:space-x-4">
        <!-- Global Search -->
        <form action="/pages/orders.php" method="get" class="hidden md:flex items-center relative">
          <i class="fa-solid fa-magnifying-glass absolute left-3 text-gold-500/70 text-xs pointer-events-none"></i>
          <input type="search" name="q" value="<?= htmlspecialchars($_GET['q'] ?? '') ?>"
            placeholder="<?= htmlspecialchars(t('search_placeholder')) ?>"
            class="sula-search bg-onyx-900/90 border border-gold-500/25 rounded-full pl-9 pr-4 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-gold-400 w-52 lg:w-64 transition-all">
        </form>
        <!-- Mobile search icon -->
        <a href="/pages/orders.php" class="md:hidden p-2.5 rounded-full bg-onyx-900/80 border border-gold-500/30 text-gold-400" title="Recherche">
          <i class="fa-solid fa-magnifying-glass"></i>
        </a>
        <!-- Theme toggle -->
        <button type="button" id="themeToggle" class="p-2.5 rounded-full bg-onyx-900/80 border border-gold-500/30 text-gold-400 hover:text-white hover:border-gold-400 transition-all" title="<?= htmlspecialchars(t('theme_toggle')) ?>">
          <i class="fa-solid fa-sun text-lg" id="themeIconSun"></i>
          <i class="fa-solid fa-moon text-lg hidden" id="themeIconMoon"></i>
        </button>
        <!-- Session jour -->
        <div class="hidden lg:flex items-center bg-onyx-900/90 border border-emerald-500/30 rounded-full px-3 py-1.5 text-xs" id="sessionBadge" title="1 jour = 1 session de service">
          <i class="fa-solid fa-calendar-day text-emerald-400 mr-1.5"></i>
          <span class="text-emerald-300"><?= htmlspecialchars($sulaSessionLabel ?? ('Session '.date('d/m/Y'))) ?></span>
        </div>
        <!-- Role Badge -->
        <div class="hidden lg:flex items-center bg-onyx-900/90 border border-gold-500/30 rounded-full px-3 py-1.5 text-xs">
          <span class="text-slate-400 mr-2"><i class="fa-solid fa-user-shield text-gold-500 mr-1"></i> <?= t('role') ?>:</span>
          <span class="text-gold-400 font-semibold"><?= htmlspecialchars(roleLabel($user['role'])) ?></span>
        </div>

        <?php if (in_array($user['role'], ['admin','checker'])): ?>
        <button type="button" id="btnSessionReset" title="Réinitialiser la session du jour" class="hidden lg:flex items-center bg-onyx-900/90 border border-amber-500/40 rounded-full px-3 py-1.5 text-xs text-amber-400 hover:bg-amber-500/10 transition-all">
          <i class="fa-solid fa-rotate-left mr-1.5"></i> <?= t('session_day') ?>
        </button>
        <?php endif; ?>
<button type="button" id="notifBell" class="relative p-2.5 rounded-full bg-onyx-900/80 border border-gold-500/30 text-gold-400 hover:text-white hover:border-gold-400 transition-all" title="<?= htmlspecialchars(t('notifications')) ?>">
          <i class="fa-solid fa-bell text-lg"></i>
          <span class="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center hidden" id="unreadNotifCount">0</span>
        </button>

        <!-- Language — toujours au premier plan -->
        <div class="dropdown" style="position:relative;z-index:300000">
          <button class="p-2.5 rounded-full bg-onyx-900/80 border border-gold-500/30 text-gold-400 hover:text-white hover:border-gold-400 transition-all text-sm" data-bs-toggle="dropdown" data-bs-display="static" style="position:relative;z-index:300001">
            <?= $flags[$cur] ?? '🌐' ?>
          </button>
          <ul class="dropdown-menu dropdown-menu-end shadow border-0 rounded-xl" style="background:#121215;border:1px solid rgba(212,175,55,0.2)!important;z-index:300002!important;position:absolute">
            <?php foreach ($flags as $code => $label):
                $href = function_exists('sulaLangUrl') ? sulaLangUrl($code) : ('?lang=' . urlencode($code));
            ?>
              <li>
                <a class="dropdown-item <?= $code === $cur ? 'active' : '' ?>" style="color:#e2e8f0" href="<?= htmlspecialchars($href) ?>">
                  <?= $label ?>
                </a>
              </li>
            <?php endforeach; ?>
          </ul>
        </div>

        <!-- User Profile -->
        <div class="flex items-center space-x-3 border-l border-gold-500/20 pl-4">
          <div class="w-10 h-10 rounded-full border-2 border-gold-500/60 bg-onyx-900 flex items-center justify-center text-gold-400 font-serif font-bold">
            <?= strtoupper(mb_substr($user['name'], 0, 1)) ?>
          </div>
          <div class="hidden md:block">
            <p class="text-sm font-semibold text-slate-200 leading-none"><?= htmlspecialchars($user['name']) ?></p>
            <p class="text-[11px] text-gold-400 mt-1"><?= htmlspecialchars(roleLabel($user['role'])) ?></p>
          </div>
          <a href="/logout.php" class="p-2 rounded-full text-slate-400 hover:text-gold-400 transition-all" title="<?= t('logout') ?>">
            <i class="fa-solid fa-right-from-bracket"></i>
          </a>
        </div>
      </div>
    </header>

    <!-- BODY CONTAINER WITH SIDEBAR & MAIN CONTENT -->
    <div class="flex flex-1 overflow-hidden">

      <!-- NAVIGATION SIDEBAR -->
      <aside id="sulaSidebar" class="sula-sidebar w-20 md:w-64 glass-nav border-r border-gold-500/15 flex flex-col justify-between py-6 shrink-0 transition-all">
        <nav class="space-y-2 px-3">
          <a href="/pages/dashboard.php" class="nav-btn w-full flex items-center space-x-3 px-3 py-3 rounded-xl transition-all <?= $activeNav==='dashboard' ? 'text-gold-400 bg-gold-500/15 border border-gold-500/30' : 'text-slate-400 hover:text-gold-400 hover:bg-gold-500/10' ?>">
            <i class="fa-solid fa-chart-pie text-xl w-6 text-center"></i>
            <span class="hidden md:inline font-medium text-sm"><?= t('dashboard') ?></span>
          </a>

          <?php if (in_array($user['role'], ['stock_manager','admin'])): ?>
          <a href="/pages/menus.php" class="nav-btn w-full flex items-center space-x-3 px-3 py-3 rounded-xl transition-all <?= $activeNav==='menu-stock' ? 'text-gold-400 bg-gold-500/15 border border-gold-500/30' : 'text-slate-400 hover:text-gold-400 hover:bg-gold-500/10' ?>">
            <i class="fa-solid fa-utensils text-xl w-6 text-center"></i>
            <span class="hidden md:inline font-medium text-sm"><?= t('menus') ?></span>
          </a>
          <?php endif; ?>

          <?php if (in_array($user['role'], ['server','checker','admin'])): ?>
          <a href="/pages/orders.php" class="nav-btn w-full flex items-center space-x-3 px-3 py-3 rounded-xl transition-all <?= $activeNav==='orders' ? 'text-gold-400 bg-gold-500/15 border border-gold-500/30' : 'text-slate-400 hover:text-gold-400 hover:bg-gold-500/10' ?>">
            <i class="fa-solid fa-receipt text-xl w-6 text-center"></i>
            <span class="hidden md:inline font-medium text-sm"><?= t('orders') ?></span>
          </a>
          <?php endif; ?>
<?php if (in_array($user['role'], ['checker','admin'])): ?>
          <a href="/pages/reservations.php" class="nav-btn w-full flex items-center space-x-3 px-3 py-3 rounded-xl transition-all <?= $activeNav==='reservations' ? 'text-gold-400 bg-gold-500/15 border border-gold-500/30' : 'text-slate-400 hover:text-gold-400 hover:bg-gold-500/10' ?>">
            <i class="fa-solid fa-chair text-xl w-6 text-center"></i>
            <span class="hidden md:inline font-medium text-sm"><?= t('reservations') ?></span>
          </a>
          <a href="/pages/events.php" class="nav-btn w-full flex items-center space-x-3 px-3 py-3 rounded-xl transition-all <?= $activeNav==='events' ? 'text-gold-400 bg-gold-500/15 border border-gold-500/30' : 'text-slate-400 hover:text-gold-400 hover:bg-gold-500/10' ?>">
            <i class="fa-solid fa-champagne-glasses w-5 text-center"></i>
            <span class="hidden md:inline font-medium text-sm"><?= t('events') ?></span>
          </a>
          <?php endif; ?>

          <?php if (in_array($user['role'], ['kitchen','checker','admin','server','stock_manager'])): ?>
          <a href="/pages/station.php?type=kitchen" class="nav-btn w-full flex items-center space-x-3 px-3 py-3 rounded-xl transition-all <?= $activeNav==='stations' ? 'text-gold-400 bg-gold-500/15 border border-gold-500/30' : 'text-slate-400 hover:text-gold-400 hover:bg-gold-500/10' ?>">
            <i class="fa-solid fa-fire text-xl w-6 text-center"></i>
            <span class="hidden md:inline font-medium text-sm"><?= t('stations') ?></span>
          </a>
          <?php endif; ?>

          <?php if (in_array($user['role'], ['accountant','admin','checker'])): ?>
          <a href="/pages/reports.php" class="nav-btn w-full flex items-center space-x-3 px-3 py-3 rounded-xl transition-all <?= $activeNav==='reports' ? 'text-gold-400 bg-gold-500/15 border border-gold-500/30' : 'text-slate-400 hover:text-gold-400 hover:bg-gold-500/10' ?>">
            <i class="fa-solid fa-chart-line text-xl w-6 text-center"></i>
            <span class="hidden md:inline font-medium text-sm"><?= t('reports') ?></span>
          </a>
          <?php endif; ?>

          <?php if ($user['role'] === 'admin'): ?>
          <a href="/pages/users.php" class="nav-btn w-full flex items-center space-x-3 px-3 py-3 rounded-xl transition-all <?= $activeNav==='admin' ? 'text-gold-400 bg-gold-500/15 border border-gold-500/30' : 'text-slate-400 hover:text-gold-400 hover:bg-gold-500/10' ?>">
            <i class="fa-solid fa-users-gear text-xl w-6 text-center"></i>
            <span class="hidden md:inline font-medium text-sm"><?= t('admin_panel') ?></span>
          </a>
          <a href="/pages/spaces.php" class="nav-btn w-full flex items-center space-x-3 px-3 py-3 rounded-xl transition-all <?= $activeNav==='spaces' ? 'text-gold-400 bg-gold-500/15 border border-gold-500/30' : 'text-slate-400 hover:text-gold-400 hover:bg-gold-500/10' ?>">
            <i class="fa-solid fa-chair text-xl w-6 text-center"></i>
            <span class="hidden md:inline font-medium text-sm">Tables & Partitions</span>
          </a>
          <?php endif; ?>
        </nav>

        <!-- Quick Status Card -->
        <div class="px-3 hidden md:block space-y-3">
          <div class="glass-card-gold p-4 rounded-2xl text-xs space-y-2">
            <div class="flex items-center justify-between text-gold-300 font-semibold">
              <span><?= t('service') ?></span>
              <span class="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <span class="w-1.5 h-1.5 bg-emerald-400 rounded-full mr-1.5 animate-pulse"></span><?= t('service_active') ?>
              </span>
            </div>
            <p class="text-slate-400 leading-relaxed">SURA · Olympia Tanjombato<br><span class="text-gold-500/80">MVola 038 24 541 74</span></p>
          </div>
          <div class="flex justify-center gap-3 text-slate-500">
            <a href="https://wa.me/261382454174" target="_blank" class="hover:text-gold-400 transition-colors" title="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
            <a href="https://www.facebook.com/David.Herinantenaina" target="_blank" class="hover:text-gold-400 transition-colors" title="Facebook"><i class="fa-brands fa-facebook"></i></a>
            <a href="https://www.instagram.com/herinantenaina.david" target="_blank" class="hover:text-gold-400 transition-colors" title="Instagram"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://www.tiktok.com/@herinantenaina.david" target="_blank" class="hover:text-gold-400 transition-colors" title="TikTok"><i class="fa-brands fa-tiktok"></i></a>
          </div>
        </div>
      </aside>

      <!-- MAIN CONTENT AREA -->
      <main class="flex-1 overflow-y-auto p-4 md:p-8 space-y-6 sula-main">


<!-- Notifications panel -->
<div id="notifDropdown" class="hidden fixed top-20 right-4 z-50 w-96 max-h-[32rem] overflow-hidden glass-card rounded-2xl border border-gold-500/30 shadow-2xl flex flex-col">
  <div class="p-3 border-b border-gold-500/20 flex items-center justify-between shrink-0">
    <h4 class="font-serif text-sm font-bold text-gold-300"><?= t('notifications') ?></h4>
    <div class="flex items-center gap-2">
      <button type="button" id="notifMarkAll" class="text-[10px] text-gold-400 hover:underline"><?= t('mark_all_read') ?></button>
      <button type="button" id="notifClose" class="text-slate-400 hover:text-white text-sm"><i class="fa-solid fa-xmark"></i></button>
    </div>
  </div>
  <div id="notifList" class="overflow-y-auto flex-1 p-2 space-y-2 max-h-80"></div>
  <div id="notifDetail" class="hidden border-t border-gold-500/20 p-4 bg-onyx-900/80 space-y-3">
    <div class="flex justify-between items-start gap-2">
      <h5 id="notifDetailTitle" class="font-serif text-sm font-bold text-gold-300"></h5>
      <button type="button" id="notifDetailBack" class="text-[10px] text-slate-400 hover:text-gold-400">← Liste</button>
    </div>
    <p id="notifDetailBody" class="text-xs text-slate-300 leading-relaxed"></p>
    <p id="notifDetailMeta" class="text-[10px] text-slate-500"></p>
    <div class="flex gap-2 pt-1">
      <button type="button" id="notifDetailRead" class="text-[10px] px-3 py-1.5 rounded-lg bg-gold-500/20 text-gold-400 border border-gold-500/30 hover:bg-gold-500/30"><?= t('mark_read') ?></button>
      <button type="button" id="notifDetailDelete" class="text-[10px] px-3 py-1.5 rounded-lg bg-red-500/15 text-red-400 border border-red-500/30 hover:bg-red-500/25"><?= t('delete') ?></button>
    </div>
  </div>
</div>
<script>
(function(){
  var notifs = [];
  var i18nNoNotif = <?= json_encode(t('no_notifications'), JSON_UNESCAPED_UNICODE) ?>;
  var currentId = null;
  var drop = document.getElementById('notifDropdown');
  var listEl = document.getElementById('notifList');
  var detailEl = document.getElementById('notifDetail');

  function escapeHtml(s){ var d=document.createElement('div'); d.textContent=s||''; return d.innerHTML; }

  function updateBadge(n) {
    var el = document.getElementById('unreadNotifCount');
    if (!el) return;
    if (n > 0) { el.textContent = n > 9 ? '9+' : n; el.classList.remove('hidden'); }
    else el.classList.add('hidden');
  }

  function renderList() {
    listEl.innerHTML = '';
    detailEl.classList.add('hidden');
    listEl.classList.remove('hidden');
    if (!notifs.length) {
      listEl.innerHTML = '<p class="text-xs text-slate-400 p-3 text-center">' + i18nNoNotif + '</p>';
      return;
    }
    notifs.forEach(function(n){
      var unread = !parseInt(n.is_read, 10);
      var div = document.createElement('div');
      div.className = 'p-3 rounded-xl border cursor-pointer transition-all ' +
        (unread ? 'bg-gold-500/10 border-gold-500/30' : 'bg-onyx-900/80 border-gold-500/10 hover:border-gold-500/25');
      div.innerHTML =
        '<div class="flex justify-between items-start gap-2">' +
          '<p class="text-xs font-semibold ' + (unread ? 'text-slate-100' : 'text-slate-300') + '">' + escapeHtml(n.title) + '</p>' +
          (unread ? '<span class="w-2 h-2 rounded-full bg-gold-400 shrink-0 mt-1"></span>' : '') +
        '</div>' +
        '<p class="text-[11px] text-slate-400 mt-1 line-clamp-2">' + escapeHtml(n.body || '') + '</p>' +
        '<p class="text-[10px] text-slate-500 mt-1">' + escapeHtml(n.created_at || '') + '</p>';
      div.addEventListener('click', function(){ openDetail(n.id); });
      listEl.appendChild(div);
    });
  }

  function openDetail(id) {
    var n = notifs.find(function(x){ return String(x.id) === String(id); });
    if (!n) return;
    currentId = n.id;
    listEl.classList.add('hidden');
    detailEl.classList.remove('hidden');
    document.getElementById('notifDetailTitle').textContent = n.title || '';
    document.getElementById('notifDetailBody').textContent = n.body || '—';
    document.getElementById('notifDetailMeta').textContent =
      (n.type ? ('Type : ' + n.type + ' · ') : '') + (n.created_at || '');
    if (!parseInt(n.is_read, 10)) {
      actionNotif('read', n.id);
    }
  }

  function actionNotif(action, id) {
    fetch('/ajax/notif_action.php', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ action: action, id: id })
    }).then(function(r){ return r.json(); }).then(function(d){
      if (!d.ok) return;
      if (action === 'delete') {
        notifs = notifs.filter(function(x){ return String(x.id) !== String(id); });
        currentId = null;
        renderList();
      } else if (action === 'read') {
        notifs.forEach(function(x){ if (String(x.id) === String(id)) x.is_read = 1; });
      } else if (action === 'read_all') {
        notifs.forEach(function(x){ x.is_read = 1; });
        renderList();
      }
      var unread = notifs.filter(function(x){ return !parseInt(x.is_read,10); }).length;
      updateBadge(unread);
    }).catch(function(){});
  }

  function pollHeader() {
    fetch('/ajax/poll.php')
      .then(function(r){ return r.json(); })
      .then(function(data){
        if (data.error) return;
        notifs = data.notifications || [];
        updateBadge(data.unread || 0);
        if (!drop.classList.contains('hidden') && detailEl.classList.contains('hidden')) {
          renderList();
        }
      }).catch(function(){});
  }

  var bell = document.getElementById('notifBell');
  if (bell) {
    bell.addEventListener('click', function(e){
      e.stopPropagation();
      drop.classList.toggle('hidden');
      if (!drop.classList.contains('hidden')) renderList();
    });
  }
  var closeBtn = document.getElementById('notifClose');
  if (closeBtn) closeBtn.addEventListener('click', function(){ drop.classList.add('hidden'); });
  var backBtn = document.getElementById('notifDetailBack');
  if (backBtn) backBtn.addEventListener('click', function(){ currentId=null; renderList(); });
  var readBtn = document.getElementById('notifDetailRead');
  if (readBtn) readBtn.addEventListener('click', function(){ if(currentId) actionNotif('read', currentId); });
  var delBtn = document.getElementById('notifDetailDelete');
  if (delBtn) delBtn.addEventListener('click', function(){
    if (currentId && confirm(<?= json_encode(t('delete') . '?', JSON_UNESCAPED_UNICODE) ?>)) actionNotif('delete', currentId);
  });
  var markAll = document.getElementById('notifMarkAll');
  if (markAll) markAll.addEventListener('click', function(){ actionNotif('read_all', 0); });

  document.addEventListener('click', function(e){
    if (!drop.contains(e.target) && e.target !== bell && !(bell && bell.contains(e.target))) {
      drop.classList.add('hidden');
    }
  });

  var btn = document.getElementById('btnSessionReset');
  if (btn) {
    btn.addEventListener('click', function(){
      if (!confirm('Réinitialiser la session du jour ?\nToutes les tables seront libérées.')) return;
      fetch('/ajax/session_reset.php', { method: 'POST' })
        .then(function(r){ return r.json(); })
        .then(function(d){
          alert(d.ok ? d.message : (d.error || 'Erreur'));
          if (d.ok) location.reload();
        });
    });
  }

  pollHeader();
  setInterval(pollHeader, 8000);
})();
</script>

<script>

</script>

<script>
(function(){
  function getTheme() {
    try { return localStorage.getItem('sura-theme') || 'dark'; } catch(e) { return 'dark'; }
  }
  function setTheme(th) {
    document.documentElement.setAttribute('data-theme', th);
    try { localStorage.setItem('sura-theme', th); } catch(e) {}
    var sun = document.getElementById('themeIconSun');
    var moon = document.getElementById('themeIconMoon');
    if (sun && moon) {
      if (th === 'light') {
        sun.classList.add('hidden');
        moon.classList.remove('hidden');
      } else {
        sun.classList.remove('hidden');
        moon.classList.add('hidden');
      }
    }
  }
  setTheme(getTheme());
  document.addEventListener('click', function(e) {
    var btn = e.target.closest('#themeToggle');
    if (!btn) return;
    e.preventDefault();
    e.stopPropagation();
    var next = getTheme() === 'light' ? 'dark' : 'light';
    setTheme(next);
  });
})();
</script>
