      </main>
    </div>
  </div>

  <footer class="sula-mobile-footer relative z-10 border-t border-gold-500/15 bg-onyx-950/90 backdrop-blur-md py-5 px-4 md:px-8">
    <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 text-xs text-slate-400">
      <div class="flex items-center gap-3">
        <img src="/assets/img/sura-logo.png" alt="SURA" class="w-9 h-9 object-contain">
        <div>
          <span class="gold-gradient-text font-serif font-semibold text-sm">SURA</span>
          <span class="mx-1">·</span>
          <span>Korean &amp; Malagasy · Olympia Tanjombato</span>
        </div>
      </div>

      <div class="flex flex-wrap items-center gap-2">
        <span class="text-[10px] uppercase tracking-wider text-slate-500 mr-1">
          <?= t('payments') ?>
        </span>
        <span class="pay-brand mvola" title="MVola">
          <i class="fa-solid fa-mobile-screen"></i> MVola
        </span>
        <span class="pay-brand orange">
          <i class="fa-solid fa-mobile"></i> Orange Money
        </span>
        <span class="pay-brand airtel">
          <i class="fa-solid fa-signal"></i> Airtel Money
        </span>
        <span class="pay-brand cash">
          <i class="fa-solid fa-money-bill-wave"></i> Cash
        </span>
        <span class="pay-brand bank">
          <i class="fa-solid fa-building-columns"></i> Virement
        </span>
      </div>

      <div class="flex items-center gap-2">
        <a href="https://wa.me/261382454174" target="_blank" rel="noopener"
           class="social-btn" title="WhatsApp">
          <i class="fa-brands fa-whatsapp"></i>
        </a>
        <a href="https://www.facebook.com/David.Herinantenaina"
           target="_blank" rel="noopener" class="social-btn" title="Facebook">
          <i class="fa-brands fa-facebook-f"></i>
        </a>
        <a href="https://www.instagram.com/herinantenaina.david"
           target="_blank" rel="noopener" class="social-btn" title="Instagram">
          <i class="fa-brands fa-instagram"></i>
        </a>
        <a href="https://www.tiktok.com/@herinantenaina.david"
           target="_blank" rel="noopener" class="social-btn" title="TikTok">
          <i class="fa-brands fa-tiktok"></i>
        </a>
      </div>
    </div>

    <p class="text-center text-[10px] text-slate-600 mt-3">
      MVola : <span class="text-gold-500">038 24 541 74</span>
      · WhatsApp : +261 38 24 541 74
    </p>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <script>
  (function () {
    function reparentModals() {
      document.querySelectorAll(
        '.modal, #sulaApproveModal, #modalReserve, #modalDetails'
      ).forEach(function (el) {
        if (el && el.parentElement !== document.body) {
          document.body.appendChild(el);
        }
      });
    }

    reparentModals();
    document.addEventListener('DOMContentLoaded', reparentModals);
    setTimeout(reparentModals, 100);
    setTimeout(reparentModals, 500);

    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') {
        var modal = document.getElementById('sulaApproveModal');
        if (modal && !modal.classList.contains('hidden')) {
          modal.classList.add('hidden');
          modal.classList.remove('flex');
        }
      }
    });
  })();
  </script>

  <script src="/assets/js/transitions.js"></script>
  <script src="/assets/js/ajax-navigation.js"></script>

  <nav id="sulaMobileNav" class="sula-mobile-nav" aria-label="Navigation mobile" hidden>
    <a href="/pages/dashboard.php" class="sula-mnav-item">
      <i class="fa-solid fa-chart-pie"></i>
      <span><?= t('dashboard') ?></span>
    </a>
    <a href="/pages/orders.php" class="sula-mnav-item">
      <i class="fa-solid fa-receipt"></i>
      <span><?= t('orders') ?></span>
    </a>
    <a href="/pages/menus.php" class="sula-mnav-item">
      <i class="fa-solid fa-utensils"></i>
      <span><?= t('menus') ?></span>
    </a>
    <a href="/pages/reservations.php" class="sula-mnav-item">
      <i class="fa-solid fa-calendar-check"></i>
      <span><?= t('reservations') ?></span>
    </a>
    <a href="/pages/reports.php" class="sula-mnav-item">
      <i class="fa-solid fa-chart-line"></i>
      <span><?= t('reports') ?></span>
    </a>
  </nav>

  <script>
  (function () {
    var nav = document.getElementById('sulaMobileNav');
    if (!nav) return;

    function sync() {
      var mobile = window.matchMedia('(max-width: 767px)').matches;
      nav.hidden = !mobile;
      nav.style.display = mobile ? 'flex' : 'none';
    }

    sync();
    window.addEventListener('resize', sync);
  })();
  </script>

</body>
</html>