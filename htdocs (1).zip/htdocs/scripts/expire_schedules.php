<?php
// CLI-only cron task: expire schedules after their last calendar day.
if (PHP_SAPI !== 'cli') { http_response_code(403); exit("CLI only\n"); }
require_once __DIR__ . '/../config/database.php';
date_default_timezone_set('Indian/Antananarivo');
$pdo = getPDO();
$pdo->exec("UPDATE reservations SET status='completed' WHERE reservation_date < CURDATE() AND status IN ('pending','confirmed')");
$cols = $pdo->query('SHOW COLUMNS FROM events')->fetchAll(PDO::FETCH_COLUMN);
$endCol = in_array('end_date', $cols, true) ? 'end_date' : 'event_date';
$pdo->exec("UPDATE events SET status='done' WHERE COALESCE(NULLIF($endCol,''),event_date) < CURDATE() AND status IN ('planned','confirmed')");
echo "Schedules expired at ".date('Y-m-d H:i:s')."\n";
