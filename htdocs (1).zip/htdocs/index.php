<?php
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/includes/auth.php';

if (isLoggedIn()) {
    header('Location: /pages/dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    try {
        $pdo = getPDO();
        $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ? AND status = 1 LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();
        if ($user && (password_verify($password, $user['password']))) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            header('Location: /pages/dashboard.php');
            exit;
        }
        $error = 'Email ou mot de passe incorrect.';
    } catch (Exception $e) {
        $error = 'Erreur de connexion à la base. Vérifiez config/database.php';
    }
}

$flags = langFlags();
$cur = currentLang();
?>
<!DOCTYPE html>
<html lang="<?= $cur ?>" class="h-full">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= t('login') ?> · SURA Luxury RMS</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: { 300:'#f6e05e', 400:'#ecc94b', 500:'#d4af37', 600:'#b78a28', 700:'#976e1a' },
            onyx: { 800:'#1A1A1E', 900:'#121215', 950:'#0A0A0C' }
          },
          fontFamily: {
            serif: ['Playfair Display', 'serif'],
            sans: ['Plus Jakarta Sans', 'sans-serif'],
          }
        }
      }
    }
  </script>
  <style>
    .gold-gradient-text {
      background: linear-gradient(135deg, #FFF1C5 0%, #D4AF37 50%, #976E1A 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }
    .glass-card-gold {
      background: linear-gradient(135deg, rgba(212, 175, 55, 0.12) 0%, rgba(26, 26, 30, 0.85) 100%);
      backdrop-filter: blur(20px);
      border: 1px solid rgba(212, 175, 55, 0.3);
    }
  .pay-brand{display:inline-flex;align-items:center;gap:.25rem;padding:.3rem.55rem;border-radius:999px;font-size:.65rem;font-weight:700;border:1px solid transparent}
.pay-brand.mvola{background:rgba(16,185,129,.15);color:#34d399;border-color:rgba(16,185,129,.3)}
.pay-brand.orange{background:rgba(249,115,22,.15);color:#fb923c;border-color:rgba(249,115,22,.3)}
.pay-brand.airtel{background:rgba(239,68,68,.15);color:#f87171;border-color:rgba(239,68,68,.3)}
</style>
  <link href="/assets/css/style.css" rel="stylesheet">

<style id="sura-theme-css">
html[data-theme="light"] body { background: #f3efe6 !important; color: #1c1917 !important; }
html[data-theme="light"] .glass-card, html[data-theme="light"] [class*="bg-onyx"] { background: #fff !important; color: #1c1917 !important; }
html[data-theme="light"] input, html[data-theme="light"] .form-control { background:#fff!important;color:#1c1917!important; }
</style>
<script>
(function(){try{var th=localStorage.getItem('sura-theme')||'dark';document.documentElement.setAttribute('data-theme',th);}catch(e){document.documentElement.setAttribute('data-theme','dark');}})();
</script>
</head>
<script>
(function(){try{var th=localStorage.getItem('sura-theme')||'dark';document.documentElement.setAttribute('data-theme',th);document.documentElement.classList.toggle('theme-light',th==='light');}catch(e){}})();
</script>
<body class="bg-onyx-950 text-slate-100 font-sans min-h-screen flex items-center justify-center relative">
  <div class="fixed inset-0 z-0 pointer-events-none">
    <img src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=2000&q=80" alt="" class="w-full h-full object-cover opacity-20 saturate-150">
    <div class="absolute inset-0 bg-gradient-to-t from-onyx-950 via-onyx-950/80 to-onyx-950/60"></div>
  </div>

  <div class="relative z-10 w-full max-w-md px-4">
    <div class="glass-card-gold rounded-2xl overflow-hidden shadow-2xl">
      <div class="p-8 text-center border-b border-gold-500/20">
        <div class="w-20 h-20 mx-auto rounded-full border border-gold-500/50 flex items-center justify-center bg-onyx-900 shadow-lg overflow-hidden p-1" style="box-shadow:0 0 20px rgba(212,175,55,0.25)">
          <img src="/assets/img/sura-logo.png" alt="SURA" class="w-full h-full object-contain">
        </div>
        <h1 class="font-serif text-3xl font-bold gold-gradient-text mt-4 tracking-wide">SURA</h1>
        <p class="text-xs tracking-widest text-gold-400 uppercase mt-1">Luxury RMS</p>
        <p class="text-slate-400 text-sm mt-2"><?= t('tagline') ?></p>
      </div>
      <div class="p-6 space-y-4">
        <div class="flex justify-end">
          <div class="relative">
            <select onchange="location.href='?lang='+this.value" class="bg-onyx-950 border border-gold-500/30 rounded-lg px-3 py-1.5 text-xs text-gold-400 focus:outline-none">
              <?php foreach ($flags as $code => $label): ?>
                <option value="<?= $code ?>" <?= $code===$cur?'selected':'' ?> class="bg-onyx-900"><?= $label ?></option>
              <?php endforeach; ?>
            </select>
          </div>
        </div>

        <?php if ($error): ?>
          <div class="bg-red-500/10 border border-red-500/30 text-red-300 text-sm rounded-xl px-4 py-2.5"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="post" class="space-y-4">
          <div>
            <label class="block text-xs text-slate-400 mb-1.5 uppercase tracking-wider">Email</label>
            <div class="relative">
              <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gold-500"><i class="fa-solid fa-envelope text-sm"></i></span>
              <input type="email" name="email" required placeholder="admin@sula.mg"
                class="w-full bg-onyx-950 border border-gold-500/30 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white focus:outline-none focus:border-gold-400">
            </div>
          </div>
          <div>
            <label class="block text-xs text-slate-400 mb-1.5 uppercase tracking-wider">Mot de passe</label>
            <div class="relative">
              <span class="absolute left-3 top-1/2 -translate-y-1/2 text-gold-500"><i class="fa-solid fa-lock text-sm"></i></span>
              <input type="password" name="password" required placeholder="••••••••"
                class="w-full bg-onyx-950 border border-gold-500/30 rounded-xl pl-10 pr-4 py-2.5 text-sm text-white focus:outline-none focus:border-gold-400">
            </div>
          </div>
          <button type="submit" class="w-full bg-gradient-to-r from-gold-600 to-gold-400 text-onyx-950 font-bold py-3 rounded-xl hover:brightness-110 transition-all flex items-center justify-center space-x-2">
            <i class="fa-solid fa-right-to-bracket"></i>
            <span><?= t('login') ?></span>
          </button>
        </form>

        <p class="text-center text-xs text-slate-500 pt-2">
          Demo : <span class="text-gold-400">admin@sula.mg</span> / <span class="text-gold-400">password</span>
        </p>
        <p class="text-center pt-3">
          <a href="/client/index.php" class="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-gold-500/40 text-gold-400 text-sm hover:bg-gold-500/10 transition-all">
            <i class="fa-solid fa-utensils"></i> Espace client
          </a>
        </p>
        <div class="flex flex-wrap justify-center gap-1.5 pt-2">
          <span class="pay-brand mvola">MVola</span>
          <span class="pay-brand orange">Orange Money</span>
          <span class="pay-brand airtel">Airtel Money</span>
        </div>
        <div class="flex justify-center items-center gap-4 pt-3 text-slate-400">
          <span class="text-[11px] text-gold-400 font-semibold">MVola 038 24 541 74</span>
          <a href="https://wa.me/261382454174" target="_blank" class="hover:text-gold-400"><i class="fa-brands fa-whatsapp"></i></a>
          <a href="https://www.facebook.com/David.Herinantenaina" target="_blank" class="hover:text-gold-400"><i class="fa-brands fa-facebook"></i></a>
          <a href="https://www.instagram.com/herinantenaina.david" target="_blank" class="hover:text-gold-400"><i class="fa-brands fa-instagram"></i></a>
          <a href="https://www.tiktok.com/@herinantenaina.david" target="_blank" class="hover:text-gold-400"><i class="fa-brands fa-tiktok"></i></a>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
