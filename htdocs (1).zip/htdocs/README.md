# SURA Luxury Restaurant Management System

Version intégrée pour le restaurant SURA — interface Onyx & Gold, avec affichage des plats adaptatif :
- **Téléphone** : une fiche par ligne, image à gauche et détails à droite.
- **Tablette** : grille de deux colonnes.
- **PC** : grille responsive de trois colonnes ou davantage selon la largeur.

## Fonctionnalités incluses

- Gestion du restaurant et des utilisateurs par rôles.
- Menus, prix, images et stock.
- Commandes sur place et commandes de livraison.
- Réservations, espaces/tables, cuisine, factures et paiements.
- Dépenses, événements, rapports et exportations disponibles dans l'application.
- Interface multilingue : français, anglais, malgache et coréen.
- PHP + MySQL/MariaDB, adapté à un hébergement mutualisé comme InfinityFree.

## Installation sur InfinityFree

1. Créez votre compte d'hébergement et votre base de données MySQL dans le panneau InfinityFree.
2. Ouvrez **phpMyAdmin** depuis le panneau de votre hébergement.
3. Sélectionnez la base de données créée, puis importez **`sql/COMPLETE_INSTALL.sql`** une seule fois sur une base vide. Ce fichier crée les tables et les comptes de démonstration. N'importez pas ensuite `schema.sql` sur la même base.
4. Ouvrez **`config/database.php`** et remplacez les quatre valeurs `YOUR_...` par les informations exactes affichées dans le panneau InfinityFree :
   - `DB_HOST` : MySQL Host Name ;
   - `DB_NAME` : nom complet de la base ;
   - `DB_USER` : nom d'utilisateur MySQL ;
   - `DB_PASS` : mot de passe MySQL.
5. Décompressez l'archive sur votre ordinateur. Envoyez **le contenu du dossier** directement dans `htdocs` via le gestionnaire de fichiers ou FTP. Le fichier `index.php` doit donc se trouver à `htdocs/index.php`, pas dans un sous-dossier `sula_rms/`.
6. Vérifiez que le dossier `uploads/` et ses sous-dossiers sont présents. Les images des plats sont stockées dans `uploads/`.
7. Ouvrez votre domaine pour afficher la page de connexion.

### Comptes de démonstration

Tous les comptes ci-dessous utilisent initialement le mot de passe `password` :

| Rôle | Email |
|---|---|
| Administrateur | `admin@sula.mg` |
| Checker | `checker@sula.mg` |
| Gestionnaire de stock | `stock@sula.mg` |
| Comptable | `comptable@sula.mg` |
| Serveur | `serveur@sula.mg` |
| Cuisine | `cuisine@sula.mg` |

**Sécurité :** changez immédiatement les mots de passe de démonstration avant d'utiliser le site en production. Ne partagez pas les identifiants MySQL. Le fichier de diagnostic public `test.php` a été retiré de cette archive.

## Important

- Cette archive contient le projet PHP SURA propre. N'envoyez pas le dossier WordPress ni les autres fichiers de l'archive `htdocs.zip` : ils ne font pas partie de l'application et peuvent entrer en conflit avec `index.php`.
- InfinityFree est un hébergement mutualisé : certaines fonctions serveur ou tâches automatiques peuvent être limitées. Testez les commandes, réservations, paiements et notifications sur l'hébergement réel avant l'ouverture.
- Les paiements Mobile Money doivent être confirmés par votre équipe tant qu'une intégration officielle avec le fournisseur n'a pas été configurée.


## Rapports SURA (mise à jour)

- Rapport journalier : liste complète des commandes du jour, avec type, heure, statut, paiement et montant.
- Rapports semaine/mois : résumé jour par jour, y compris les jours sans commande, avec accès aux détails de chaque journée.
- Impression navigateur et export PDF disponibles depuis la page Rapports.
- Rapport complet CEO : recettes encaissées, dépenses, nombre de commandes sur place et en livraison, réservations et événements non terminés.

### Migration événements multi-jours
Exécuter une seule fois `sql/reporting_updates.sql` dans la base SURA afin d'ajouter `events.end_date`. La date de fin est facultative dans le formulaire; si elle est vide, la date de début est utilisée.

### Expiration automatique à minuit
Les réservations passent au statut `completed` et les événements planifiés/confirmés passent à `done` le jour suivant leur dernière date. La page Rapports vérifie aussi ces statuts lors de son ouverture. Pour exécuter la vérification chaque nuit même sans visite du site, ajouter une tâche cron quotidienne à 00:05 (heure Madagascar), par exemple :

```cron
5 0 * * * /usr/bin/php /CHEMIN/ABSOLU/htdocs/scripts/expire_schedules.php >> /CHEMIN/ABSOLU/expire-schedules.log 2>&1
```

Remplacer `/CHEMIN/ABSOLU/htdocs` par le chemin réel de l'installation.

## Rapports annuels
- Dans **Rapports**, choisissez **Année** puis sélectionnez une date de l'année voulue.
- Le tableau affiche toujours les 12 mois de l'année, y compris les mois sans commandes et les mois futurs (valeurs à zéro tant qu'il n'y a pas de données).
- Le bouton **Voir détails** ouvre le rapport mensuel du mois choisi; les détails journaliers restent accessibles depuis le rapport mensuel.
- Le bouton **PDF** exporte la synthèse annuelle mois par mois.


### Règle de stock des commandes
Les plats dont le stock est à zéro sont désactivés dans la grille et les contrôles serveur refusent toute commande avec stock nul ou quantité supérieure au stock disponible. La commande client revalide le stock sous verrou SQL et décrémente uniquement si le stock est suffisant.
