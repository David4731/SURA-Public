<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/lang.php';
require_once __DIR__ . '/../includes/validate.php';
require_once __DIR__ . '/../includes/client_types.php';
require_once __DIR__ . '/../includes/notify.php';
$clientPage = 'reservation';
$pageTitle = t('book_table_title');
$pdo = getPDO();
if (function_exists('sulaEnsureClientTypeColumn')) {
    try { sulaEnsureClientTypeColumn($pdo); } catch (Exception $e) {}
}
$msg = '';
$error = '';

foreach ([
    "ALTER TABLE reservations ADD COLUMN reserve_type ENUM('table','multi_table','salle','all_salles','partition') NOT NULL DEFAULT 'table'",
    "ALTER TABLE reservations ADD COLUMN space_codes VARCHAR(255) NULL",
    "ALTER TABLE reservations ADD COLUMN tables_count INT NOT NULL DEFAULT 1",
] as $sql) {
    try { $pdo->exec($sql); } catch (Exception $e) {}
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $name = trim($_POST['client_name'] ?? '');
        $clientType = function_exists('sulaNormalizeClientType') ? sulaNormalizeClientType($_POST['client_type'] ?? 'individu') : 'individu';
        $organization = trim($_POST['organization'] ?? '');
        $phone = trim($_POST['client_phone'] ?? '');
        if ($name === '' || $phone === '') {
            throw new Exception('Nom et téléphone obligatoires.');
        }
        if (!sulaIsValidMgPhone($phone)) {
            throw new Exception('Numéro de téléphone invalide (format 03X XX XXX XX).');
        }
        $phone = sulaNormalizePhone($phone);
        // Append org to notes if provided
        $notes = trim($_POST['notes'] ?? '');
        if ($organization !== '') {
            $notes = trim($notes . ' | Org: ' . $organization);
        }
        $guests = max(1, (int)($_POST['guests'] ?? 2));
        $date = $_POST['reservation_date'] ?? '';
        $time = $_POST['reservation_time'] ?? '';
        $rtype = $_POST['reserve_type'] ?? 'table';
        $tablesCount = max(1, (int)($_POST['tables_count'] ?? 1));
        $notes = trim($_POST['notes'] ?? '');
        $space = trim($_POST['space_code'] ?? '');

        if ($name === '' || $phone === '' || $date === '' || $time === '') {
            throw new Exception('Nom, telephone, date et heure sont obligatoires.');
        }
        if (!in_array($rtype, ['table', 'multi_table', 'salle', 'all_salles', 'partition'], true)) {
            $rtype = 'table';
        }
        if (in_array($rtype, ['table', 'multi_table', 'partition'], true)) {
            if ($rtype === 'table') $tablesCount = 1;
            $minG = $tablesCount * 4;
            $maxG = $tablesCount * 8;
            if ($guests < $minG || $guests > $maxG) {
                throw new Exception("Pour $tablesCount table(s) : entre $minG et $maxG personnes (4 a 8 par table).");
            }
        }
        if ($rtype === 'all_salles') {
            $codesCsv = 'ALL_SALLES';
            $label = 'Tout etablissement (2 salles + terrasse)';
        } else {
            if ($space === '') throw new Exception('Choisissez une partie libre.');
            $codesCsv = $space;
            $label = $space . ($tablesCount > 1 ? " ($tablesCount tables)" : '');
        }

        try {
            $pdo->prepare('INSERT INTO reservations (client_name,client_phone,guests,reservation_date,reservation_time,table_partition,reserve_type,space_codes,tables_count,payment_status,paid_amount,notes,status) VALUES (?,?,?,?,?,?,?,?,?,"not_paid",0,?,"pending")')
                ->execute([$name, $phone, $guests, $date, $time, $label, $rtype, $codesCsv, $tablesCount, $notes ?: null]);
        } catch (Exception $ex) {
            $pdo->prepare('INSERT INTO reservations (client_name,client_phone,guests,reservation_date,reservation_time,table_partition,payment_status,paid_amount,notes,status) VALUES (?,?,?,?,?,?,"not_paid",0,?,"pending")')
                ->execute([$name, $phone, $guests, $date, $time, $label, $notes ?: null]);
        }
        $rid = (int)$pdo->lastInsertId();
        sulaNotify($pdo, 'Nouvelle reservation client #' . $rid, "$name — $guests pers. — $date $time — $label — Tel: $phone", 'reservation');
        $msg = 'Demande envoyee ! Le checker confirmera par telephone.';
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

require __DIR__ . '/_header.php';
?>
<h2 class="font-serif text-2xl font-bold mb-1"><?= t('book_table') ?></h2>
<p class="text-muted mb-4">Choisissez une date : les parties <strong>libres</strong> s'affichent automatiquement.</p>

<?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="row g-4">
  <div class="col-lg-5">
    <div class="card border-0 shadow-sm p-4">
      <form method="post" id="resForm">
        <div class="row g-2 mb-3">
          <div class="col-6">
            <label class="form-label"><?= t('date') ?> *</label>
            <input type="date" name="reservation_date" id="resDate" class="form-control" required min="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d') ?>">
          </div>
          <div class="col-6">
            <label class="form-label"><?= t('time_label') ?> *</label>
            <input type="time" name="reservation_time" class="form-control" required value="19:00">
          </div>
        </div>
        <div class="mb-3">
          <label class="form-label">Type *</label>
          <select name="reserve_type" id="cType" class="form-select" required>
            <option value="table">Une table (4–8 pers.)</option>
            <option value="partition">Partition (plusieurs tables)</option>
            <option value="salle">Salle 1, Salle 2 ou Terrasse entiere</option>
            <option value="all_salles">Tout l'etablissement</option>
          </select>
        </div>
        <div class="mb-3" id="cSpace">
          <label class="form-label">Partie libre *</label>
          <select name="space_code" id="spaceSelect" class="form-select">
            <option value="">— Choisir une date d'abord —</option>
          </select>
        </div>
        <div class="mb-3" id="cCnt" style="display:none">
          <label class="form-label"><?= t('tables_count') ?> (partition)</label>
          <input type="number" name="tables_count" class="form-control" min="1" max="15" value="2">
        </div>
        <div class="mb-3">
          <label class="form-label">Votre nom *</label>
          <label class="form-label"><?= t('client_type') ?></label>
          <select name="client_type" id="clientTypeRes" class="form-select mb-2">
            <?php foreach (function_exists('sulaClientTypes') ? sulaClientTypes() : ['individu'=>'Individu'] as $code=>$label): ?>
              <option value="<?= htmlspecialchars($code) ?>"><?= htmlspecialchars($label) ?></option>
            <?php endforeach; ?>
          </select>
          <div id="orgBoxRes" class="mb-2" style="display:none">
            <label class="form-label"><?= t('organization_family') ?></label>
            <input type="text" name="organization" class="form-control" placeholder="<?= t('organization_family') ?>">
          </div>
          <label class="form-label"><?= t('contact_name') ?> *</label>
          <input type="text" name="client_name" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label"><?= t('phone_required') ?> *</label>
          <input type="text" name="client_phone" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label"><?= t('guests') ?> *</label>
          <input type="number" name="guests" class="form-control" min="1" value="4" required>
        </div>
        <div class="mb-3">
          <label class="form-label"><?= t('notes') ?></label>
          <textarea name="notes" class="form-control" rows="2"></textarea>
        </div>
        <button class="btn btn-danger w-100"><?= t('submit') ?></button>
      </form>
    </div>
  </div>
  <div class="col-lg-7">
    <div class="card border-0 shadow-sm p-4">
      <h5 class="font-serif text-gold-400 mb-3">Parties libres — <span id="freeDateLabel"><?= date('d/m/Y') ?></span></h5>
      <div id="freeLoading" class="text-muted small">Chargement…</div>
      <div id="freeLists" class="row g-3" style="display:none">
        <div class="col-md-4">
          <h6 class="text-uppercase text-muted small">Salles / Terrasse</h6>
          <ul id="listSalles" class="list-unstyled small"></ul>
        </div>
        <div class="col-md-4">
          <h6 class="text-uppercase text-muted small">Tables</h6>
          <ul id="listTables" class="list-unstyled small" style="max-height:280px;overflow:auto"></ul>
        </div>
        <div class="col-md-4">
          <h6 class="text-uppercase text-muted small">Partitions</h6>
          <ul id="listParts" class="list-unstyled small"></ul>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
(function(){
  var dateEl = document.getElementById('resDate');
  var typeEl = document.getElementById('cType');
  var spaceSel = document.getElementById('spaceSelect');
  var freeData = {salle:[], table:[], partition:[]};

  function loadFree() {
    var d = dateEl.value;
    if (!d) return;
    document.getElementById('freeLoading').style.display = '';
    document.getElementById('freeLists').style.display = 'none';
    document.getElementById('freeDateLabel').textContent = d.split('-').reverse().join('/');
    fetch('/ajax/free_spaces.php?date=' + encodeURIComponent(d))
      .then(function(r){ return r.json(); })
      .then(function(data){
        document.getElementById('freeLoading').style.display = 'none';
        if (!data.ok) {
          document.getElementById('freeLoading').style.display = '';
          document.getElementById('freeLoading').textContent = data.error || 'Erreur';
          return;
        }
        freeData = data.free || {salle:[],table:[],partition:[]};
        function fillUl(id, arr, prefix) {
          var ul = document.getElementById(id);
          ul.innerHTML = '';
          if (!arr.length) { ul.innerHTML = '<li class="text-muted">Aucune</li>'; return; }
          arr.forEach(function(s){
            var li = document.createElement('li');
            li.className = 'mb-1';
            li.innerHTML = '<span class="badge bg-success">Libre</span> <strong>' + (prefix||'') + s.code + '</strong> — ' + (s.label||'') +
              (s.capacity ? ' <span class="text-muted">(' + s.capacity + ' p.)</span>' : '');
            ul.appendChild(li);
          });
        }
        fillUl('listSalles', freeData.salle || []);
        fillUl('listTables', freeData.table || [], 'N° ');
        fillUl('listParts', freeData.partition || []);
        document.getElementById('freeLists').style.display = '';
        syncSelect();
      })
      .catch(function(){
        document.getElementById('freeLoading').textContent = 'Impossible de charger les disponibilites';
      });
  }

  function syncSelect() {
    var v = typeEl.value;
    document.getElementById('cSpace').style.display = (v === 'all_salles') ? 'none' : '';
    document.getElementById('cCnt').style.display = (v === 'partition') ? '' : 'none';
    var list = [];
    if (v === 'table') list = freeData.table || [];
    else if (v === 'partition') list = freeData.partition || [];
    else if (v === 'salle') list = freeData.salle || [];
    spaceSel.innerHTML = '<option value="">— Choisir —</option>';
    list.forEach(function(s){
      var opt = document.createElement('option');
      opt.value = s.code;
      opt.textContent = s.code + ' — ' + (s.label || '') + (s.capacity ? ' (' + s.capacity + ' p.)' : '');
      spaceSel.appendChild(opt);
    });
  }

  dateEl.addEventListener('change', loadFree);
  typeEl.addEventListener('change', syncSelect);
  loadFree();
})();
</script>
<script>
(function(){
  var ct = document.getElementById('clientTypeRes');
  var org = document.getElementById('orgBoxRes');
  function sync(){
    if (!ct || !org) return;
    var v = ct.value;
    var needs = ['famille','association','entreprise','institution','ecole','hotel','groupe','autre'].indexOf(v)>=0;
    org.style.display = needs ? '' : 'none';
  }
  if (ct) { ct.addEventListener('change', sync); sync(); }
})();
</script>
<?php require __DIR__ . '/_footer.php'; ?>
