<?php
/**
 * Page de paiement direct — preuve = capture d'écran du message avec la référence
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/lang.php';
require_once __DIR__ . '/../includes/payments.php';
require_once __DIR__ . '/../includes/validate.php';

$clientPage = 'order';
$pageTitle = 'Paiement';
$pdo = getPDO();
$merchants = sulaPaymentMethods();
$msg = '';
$error = '';
$pay = null;
$order = null;

$uploadDir = __DIR__ . '/../uploads/payments';
if (!is_dir($uploadDir)) {
    @mkdir($uploadDir, 0755, true);
}

$ref = trim($_GET['ref'] ?? $_POST['ref'] ?? '');
$orderId = (int)($_GET['order'] ?? $_POST['order_id'] ?? 0);

try {
    if ($ref !== '') {
        $st = $pdo->prepare('SELECT * FROM payment_requests WHERE reference = ? LIMIT 1');
        $st->execute([$ref]);
        $pay = $st->fetch(PDO::FETCH_ASSOC);
    } elseif ($orderId > 0) {
        $st = $pdo->prepare('SELECT * FROM payment_requests WHERE order_id = ? ORDER BY id DESC LIMIT 1');
        $st->execute([$orderId]);
        $pay = $st->fetch(PDO::FETCH_ASSOC);
    }
    if ($pay && !empty($pay['order_id'])) {
        $st = $pdo->prepare('SELECT * FROM orders WHERE id = ?');
        $st->execute([(int)$pay['order_id']]);
        $order = $st->fetch(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    $error = 'Référence introuvable. Vérifiez le code SURA-…';
}

// Colonnes image preuve
try {
    $pdo->exec("ALTER TABLE payment_requests ADD COLUMN proof_image VARCHAR(255) NULL AFTER proof_note");
} catch (Exception $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_payment']) && $pay) {
    try {
        $proof = trim($_POST['proof_note'] ?? '');
        $payerName = trim($_POST['payer_name'] ?? '');
        $payerPhone = trim($_POST['payer_phone'] ?? '');

        // Auto depuis commande si vide
        if ($order) {
            if ($payerName === '') $payerName = $order['client_name'] ?? '';
            if ($payerPhone === '') $payerPhone = $order['client_phone'] ?? '';
        }
        if ($payerPhone !== '' && !sulaIsValidMgPhone($payerPhone)) {
            throw new Exception('Numéro de l\'envoyeur invalide (format 03X XX XXX XX).');
        }
        if ($payerPhone !== '') $payerPhone = sulaNormalizePhone($payerPhone);

        // Capture d'écran obligatoire
        $proofImage = $pay['proof_image'] ?? null;
        if (!empty($_FILES['proof_image']['name']) && $_FILES['proof_image']['error'] === UPLOAD_ERR_OK) {
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($_FILES['proof_image']['tmp_name']);
            $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
            if (!isset($allowed[$mime])) {
                throw new Exception('La preuve doit être une image (JPG, PNG, WEBP). Capture d\'écran du message de transaction.');
            }
            if ($_FILES['proof_image']['size'] > 5 * 1024 * 1024) {
                throw new Exception('Image trop lourde (max 5 Mo).');
            }
            $ext = $allowed[$mime];
            $fname = 'proof_' . preg_replace('/[^A-Z0-9\-]/i', '', $pay['reference']) . '_' . time() . '.' . $ext;
            $dest = $uploadDir . '/' . $fname;
            if (!move_uploaded_file($_FILES['proof_image']['tmp_name'], $dest)) {
                throw new Exception('Échec upload de la capture.');
            }
            $proofImage = 'payments/' . $fname;
        }
        if (empty($proofImage) && empty($pay['proof_image'])) {
            throw new Exception('Joignez une capture d\'écran du message de transaction contenant la référence ' . $pay['reference'] . '.');
        }

        $pdo->prepare("UPDATE payment_requests SET status='awaiting_proof', proof_note=?, proof_image=COALESCE(?, proof_image), payer_name=COALESCE(NULLIF(?,''), payer_name), payer_phone=COALESCE(NULLIF(?,''), payer_phone) WHERE id=?")
            ->execute([$proof ?: null, $proofImage, $payerName, $payerPhone, (int)$pay['id']]);

        try {
            require_once __DIR__ . '/../includes/notify.php';
            sulaNotify($pdo,
                'Preuve paiement ' . $pay['reference'],
                'Commande #' . ($pay['order_id'] ?? '?') . ' — ' . $pay['method'] . ' — ' . number_format((float)$pay['amount'],0,',',' ') . ' Ar — Capture reçue — À confirmer par Checker',
                'payment'
            );
        } catch (Exception $e) {}

        $msg = 'Preuve enregistrée. Le restaurant confirmera votre paiement sous peu.';
        $st = $pdo->prepare('SELECT * FROM payment_requests WHERE id=?');
        $st->execute([(int)$pay['id']]);
        $pay = $st->fetch(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

$method = $pay['method'] ?? ($_GET['method'] ?? 'mvola');
$amount = (float)($pay['amount'] ?? 0);
$reference = $pay['reference'] ?? $ref;
$mInfo = $merchants[$method] ?? null;

// Préremplir envoyeur depuis commande
$defaultPayerName = $pay['payer_name'] ?? ($order['client_name'] ?? '');
$defaultPayerPhone = $pay['payer_phone'] ?? ($order['client_phone'] ?? '');

require __DIR__ . '/_header.php';
?>
<div class="max-w-lg mx-auto">
  <h2 class="font-serif text-2xl font-bold mb-1">Paiement sécurisé</h2>
  <p class="text-muted mb-4">Réglez via l’app. La preuve doit être une <strong>capture d’écran</strong> du message contenant la référence.</p>

  <?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
  <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

  <?php if (!$pay && !$reference): ?>
    <div class="card p-4">
      <p class="mb-3">Entrez la référence reçue après commande :</p>
      <form method="get" class="d-flex gap-2">
        <input type="text" name="ref" class="form-control" placeholder="SURA-XXXXXX" required>
        <button class="btn btn-danger">OK</button>
      </form>
    </div>
  <?php else: ?>
    <div class="card border-0 shadow-sm p-4 mb-3">
      <div class="d-flex justify-content-between align-items-start mb-3">
        <div>
          <p class="text-muted small mb-0">Référence</p>
          <code class="fs-5 text-success"><?= htmlspecialchars($reference) ?></code>
        </div>
        <span class="pay-brand <?= htmlspecialchars($mInfo['color'] ?? 'cash') ?>">
          <?= htmlspecialchars($mInfo['label'] ?? $method) ?>
        </span>
      </div>
      <p class="mb-1">Montant à payer</p>
      <p class="display-6 fw-bold text-warning mb-3"><?= number_format($amount, 0, ',', ' ') ?> <small class="fs-6">Ar</small></p>
      <?php if ($order): ?>
        <p class="small text-muted mb-0">Commande #<?= (int)$order['id'] ?> · <?= htmlspecialchars($order['client_name'] ?? '') ?> · <?= htmlspecialchars(sulaFormatPhone($order['client_phone'] ?? '')) ?></p>
      <?php endif; ?>
      <?php if (($pay['status'] ?? '') === 'confirmed'): ?>
        <div class="alert alert-success mt-3 mb-0">Paiement confirmé. Merci !</div>
      <?php endif; ?>
    </div>

    <?php if ($method !== 'cash' && ($pay['status'] ?? '') !== 'confirmed'): ?>
    <div class="card border-0 shadow-sm p-4 mb-3">
      <h5 class="mb-3">Étape 1 — Effectuer le transfert</h5>
      <?php if ($method === 'mvola'): ?>
        <p>Envoyez <strong><?= number_format($amount,0,',',' ') ?> Ar</strong> via <strong>MVola</strong> vers :</p>
        <p class="fs-4 fw-bold"><span class="pay-brand mvola"><?= htmlspecialchars($mInfo['number'] ?? '') ?></span></p>
        <p class="small">Dans le <strong>motif / message</strong>, indiquez exactement : <code><?= htmlspecialchars($reference) ?></code></p>
      <?php elseif ($method === 'orange_money'): ?>
        <p>Envoyez <strong><?= number_format($amount,0,',',' ') ?> Ar</strong> via <strong>Orange Money</strong> vers <span class="pay-brand orange"><?= htmlspecialchars($mInfo['number'] ?? '') ?></span></p>
        <p class="small">Motif : <code><?= htmlspecialchars($reference) ?></code></p>
      <?php elseif ($method === 'airtel_money'): ?>
        <p>Envoyez <strong><?= number_format($amount,0,',',' ') ?> Ar</strong> via <strong>Airtel Money</strong> vers <span class="pay-brand airtel"><?= htmlspecialchars($mInfo['number'] ?? '') ?></span></p>
        <p class="small">Motif : <code><?= htmlspecialchars($reference) ?></code></p>
      <?php elseif ($method === 'virement'): ?>
        <ul class="small">
          <li>Bénéficiaire : <?= htmlspecialchars($mInfo['account_name'] ?? 'SURA') ?></li>
          <li>Banque : <?= htmlspecialchars($mInfo['bank'] ?? '') ?></li>
          <li>Compte : <?= htmlspecialchars($mInfo['iban'] ?: '(demander au restaurant)') ?></li>
          <li>Libellé : <code><?= htmlspecialchars($reference) ?></code></li>
        </ul>
      <?php endif; ?>
    </div>

    <div class="card border-0 shadow-sm p-4">
      <h5 class="mb-3">Étape 2 — Joindre la capture d’écran</h5>
      <p class="small text-muted mb-3">Prenez une <strong>capture d’écran du SMS / notification / reçu</strong> qui contient la référence <code><?= htmlspecialchars($reference) ?></code> et le montant.</p>
      <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="confirm_payment" value="1">
        <input type="hidden" name="ref" value="<?= htmlspecialchars($reference) ?>">
        <div class="mb-3">
          <label class="form-label">Capture d’écran (JPG / PNG) *</label>
          <input type="file" name="proof_image" class="form-control" accept="image/jpeg,image/png,image/webp,image/gif" <?= empty($pay['proof_image']) ? 'required' : '' ?>>
          <?php if (!empty($pay['proof_image'])): ?>
            <p class="small text-success mt-1">Fichier déjà envoyé.
              <a href="/uploads/<?= htmlspecialchars($pay['proof_image']) ?>" target="_blank">Voir</a>
            </p>
          <?php endif; ?>
        </div>
        <div class="mb-2">
          <label class="form-label">Note / n° transaction (optionnel)</label>
          <input type="text" name="proof_note" class="form-control" placeholder="ID transaction si visible"
                 value="<?= htmlspecialchars($pay['proof_note'] ?? '') ?>">
        </div>
        <div class="mb-2">
          <label class="form-label">Nom de l'envoyeur</label>
          <input type="text" name="payer_name" class="form-control" value="<?= htmlspecialchars($defaultPayerName) ?>">
        </div>
        <div class="mb-3">
          <label class="form-label">Numéro de l'envoyeur</label>
          <input type="text" name="payer_phone" class="form-control" placeholder="03X XX XXX XX" value="<?= htmlspecialchars($defaultPayerPhone) ?>">
        </div>
        <button type="submit" class="btn btn-danger w-100">Envoyer la preuve</button>
      </form>
    </div>
    <?php endif; ?>

    <div class="text-center mt-4">
      <a href="/client/order.php" class="text-muted small">← Nouvelle commande</a>
      ·
      <a href="/client/index.php" class="text-muted small">Accueil</a>
    </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
