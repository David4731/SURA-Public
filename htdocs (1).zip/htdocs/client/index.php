<?php
require_once __DIR__ . '/../includes/lang.php';
$pageTitle = 'SURA';
require __DIR__ . '/_header.php';
?>
<div class="text-center mb-10">
  <p class="text-[11px] uppercase tracking-[0.25em] text-gold-500 mb-2">Olympia Tanjombato</p>
  <h1 class="font-serif text-4xl md:text-5xl font-bold gold-gradient-text mb-3">SURA</h1>
  <p class="text-slate-400 max-w-lg mx-auto"><?= t('tagline') ?> · Korean &amp; Malagasy</p>
</div>

<div class="grid md:grid-cols-3 gap-5 mb-10">
  <a href="/client/order.php" class="glass-card rounded-2xl p-6 text-center hover:border-gold-400 transition-all no-underline group">
    <div class="text-3xl mb-3 text-gold-400"><i class="fa-solid fa-utensils"></i></div>
    <h3 class="font-serif text-lg font-bold text-slate-100 mb-1"><?= t('order_now') ?></h3>
    <p class="text-xs text-slate-400">Menu · livraison · sur place</p>
  </a>
  <a href="/client/reservation.php" class="glass-card rounded-2xl p-6 text-center hover:border-gold-400 transition-all no-underline group">
    <div class="text-3xl mb-3 text-gold-400"><i class="fa-solid fa-calendar-check"></i></div>
    <h3 class="font-serif text-lg font-bold text-slate-100 mb-1"><?= t('book_table') ?></h3>
    <p class="text-xs text-slate-400"><?= t('reservations') ?></p>
  </a>
  <a href="/client/avis.php" class="glass-card rounded-2xl p-6 text-center hover:border-gold-400 transition-all no-underline group">
    <div class="text-3xl mb-3 text-gold-400"><i class="fa-solid fa-star"></i></div>
    <h3 class="font-serif text-lg font-bold text-slate-100 mb-1"><?= t('feedback') ?></h3>
    <p class="text-xs text-slate-400">Notes &amp; idées</p>
  </a>
</div>

<div class="glass-card rounded-2xl p-6 text-center mb-8">
  <p class="text-sm text-slate-400 mb-2"><?= t('payments') ?></p>
  <div class="flex flex-wrap justify-center gap-2 mb-3">
    <span class="pay-brand mvola">MVola 038 24 541 74</span>
    <span class="pay-brand orange">Orange Money</span>
    <span class="pay-brand airtel">Airtel Money</span>
    <span class="pay-brand cash">Cash</span>
  </div>
  <a href="https://wa.me/261382454174" class="text-gold-400 hover:underline text-sm" target="_blank">
    <i class="fa-brands fa-whatsapp"></i> WhatsApp +261 38 24 541 74
  </a>
</div>

<!-- Carte — Trouver le restaurant -->
<div class="glass-card rounded-2xl overflow-hidden mb-6">
  <div class="p-4 border-b border-gold-500/20 flex flex-wrap items-center justify-between gap-2">
    <div>
      <h3 class="font-serif text-lg font-bold text-slate-100 mb-0">
        <i class="fa-solid fa-location-dot text-gold-400 me-2"></i>Nous trouver
      </h3>
      <p class="text-xs text-slate-400 mb-0">SURA · Centre commercial Olympia · Tanjombato, Antananarivo</p>
    </div>
    <a href="https://www.google.com/maps/search/?api=1&query=Olympia+Tanjombato+Antananarivo" target="_blank" rel="noopener"
       class="text-xs px-3 py-1.5 rounded-full border border-gold-500/40 text-gold-400 hover:bg-gold-500/10 no-underline">
      Ouvrir dans Google Maps →
    </a>
  </div>
  <div class="relative w-full" style="height:320px">
    <iframe
      title="Carte SURA Olympia Tanjombato"
      width="100%" height="320" style="border:0;display:block"
      loading="lazy" referrerpolicy="no-referrer-when-downgrade"
      src="https://www.openstreetmap.org/export/embed.html?bbox=47.500%2C-19.000%2C47.560%2C-18.940&amp;layer=mapnik&amp;marker=-18.970%2C47.530">
    </iframe>
  </div>
  <div class="p-3 text-center text-xs text-slate-400">
    <i class="fa-solid fa-map-pin text-gold-500 me-1"></i>
    Olympia Tanjombato · près de Kibo &amp; Sanifer · Antananarivo Atsimondrano
  </div>
</div>
<?php require __DIR__ . '/_footer.php'; ?>
