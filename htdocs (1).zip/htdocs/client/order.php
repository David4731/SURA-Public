<?php
/**
 * Espace client — Commande livraison
 * Robustifié : pas de DDL dans une transaction (évite "There is no active transaction")
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/lang.php';
require_once __DIR__ . '/../includes/notify.php';
require_once __DIR__ . '/../includes/stations.php';
require_once __DIR__ . '/../includes/payments.php';
require_once __DIR__ . '/../includes/validate.php';
require_once __DIR__ . '/../includes/client_types.php';

$clientPage = 'order';
$pageTitle = t('order_delivery_title');
$pdo = getPDO();
try { if (function_exists('sulaEnsureClientTypeColumn')) sulaEnsureClientTypeColumn($pdo); } catch (Exception $e) {}
$msg = '';
$error = '';
$paymentInfo = null;

// Tables auxiliaires AVANT toute transaction
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS customers (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      phone VARCHAR(30) NOT NULL,
      email VARCHAR(150) NULL,
      is_vip TINYINT(1) NOT NULL DEFAULT 0,
      orders_count INT NOT NULL DEFAULT 0,
      notes TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uk_phone (phone)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS payment_requests (
      id INT AUTO_INCREMENT PRIMARY KEY,
      order_id INT NULL,
      reservation_id INT NULL,
      method VARCHAR(40) NOT NULL DEFAULT 'mvola',
      amount DECIMAL(12,2) NOT NULL DEFAULT 0,
      reference VARCHAR(40) NOT NULL,
      payer_name VARCHAR(100) NULL,
      payer_phone VARCHAR(30) NULL,
      status VARCHAR(30) NOT NULL DEFAULT 'pending',
      external_id VARCHAR(100) NULL,
      proof_note TEXT NULL,
      confirmed_by INT NULL,
      confirmed_at DATETIME NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uk_reference (reference)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    try {
        $name    = trim($_POST['client_name'] ?? '');
        $clientType = sulaNormalizeClientType($_POST['client_type'] ?? 'individu');
        $organization = trim($_POST['organization'] ?? '');
        $phone   = trim($_POST['client_phone'] ?? '');
        $address = trim($_POST['client_address'] ?? '');
        $ddate   = trim($_POST['delivery_date'] ?? '');
        $method  = $_POST['payment_method'] ?? 'cash';
        $payerName  = trim($_POST['payer_name'] ?? '');
        $payerPhone = trim($_POST['payer_phone'] ?? '');
        $items   = isset($_POST['items']) && is_array($_POST['items']) ? $_POST['items'] : [];
        $notes   = trim($_POST['notes'] ?? '');

        if ($name === '' || $phone === '' || $address === '') {
            throw new Exception('Nom, téléphone et adresse sont obligatoires.');
        }
        if (!sulaIsValidMgPhone($phone)) {
            throw new Exception('Numéro client invalide. Format attendu : 03X XX XXX XX (opérateur malgache).');
        }
        $phone = sulaNormalizePhone($phone);

        $allowed = ['cash','mvola','orange_money','airtel_money','virement','autre'];
        if (!in_array($method, $allowed, true)) $method = 'cash';
        // Non-cash : nom & numéro envoyeur = ceux du client (automatique)
        if ($method === 'cash') {
            $payerName = '';
            $payerPhone = '';
        } else {
            if ($payerName === '') $payerName = $name;
            if ($payerPhone === '') $payerPhone = $phone;
            if (!sulaIsValidMgPhone($payerPhone)) {
                throw new Exception('Numéro de l\'envoyeur invalide. Format : 03X XX XXX XX.');
            }
            $payerPhone = sulaNormalizePhone($payerPhone);
        }

        $total = 0;
        $lines = [];
        foreach ($items as $mid => $qty) {
            $qty = (int)$qty;
            if ($qty < 1) continue;
            $st = $pdo->prepare('SELECT * FROM menus WHERE id=? AND available=1');
            $st->execute([(int)$mid]);
            $m = $st->fetch(PDO::FETCH_ASSOC);
            if (!$m) continue;
            $availableStock = (int)($m['stock'] ?? 0);
            if ($availableStock <= 0) {
                throw new Exception('Le plat « ' . $m['name'] . ' » est épuisé et ne peut pas être commandé.');
            }
            if ($qty > $availableStock) {
                throw new Exception('Stock insuffisant pour « ' . $m['name'] . ' ». Quantité disponible : ' . $availableStock . '.');
            }
            $sub = (float)$m['price'] * $qty;
            $total += $sub;
            $lines[] = [
                'menu_id' => (int)$m['id'],
                'name'    => $m['name'],
                'qty'     => $qty,
                'price'   => (float)$m['price'],
                'sub'     => $sub,
                'category'=> $m['category'] ?? 'plat',
            ];
        }
        if (!$lines) {
            throw new Exception('Ajoutez au moins un plat (quantité > 0).');
        }
        if ($total <= 0) {
            throw new Exception('Montant total invalide.');
        }

        $pdo->beginTransaction();

        // Revalidation sous verrou pour éviter deux commandes simultanées sur le même stock.
        foreach ($lines as $line) {
            $lock = $pdo->prepare('SELECT name, stock FROM menus WHERE id=? AND available=1 FOR UPDATE');
            $lock->execute([$line['menu_id']]);
            $lockedMenu = $lock->fetch(PDO::FETCH_ASSOC);
            if (!$lockedMenu || (int)$lockedMenu['stock'] <= 0) {
                throw new Exception('Le plat « ' . $line['name'] . ' » vient de passer en rupture de stock.');
            }
            if ((int)$lockedMenu['stock'] < (int)$line['qty']) {
                throw new Exception('Stock insuffisant pour « ' . $line['name'] . ' ». Quantité restante : ' . (int)$lockedMenu['stock'] . '.');
            }
        }

        $oid = 0;
        $orderInserted = false;
        $lastEx = null;
        $insertAttempts = [
            [
                'sql' => 'INSERT INTO orders (user_id,order_type,client_name,client_type,client_phone,client_address,delivery_date,total,status,payment_status,payment_method,payer_name,payer_phone,notes)
                          VALUES (NULL,\'delivery\',?,?,?,?,?,?,\'pending\',\'not_paid\',?,?,?,?)',
                'params' => [$name, $clientType, $phone, $address, $ddate !== '' ? $ddate : null, $total, $method, $payerName ?: null, $payerPhone ?: null, $notes ?: null],
            ],
            [
                'sql' => 'INSERT INTO orders (user_id,order_type,client_name,client_phone,client_address,delivery_date,total,status,payment_status,payment_method,payer_name,payer_phone,notes)
                          VALUES (NULL,\'delivery\',?,?,?,?,?,\'pending\',\'not_paid\',?,?,?,?)',
                'params' => [$name, $phone, $address, $ddate !== '' ? $ddate : null, $total, $method, $payerName ?: null, $payerPhone ?: null, $notes ?: null],
            ],
            [
                'sql' => 'INSERT INTO orders (user_id,order_type,client_name,client_phone,client_address,delivery_date,total,status,payment_status,payment_method,notes)
                          VALUES (NULL,\'delivery\',?,?,?,?,?,\'pending\',\'not_paid\',?,?)',
                'params' => [$name, $phone, $address, $ddate !== '' ? $ddate : null, $total, $method, $notes ?: null],
            ],
            [
                'sql' => 'INSERT INTO orders (user_id,order_type,client_name,client_phone,client_address,delivery_date,total,status,payment_status,notes)
                          VALUES (NULL,\'delivery\',?,?,?,?,?,\'pending\',\'not_paid\',?)',
                'params' => [$name, $phone, $address, $ddate !== '' ? $ddate : null, $total, $notes ?: null],
            ],
        ];
        foreach ($insertAttempts as $attempt) {
            try {
                $pdo->prepare($attempt['sql'])->execute($attempt['params']);
                $oid = (int)$pdo->lastInsertId();
                if ($oid > 0) { $orderInserted = true; break; }
            } catch (Exception $ex) {
                $lastEx = $ex;
            }
        }
        if (!$orderInserted || $oid < 1) {
            throw new Exception('Impossible d\'enregistrer la commande. ' . ($lastEx ? $lastEx->getMessage() : ''));
        }

        foreach ($lines as &$l) {
            $l['station'] = function_exists('stationForCategory') ? stationForCategory($l['category']) : 'kitchen';
        }
        unset($l);

        try {
            $ins = $pdo->prepare('INSERT INTO order_items (order_id,menu_id,item_name,quantity,unit_price,subtotal,station) VALUES (?,?,?,?,?,?,?)');
            foreach ($lines as $l) {
                $ins->execute([$oid, $l['menu_id'], $l['name'], $l['qty'], $l['price'], $l['sub'], $l['station']]);
            }
        } catch (Exception $ex) {
            $ins = $pdo->prepare('INSERT INTO order_items (order_id,menu_id,item_name,quantity,unit_price,subtotal) VALUES (?,?,?,?,?,?)');
            foreach ($lines as $l) {
                $ins->execute([$oid, $l['menu_id'], $l['name'], $l['qty'], $l['price'], $l['sub']]);
            }
        }

        $upd = $pdo->prepare('UPDATE menus SET stock = stock - ? WHERE id = ? AND stock >= ?');
        foreach ($lines as $l) {
            $upd->execute([$l['qty'], $l['menu_id'], $l['qty']]);
            if ($upd->rowCount() !== 1) {
                throw new Exception('Stock insuffisant pour « ' . $l['name'] . ' ». La commande n’a pas été validée.');
            }
        }

        if ($pdo->inTransaction()) {
            $pdo->commit();
        }

        // Après commit : tracking client + paiement (hors transaction)
        try {
            $ex = $pdo->prepare('SELECT id, orders_count FROM customers WHERE phone=?');
            $ex->execute([$phone]);
            $c = $ex->fetch();
            if ($c) {
                $newCount = (int)$c['orders_count'] + 1;
                $vip = $newCount >= 5 ? 1 : 0;
                $pdo->prepare('UPDATE customers SET name=?, orders_count=?, is_vip=IF(is_vip=1,1,?) WHERE id=?')
                    ->execute([$name, $newCount, $vip, $c['id']]);
            } else {
                try {
                    $pdo->prepare('INSERT INTO customers (name,phone,client_type,organization,orders_count) VALUES (?,?,?,?,1)')
                        ->execute([$name, $phone, $clientType, $organization ?: null]);
                } catch (Exception $e) {
                    $pdo->prepare('INSERT INTO customers (name,phone,orders_count) VALUES (?,?,1)')
                        ->execute([$name, $phone]);
                }
            }
            try {
                $pdo->prepare('UPDATE customers SET client_type=?, organization=COALESCE(NULLIF(?,""), organization), name=? WHERE phone=?')
                    ->execute([$clientType, $organization, $name, $phone]);
            } catch (Exception $e) {}
        } catch (Exception $e2) {}

        $payReq = null;
        try {
            $payReq = sulaCreatePaymentRequest($pdo, $oid, $total, $method, $payerName ?: $name, $payerPhone ?: $phone);
        } catch (Exception $e) {
            $payReq = ['reference' => sulaGeneratePaymentRef(), 'method' => $method, 'amount' => $total];
        }

        try {
            sulaNotify($pdo,
                'Nouvelle commande client #' . $oid,
                $name . ' — ' . number_format($total, 0, ',', ' ') . ' Ar — Tel: ' . $phone .
                ' — Paiement: ' . $method . ' — Réf: ' . ($payReq['reference'] ?? '') . ' — En attente approbation checker',
                'order'
            );
        } catch (Exception $e) {}

        // Redirection paiement non-cash
        if ($method !== 'cash' && !empty($payReq['reference'])) {
            header('Location: /client/pay.php?ref=' . urlencode($payReq['reference']));
            exit;
        }

        $paymentInfo = [
            'order_id'  => $oid,
            'reference' => $payReq['reference'] ?? '',
            'method'    => $method,
            'amount'    => $total,
            'instructions' => sulaPaymentInstructions($method, $payReq['reference'] ?? '', $total),
        ];
        $msg = "Commande #$oid enregistrée ! Total : " . number_format($total, 0, ',', ' ') . " Ar. Nous vous contacterons au $phone.";
    } catch (Exception $e) {
        try {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
        } catch (Exception $rb) {}
        $error = $e->getMessage();
    }
}

try {
    $menus = $pdo->query("SELECT * FROM menus WHERE available=1 ORDER BY category, name")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $menus = [];
    $error = $error ?: 'Impossible de charger le menu. Vérifiez la connexion base de données.';
}
$categories = [
        'entree' => t('cat_entree'), 'plat' => t('cat_plat'), 'grill' => t('cat_grill'),
        'pain' => t('cat_pain'), 'cafe' => t('cat_cafe'), 'boisson' => t('cat_boisson'),
        'openbar' => t('cat_openbar'), 'dessert' => t('cat_dessert'), 'autre' => t('cat_autre'),
    ];
$merchants = sulaPaymentMethods();

require __DIR__ . '/_header.php';
?>
<h2 class="font-serif text-2xl font-bold mb-1"><?= t('order_now') ?></h2>
<p class="text-muted mb-4"><?= t('order_delivery_intro') ?></p>

<?php if ($msg): ?>
  <div class="alert alert-success">
    <?= htmlspecialchars($msg) ?>
    <?php if ($paymentInfo): ?>
      <hr class="my-2 border-success">
      <p class="mb-1"><strong>Référence :</strong> <code class="fs-5 text-success"><?= htmlspecialchars($paymentInfo['reference']) ?></code></p>
      <p class="mb-1 small"><?= htmlspecialchars($paymentInfo['instructions']) ?></p>
    <?php endif; ?>
  </div>
<?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><strong>Erreur :</strong> <?= htmlspecialchars($error) ?></div><?php endif; ?>

<?php if (!$msg): ?>
<form method="post" action="" id="clientOrderForm" novalidate>
  <input type="hidden" name="place_order" value="1">
  <div class="row">
    <div class="col-lg-7 mb-4">
      <div class="card border-0 shadow-sm p-3">
        <h5 class="mb-3"><?= t('menu') ?></h5>
        <?php if (empty($menus)): ?>
          <p class="text-muted">Aucun plat disponible pour le moment.</p>
        <?php else:
          $byCat = [];
          foreach ($menus as $m) $byCat[$m['category'] ?? 'autre'][] = $m;
          foreach ($byCat as $cat => $list):
        ?>
          <div class="small text-muted fw-bold text-uppercase mt-3 mb-2"><?= htmlspecialchars($categories[$cat] ?? $cat) ?></div>
          <div class="row g-3 client-menu-list">
          <?php foreach ($list as $m): ?>
            <div class="col-12 col-sm-6 col-lg-4 client-menu-item">
              <div class="card client-card-menu h-100 border-0 shadow-sm">
                <div class="menu-img client-menu-image">
                  <?php if (!empty($m['image'])): ?>
                    <img src="/uploads/<?= htmlspecialchars($m['image']) ?>" alt="" loading="lazy"
                         onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">
                    <div class="menu-placeholder" style="display:none"><?= strtoupper(substr($m['name'],0,2)) ?></div>
                  <?php else: ?>
                    <div class="menu-placeholder"><?= strtoupper(substr($m['name'],0,2)) ?></div>
                  <?php endif; ?>
                </div>
                <div class="card-body p-2">
                  <div class="fw-semibold small text-truncate"><?= htmlspecialchars($m['name']) ?></div>
                  <div class="text-danger fw-bold"><?= number_format((float)$m['price'],0,',',' ') ?> Ar</div>
                  <?php $menuStock = (int)($m['stock'] ?? 0); ?>
                  <div class="d-flex align-items-center gap-1 mt-1">
                    <?php if ($menuStock <= 0): ?>
                      <span class="badge bg-danger">Épuisé</span>
                      <input type="number" name="items[<?= (int)$m['id'] ?>]" min="0" max="0" value="0"
                             class="form-control form-control-sm qty-input" style="width:60px"
                             data-id="<?= (int)$m['id'] ?>" data-price="<?= (float)$m['price'] ?>" data-stock="0" disabled>
                      <button type="button" class="btn btn-sm btn-outline-secondary add-btn" data-id="<?= (int)$m['id'] ?>" disabled>+</button>
                    <?php else: ?>
                      <span class="small text-muted">Stock : <?= $menuStock ?></span>
                      <input type="number" name="items[<?= (int)$m['id'] ?>]" min="0" max="<?= $menuStock ?>" value="0"
                             class="form-control form-control-sm qty-input" style="width:60px"
                             data-id="<?= (int)$m['id'] ?>" data-price="<?= (float)$m['price'] ?>" data-stock="<?= $menuStock ?>">
                      <button type="button" class="btn btn-sm btn-outline-danger add-btn" data-id="<?= (int)$m['id'] ?>" data-stock="<?= $menuStock ?>">+</button>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </div>

    <div class="col-lg-5 mb-4">
      <div class="card border-0 shadow-sm p-3 sticky-top" style="top:1rem">
        <h5 class="mb-3"><?= t('your_details') ?></h5>
        <div class="mb-2">
          <label class="form-label"><?= t('client_type') ?> *</label>
          <select name="client_type" id="clientType" class="form-select" required>
            <?php foreach (sulaClientTypes() as $code => $label): ?>
              <option value="<?= htmlspecialchars($code) ?>" <?= (($_POST['client_type'] ?? 'individu') === $code) ? 'selected' : '' ?>><?= htmlspecialchars($label) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-2" id="orgBox">
          <label class="form-label"><?= t('organization_family') ?></label>
          <input type="text" name="organization" id="organization" class="form-control" placeholder="<?= t('org_placeholder') ?>"
                 value="<?= htmlspecialchars($_POST['organization'] ?? '') ?>">
        </div>
        <div class="mb-2">
          <label class="form-label" id="clientNameLabel"><?= t('contact_name') ?> *</label>
          <input type="text" name="client_name" class="form-control" required value="<?= htmlspecialchars($_POST['client_name'] ?? '') ?>">
        </div>
        <div class="mb-2">
          <label class="form-label"><?= t('phone_required') ?> *</label>
          <input type="text" name="client_phone" class="form-control" required placeholder="03X XX XXX XX"
                 value="<?= htmlspecialchars($_POST['client_phone'] ?? '') ?>">
        </div>
        <div class="mb-2">
          <label class="form-label"><?= t('delivery_address') ?> *</label>
          <textarea name="client_address" class="form-control" rows="2" required><?= htmlspecialchars($_POST['client_address'] ?? '') ?></textarea>
        </div>
        <div class="mb-2">
          <label class="form-label">Date & heure souhaitées</label>
          <input type="datetime-local" name="delivery_date" class="form-control" value="<?= htmlspecialchars($_POST['delivery_date'] ?? '') ?>">
        </div>
        <div class="mb-2">
          <label class="form-label"><?= t('payment_method') ?></label>
          <select name="payment_method" id="payMethod" class="form-select">
            <option value="cash"><?= t('cash') ?></option>
            <option value="mvola">MVola (<?= htmlspecialchars($merchants['mvola']['number'] ?? '038…') ?>)</option>
            <option value="orange_money">Orange Money</option>
            <option value="airtel_money">Airtel Money</option>
            <option value="virement"><?= t('bank_transfer') ?></option>
            <option value="autre"><?= t('other') ?></option>
          </select>
        </div>
        <div id="payerBox" class="d-none border rounded p-2 mb-2">
          <p class="small text-muted mb-2"><?= t('payer_auto_hint') ?></p>
          <div class="mb-2">
            <label class="form-label"><?= t('payer_name') ?></label>
            <input type="text" name="payer_name" class="form-control" value="<?= htmlspecialchars($_POST['payer_name'] ?? '') ?>">
          </div>
          <div class="mb-2">
            <label class="form-label"><?= t('payer_phone') ?></label>
            <input type="text" name="payer_phone" class="form-control" placeholder="03X XX XXX XX" value="<?= htmlspecialchars($_POST['payer_phone'] ?? '') ?>">
          </div>
        </div>
        <div class="mb-3">
          <label class="form-label"><?= t('notes') ?></label>
          <textarea name="notes" class="form-control" rows="2" placeholder="Précisions, allergènes..."><?= htmlspecialchars($_POST['notes'] ?? '') ?></textarea>
        </div>
        <div class="d-flex justify-content-between align-items-center mb-3 p-2 rounded border">
          <span class="text-muted small"><?= t('order_total') ?></span>
          <strong id="liveTotal" class="text-warning fs-5">0 Ar</strong>
        </div>
        <button type="submit" class="btn btn-danger w-100 btn-lg" id="btnSubmitOrder">
          <i class="fa-solid fa-paper-plane me-1"></i> <?= t('place_order') ?>
        </button>
        <p class="small text-muted mt-2 mb-0">Hors cash : vous serez redirigé vers la page de paiement (référence SURA-…).</p>
      </div>
    </div>
  </div>
</form>
<?php endif; ?>

<script>
(function(){
  var payMethod = document.getElementById('payMethod');
  var payerBox = document.getElementById('payerBox');
  if (payMethod && payerBox) {
    function syncPay() {
      var isCash = payMethod.value === 'cash';
      payerBox.classList.toggle('d-none', isCash);
      if (!isCash) {
        var cn = document.querySelector('input[name="client_name"]');
        var cp = document.querySelector('input[name="client_phone"]');
        var pn = document.querySelector('input[name="payer_name"]');
        var pp = document.querySelector('input[name="payer_phone"]');
        if (cn && pn && !pn.value) pn.value = cn.value;
        if (cp && pp && !pp.value) pp.value = cp.value;
      }
    }
    payMethod.addEventListener('change', syncPay);
    var cn = document.querySelector('input[name="client_name"]');
    var cp = document.querySelector('input[name="client_phone"]');
    if (cn) cn.addEventListener('input', function(){
      if (payMethod.value !== 'cash') {
        var pn = document.querySelector('input[name="payer_name"]');
        if (pn) pn.value = cn.value;
      }
    });
    if (cp) cp.addEventListener('input', function(){
      if (payMethod.value !== 'cash') {
        var pp = document.querySelector('input[name="payer_phone"]');
        if (pp) pp.value = cp.value;
      }
    });
    syncPay();
  }
  document.querySelectorAll('.add-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var id = this.getAttribute('data-id');
      var input = document.querySelector('.qty-input[data-id="'+id+'"]');
      if (input && !input.disabled) {
        var stock = parseInt(input.getAttribute('data-stock') || input.getAttribute('max') || '0', 10);
        var next = parseInt(input.value || '0', 10) + 1;
        input.value = Math.min(next, stock);
        calcTotal();
      }
    });
  });
  function calcTotal() {
    var t = 0;
    document.querySelectorAll('.qty-input').forEach(function(inp) {
      var q = parseInt(inp.value || '0', 10);
      var p = parseFloat(inp.getAttribute('data-price') || '0');
      if (q > 0) t += q * p;
    });
    var el = document.getElementById('liveTotal');
    if (el) el.textContent = t.toLocaleString('fr-FR') + ' Ar';
  }
  document.querySelectorAll('.qty-input').forEach(function(inp) {
    function clampQuantity() {
      if (inp.disabled) { inp.value = 0; return; }
      var max = parseInt(inp.getAttribute('data-stock') || inp.getAttribute('max') || '0', 10);
      var q = parseInt(inp.value || '0', 10);
      if (q < 0 || !Number.isFinite(q)) q = 0;
      if (q > max) q = max;
      inp.value = q;
    }
    inp.addEventListener('input', function(){ clampQuantity(); calcTotal(); });
    inp.addEventListener('change', function(){ clampQuantity(); calcTotal(); });
  });
  var ct = document.getElementById('clientType');
  var orgBox = document.getElementById('orgBox');
  var nameLabel = document.getElementById('clientNameLabel');
  function syncClientType() {
    if (!ct) return;
    var v = ct.value;
    var needsOrg = ['famille','association','entreprise','institution','ecole','hotel','groupe','autre'].indexOf(v) >= 0;
    if (orgBox) orgBox.style.display = needsOrg ? '' : 'none';
    if (nameLabel) {
      nameLabel.textContent = (v === 'individu' || v === 'couple') ? '<?= t('your_name') ?> *' : 'Nom du contact / responsable *';
    }
  }
  if (ct) { ct.addEventListener('change', syncClientType); syncClientType(); }

  var form = document.getElementById('clientOrderForm');
  if (form) {
    form.addEventListener('submit', function(e) {
      var hasItem = false;
      document.querySelectorAll('.qty-input').forEach(function(inp) {
        if (parseInt(inp.value || '0', 10) > 0) hasItem = true;
      });
      if (!hasItem) {
        e.preventDefault();
        alert('Ajoutez au moins un plat (quantité > 0).');
        return false;
      }
      var btn = document.getElementById('btnSubmitOrder');
      if (btn) { btn.disabled = true; btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin me-1"></i> Envoi…'; }
    });
  }
})();
</script>
<?php require __DIR__ . '/_footer.php'; ?>
