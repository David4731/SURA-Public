<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/lang.php';
require_once __DIR__ . '/../includes/notify.php';
$clientPage = 'avis';
$pageTitle = t('feedback_title');
$pdo = getPDO();
$msg = '';
$error = '';

// Ensure reviews table
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS reviews (
      id INT AUTO_INCREMENT PRIMARY KEY,
      client_name VARCHAR(100) NOT NULL,
      client_phone VARCHAR(30) NULL,
      rating TINYINT NOT NULL DEFAULT 5,
      comment TEXT,
      status ENUM('pending','published','hidden') NOT NULL DEFAULT 'pending',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? 'avis';
    try {
        if ($type === 'avis') {
            $pdo->prepare('INSERT INTO reviews (client_name, client_phone, rating, comment, status) VALUES (?,?,?,?,"pending")')
                ->execute([
                    trim($_POST['client_name']),
                    trim($_POST['client_phone'] ?? ''),
                    max(1, min(5, (int)$_POST['rating'])),
                    trim($_POST['comment'] ?? '')
                ]);
            sulaNotify($pdo, 'Nouvel avis client',
                trim($_POST['client_name']) . ' — note ' . max(1, min(5, (int)$_POST['rating'])) . '/5',
                'feedback');
            $msg = 'Merci pour votre avis ! Il sera publié après validation.';
        } else {
            // proposition de plat
            $pdo->prepare('INSERT INTO dish_proposals (proposed_by, name, description, suggested_price, status) VALUES (NULL,?,?,?,"pending")')
                ->execute([
                    trim($_POST['dish_name']),
                    trim($_POST['dish_desc'] ?? ''),
                    (float)($_POST['suggested_price'] ?? 0) ?: null
                ]);
            sulaNotify($pdo, 'Proposition plat client',
                trim($_POST['dish_name']) . ' — a valider (stock/checker)',
                'proposal');
            $msg = 'Proposition envoyee ! Le Stock Manager l etudiera.';
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

$published = [];
try {
    $published = $pdo->query("SELECT * FROM reviews WHERE status='published' ORDER BY id DESC LIMIT 12")->fetchAll();
} catch (Exception $e) {}

require __DIR__ . '/_header.php';
?>
<h2 class="font-serif text-2xl font-bold mb-1"><?= t('feedback') ?></h2>
<p class="text-muted mb-4">Partagez votre expérience ou proposez un nouveau plat.</p>

<?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="row g-4">
  <div class="col-md-6">
    <div class="card border-0 shadow-sm p-4 h-100">
      <h5 class="mb-3"><?= t('leave_review') ?></h5>
      <form method="post">
        <input type="hidden" name="type" value="avis">
        <div class="mb-2">
          <label class="form-label">Votre nom *</label>
          <input type="text" name="client_name" class="form-control" required>
        </div>
        <div class="mb-2">
          <label class="form-label"><?= t('phone') ?></label>
          <input type="text" name="client_phone" class="form-control">
        </div>
        <div class="mb-2">
          <label class="form-label"><?= t('rating') ?></label>
          <select name="rating" class="form-select">
            <option value="5">⭐⭐⭐⭐⭐ <?= t('rating_5') ?></option>
            <option value="4">⭐⭐⭐⭐ <?= t('rating_4') ?></option>
            <option value="3">⭐⭐⭐ <?= t('rating_3') ?></option>
            <option value="2">⭐⭐ <?= t('rating_2') ?></option>
            <option value="1">⭐ <?= t('rating_1') ?></option>
          </select>
        </div>
        <div class="mb-3">
          <label class="form-label"><?= t('comment') ?></label>
          <textarea name="comment" class="form-control" rows="3" placeholder="<?= t('comment_placeholder') ?>"></textarea>
        </div>
        <button class="btn btn-danger w-100"><?= t('send_review') ?></button>
      </form>
    </div>
  </div>

  <div class="col-md-6">
    <div class="card border-0 shadow-sm p-4 h-100">
      <h5 class="mb-3"><?= t('suggest_dish') ?></h5>
      <form method="post">
        <input type="hidden" name="type" value="proposition">
        <div class="mb-2">
          <label class="form-label"><?= t('dish_name') ?> *</label>
          <input type="text" name="dish_name" class="form-control" required>
        </div>
        <div class="mb-2">
          <label class="form-label"><?= t('description') ?></label>
          <textarea name="dish_desc" class="form-control" rows="3" placeholder="Ingrédients, style..."></textarea>
        </div>
        <div class="mb-3">
          <label class="form-label"><?= t('suggested_price') ?></label>
          <input type="number" name="suggested_price" class="form-control" step="100" placeholder="Optionnel">
        </div>
        <button class="btn btn-outline-danger w-100"><?= t('send_proposal') ?></button>
      </form>
    </div>
  </div>
</div>

<?php if ($published): ?>
<div class="mt-5">
  <h5 class="mb-3"><?= t('published_reviews') ?></h5>
  <div class="row g-3">
    <?php foreach ($published as $r): ?>
      <div class="col-md-4">
        <div class="card border-0 shadow-sm p-3 h-100">
          <div class="text-warning mb-1"><?= str_repeat('⭐', (int)$r['rating']) ?></div>
          <p class="mb-1 small"><?= htmlspecialchars($r['comment'] ?? '') ?></p>
          <div class="text-muted small">— <?= htmlspecialchars($r['client_name']) ?></div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/_footer.php'; ?>
