<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../includes/lang.php';
$cur = currentLang();
$flags = langFlags();
$pageTitle = $pageTitle ?? 'SURA';
$script = basename($_SERVER['SCRIPT_NAME'] ?? '');
?>
<!DOCTYPE html>
<html lang="<?= $cur ?>" class="h-full" data-theme="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
  <title><?= htmlspecialchars($pageTitle) ?> · SURA Luxury</title>
  <script>
  (function(){try{var th=localStorage.getItem('sura-theme')||'dark';document.documentElement.setAttribute('data-theme',th);}catch(e){document.documentElement.setAttribute('data-theme','dark');}})();
  </script>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="/assets/css/style.css" rel="stylesheet">
  <script>
    tailwind.config = {
      theme: {
        extend: {
          colors: {
            gold: { 300:'#f6e05e', 400:'#ecc94b', 500:'#d4af37', 600:'#b78a28' },
            onyx: { 800:'#1A1A1E', 900:'#121215', 950:'#0A0A0C' }
          },
          fontFamily: {
            serif: ['Playfair Display', 'serif'],
            sans: ['Plus Jakarta Sans', 'sans-serif'],
          }
        }
      }
    }
  </script>
  <style id="sura-theme-css">
    html[data-theme="light"] body { background:#f3efe6!important; color:#1c1917!important; }
    html[data-theme="light"] .glass-nav, html[data-theme="light"] .glass-card, html[data-theme="light"] .card {
      background:#fff!important; color:#1c1917!important; border-color:rgba(183,138,40,.28)!important;
    }
    html[data-theme="light"] .text-slate-100, html[data-theme="light"] .text-slate-200, html[data-theme="light"] h1, html[data-theme="light"] h2 {
      color:#1c1917!important;
    }
    html[data-theme="light"] .text-slate-400 { color:#78716c!important; }
    html[data-theme="light"] input, html[data-theme="light"] select, html[data-theme="light"] textarea, html[data-theme="light"] .form-control {
      background:#fff!important; color:#1c1917!important;
    }
  
  /* client-form-polish */
  .card { background: rgba(26,26,30,0.85) !important; border: 1px solid rgba(212,175,55,0.2) !important; border-radius: 1rem !important; color: #e2e8f0; }
  .form-control, .form-select { background: rgba(10,10,12,0.6) !important; border-color: rgba(212,175,55,0.25) !important; color: #f1f5f9 !important; }
  .form-label { color: #94a3b8; font-size: 0.8rem; }
  .btn-danger { background: linear-gradient(135deg, #b78a28, #d4af37) !important; border: none !important; color: #0a0a0c !important; font-weight: 600; }
  html[data-theme="light"] .card { background: #fff !important; color: #1c1917 !important; }
  html[data-theme="light"] .form-control, html[data-theme="light"] .form-select { background: #fff !important; color: #1c1917 !important; }
</style>
<style>.dropdown{z-index:300000!important}.dropdown-menu{z-index:300002!important;position:absolute!important}header,.glass-nav{z-index:100000;position:relative}</style>
</head>
<body class="bg-onyx-950 text-slate-100 font-sans min-h-screen flex flex-col">
  <header class="glass-nav sticky top-0 z-40 border-b border-gold-500/20">
    <div class="max-w-6xl mx-auto px-4 py-3 flex flex-wrap items-center justify-between gap-3">
      <a href="/client/index.php" class="flex items-center gap-3 no-underline">
        <img src="/assets/img/sura-logo.png" alt="SURA" class="w-10 h-10 object-contain">
        <div>
          <span class="font-serif text-xl font-bold gold-gradient-text">SURA</span>
          <span class="block text-[10px] uppercase tracking-widest text-gold-400">Luxury · Client</span>
        </div>
      </a>
      <nav class="flex flex-wrap items-center gap-1 text-sm">
        <div class="client-nav-links flex items-center gap-1 flex-1 min-w-0">
        <a href="/client/index.php" class="px-3 py-1.5 rounded-lg <?= $script==='index.php'?'text-gold-400 bg-gold-500/15':'text-slate-400 hover:text-gold-400' ?>"><?= t('home') ?></a>
        <a href="/client/order.php" class="px-3 py-1.5 rounded-lg <?= $script==='order.php'?'text-gold-400 bg-gold-500/15':'text-slate-400 hover:text-gold-400' ?>"><?= t('order_now') ?></a>
        <a href="/client/reservation.php" class="px-3 py-1.5 rounded-lg <?= $script==='reservation.php'?'text-gold-400 bg-gold-500/15':'text-slate-400 hover:text-gold-400' ?>"><?= t('book_table') ?></a>
        <a href="/client/avis.php" class="px-3 py-1.5 rounded-lg <?= $script==='avis.php'?'text-gold-400 bg-gold-500/15':'text-slate-400 hover:text-gold-400' ?>"><?= t('feedback') ?></a>
        </div>
      </nav>
      <div class="flex items-center gap-2">
        <button type="button" id="themeToggle" class="p-2 rounded-full border border-gold-500/30 text-gold-400" title="<?= htmlspecialchars(t('theme_toggle')) ?>">
          <i class="fa-solid fa-sun" id="themeIconSun"></i>
          <i class="fa-solid fa-moon hidden" id="themeIconMoon"></i>
        </button>
        <!-- Langue : liens directs (fiable sans Bootstrap JS) -->
        <div class="relative" id="clientLangWrap" style="z-index:300001">
          <button type="button" id="clientLangBtn" class="p-2 rounded-full border border-gold-500/30 text-gold-400 text-xs hover:border-gold-400"
                  aria-haspopup="true" aria-expanded="false">
            <?= htmlspecialchars($flags[$cur] ?? '🌐') ?>
          </button>
          <div id="clientLangMenu" class="hidden absolute right-0 mt-2 min-w-[11rem] rounded-xl border border-gold-500/30 shadow-2xl py-1"
               style="background:#121215;z-index:300002">
            <?php foreach ($flags as $code => $label):
              $href = function_exists('sulaLangUrl') ? sulaLangUrl($code) : ('?lang=' . urlencode($code));
              $active = ($code === $cur);
            ?>
              <a href="<?= htmlspecialchars($href) ?>"
                 class="block px-3 py-2 text-sm no-underline hover:bg-gold-500/15 <?= $active ? 'text-gold-400 font-semibold' : 'text-slate-200' ?>">
                <?= htmlspecialchars($label) ?>
              </a>
            <?php endforeach; ?>
          </div>
        </div>
        <script>
        (function(){
          var btn = document.getElementById('clientLangBtn');
          var menu = document.getElementById('clientLangMenu');
          if (!btn || !menu) return;
          btn.addEventListener('click', function(e){
            e.preventDefault(); e.stopPropagation();
            menu.classList.toggle('hidden');
            btn.setAttribute('aria-expanded', menu.classList.contains('hidden') ? 'false' : 'true');
          });
          document.addEventListener('click', function(e){
            if (!e.target.closest('#clientLangWrap')) menu.classList.add('hidden');
          });
        })();
        </script>
        <a href="/index.php" class="text-xs text-slate-400 hover:text-gold-400 px-2"><?= t('login') ?></a>
      </div>
    </div>
  </header>
  <main class="flex-1 max-w-6xl mx-auto w-full px-3 sm:px-4 py-4 sm:py-6">
