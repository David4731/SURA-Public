  </main>

  <nav class="sula-client-mnav" id="sulaClientMnav"
       hidden aria-label="Menu client">

    <a href="/client/index.php"
       class="<?= basename($_SERVER['SCRIPT_NAME'] ?? '') === 'index.php' ? 'active' : '' ?>">
      <i class="fa-solid fa-house"></i>
      <span><?= t('home') ?></span>
    </a>

    <a href="/client/order.php"
       class="<?= basename($_SERVER['SCRIPT_NAME'] ?? '') === 'order.php' ? 'active' : '' ?>">
      <i class="fa-solid fa-utensils"></i>
      <span><?= t('order_now') ?></span>
    </a>

    <a href="/client/reservation.php"
       class="<?= basename($_SERVER['SCRIPT_NAME'] ?? '') === 'reservation.php' ? 'active' : '' ?>">
      <i class="fa-solid fa-calendar"></i>
      <span><?= t('book_table') ?></span>
    </a>

    <a href="/client/avis.php"
       class="<?= basename($_SERVER['SCRIPT_NAME'] ?? '') === 'avis.php' ? 'active' : '' ?>">
      <i class="fa-solid fa-star"></i>
      <span><?= t('feedback') ?></span>
    </a>
  </nav>

  <footer class="sula-mobile-footer border-t border-gold-500/15 py-5 px-4 mt-auto">
    <div class="max-w-6xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4 text-xs text-slate-400">

      <div class="flex items-center gap-2">
        <img src="/assets/img/sura-logo.png" alt="SURA"
             class="w-8 h-8 object-contain">
        <span class="gold-gradient-text font-serif font-semibold">SURA</span>
        <span>· Olympia Tanjombato</span>
      </div>

      <div class="flex flex-wrap gap-2">
        <span class="pay-brand mvola">MVola 038 24 541 74</span>
        <span class="pay-brand orange">Orange Money</span>
        <span class="pay-brand airtel">Airtel Money</span>
      </div>

      <div class="flex items-center gap-2">
        <a href="https://wa.me/261382454174" target="_blank"
           rel="noopener" class="social-btn" title="WhatsApp">
          <i class="fa-brands fa-whatsapp"></i>
        </a>
        <a href="https://www.facebook.com/David.Herinantenaina"
           target="_blank" rel="noopener" class="social-btn" title="Facebook">
          <i class="fa-brands fa-facebook-f"></i>
        </a>
        <a href="https://www.instagram.com/herinantenaina.david"
           target="_blank" rel="noopener" class="social-btn" title="Instagram">
          <i class="fa-brands fa-instagram"></i>
        </a>
        <a href="https://www.tiktok.com/@herinantenaina.david"
           target="_blank" rel="noopener" class="social-btn" title="TikTok">
          <i class="fa-brands fa-tiktok"></i>
        </a>
        <a href="/index.php" class="text-gold-400 hover:underline ml-2">
          <?= t('login') ?> équipe
        </a>
      </div>
    </div>
  </footer>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

  <script>
  (function () {
    function getTheme() {
      try {
        return localStorage.getItem('sura-theme') || 'dark';
      } catch (e) {
        return 'dark';
      }
    }

    function setTheme(theme) {
      document.documentElement.setAttribute('data-theme', theme);

      try {
        localStorage.setItem('sura-theme', theme);
      } catch (e) {}

      var sun = document.getElementById('themeIconSun');
      var moon = document.getElementById('themeIconMoon');

      if (sun && moon) {
        sun.classList.toggle('hidden', theme === 'light');
        moon.classList.toggle('hidden', theme !== 'light');
      }
    }

    setTheme(getTheme());

    document.addEventListener('click', function (e) {
      if (!e.target.closest('#themeToggle')) return;

      e.preventDefault();
      setTheme(getTheme() === 'light' ? 'dark' : 'light');
    });

    var nav = document.getElementById('sulaClientMnav');

    function syncNav() {
      if (!nav) return;

      var mobile = window.matchMedia('(max-width: 767px)').matches;
      nav.hidden = !mobile;
      nav.style.display = mobile ? 'flex' : 'none';
    }

    syncNav();
    window.addEventListener('resize', syncNav);
  })();
  </script>

</body>
</html>