<?php
/**
 * Reservations SURA — tables, salles, partitions, toutes salles
 * Checker approuve → parties marquees reserved automatiquement
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/client_types.php';
require_once __DIR__ . '/../includes/notify.php';
requireRole(['checker', 'admin']);

$pageTitle = t('reservations');
$pdo = getPDO();
if (function_exists('sulaEnsureClientTypeColumn')) { try { sulaEnsureClientTypeColumn($pdo); } catch (Exception $e) {} }
$user = currentUser();
$msg = '';
$error = '';

// ---- Schema soft upgrade ----
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS restaurant_tables (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(50) NULL,
      code VARCHAR(30) NOT NULL UNIQUE,
      label VARCHAR(100) NOT NULL,
      zone ENUM('salle','terrasse','vip','bar','autre') NOT NULL DEFAULT 'salle',
      space_type ENUM('table','salle','partition') NOT NULL DEFAULT 'table',
      capacity INT NOT NULL DEFAULT 4,
      status ENUM('free','occupied','reserved') NOT NULL DEFAULT 'free',
      current_order_id INT NULL,
      guest_name VARCHAR(100) NULL,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      notes VARCHAR(255) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}

foreach ([
    "ALTER TABLE restaurant_tables ADD COLUMN space_type ENUM('table','salle','partition') NOT NULL DEFAULT 'table'",
    "ALTER TABLE restaurant_tables ADD COLUMN status ENUM('free','occupied','reserved') NOT NULL DEFAULT 'free'",
    "ALTER TABLE restaurant_tables ADD COLUMN name VARCHAR(50) NULL",
    "ALTER TABLE reservations ADD COLUMN reserve_type ENUM('table','multi_table','salle','all_salles','partition') NOT NULL DEFAULT 'table'",
    "ALTER TABLE reservations ADD COLUMN space_codes VARCHAR(255) NULL",
    "ALTER TABLE reservations ADD COLUMN tables_count INT NOT NULL DEFAULT 1",
] as $sql) {
    try { $pdo->exec($sql); } catch (Exception $e) {}
}

// Seed: 2 salles (~25p) + terrasse (~50p) + 50 tables + partitions
try {
    $cnt = (int)$pdo->query("SELECT COUNT(*) FROM restaurant_tables")->fetchColumn();
    if ($cnt < 5) {
        if ($cnt > 0) {
            // replace incomplete demo data
            try { $pdo->exec("DELETE FROM restaurant_tables"); } catch (Exception $e) {}
        }
        $pdo->exec("INSERT INTO restaurant_tables (code,label,name,zone,space_type,capacity,status) VALUES
          ('SALLE1','Salle 1 (Restaurant)','Salle 1','salle','salle',25,'free'),
          ('SALLE2','Salle 2 (Restaurant)','Salle 2','salle','salle',25,'free'),
          ('TERRASSE','Terrasse — Open-Bar & Grillades','Terrasse','terrasse','salle',50,'free')
        ");
        $vals = [];
        for ($i = 1; $i <= 20; $i++) {
            $vals[] = sprintf("('T%d','Table %d — Salle 1','T%d','salle','table',6,'free')", $i, $i, $i);
        }
        for ($i = 21; $i <= 35; $i++) {
            $vals[] = sprintf("('T%d','Table %d — Salle 2','T%d','salle','table',6,'free')", $i, $i, $i);
        }
        for ($i = 36; $i <= 50; $i++) {
            $vals[] = sprintf("('T%d','Table %d — Terrasse','T%d','terrasse','table',6,'free')", $i, $i, $i);
        }
        $vals[] = "('P1-S1','Partition Salle 1 · T1-T4','Partition S1-A','salle','partition',24,'free')";
        $vals[] = "('P2-S1','Partition Salle 1 · T5-T8','Partition S1-B','salle','partition',24,'free')";
        $vals[] = "('P3-S1','Partition Salle 1 · T9-T12','Partition S1-C','salle','partition',24,'free')";
        $vals[] = "('P1-S2','Partition Salle 2 · T21-T24','Partition S2-A','salle','partition',24,'free')";
        $vals[] = "('P2-S2','Partition Salle 2 · T25-T28','Partition S2-B','salle','partition',24,'free')";
        $vals[] = "('P1-TR','Partition Terrasse · T36-T40','Partition Terrasse A','terrasse','partition',30,'free')";
        $vals[] = "('P2-TR','Partition Terrasse · T41-T45','Partition Terrasse B','terrasse','partition',30,'free')";
        $pdo->exec("INSERT INTO restaurant_tables (code,label,name,zone,space_type,capacity,status) VALUES " . implode(',', $vals));
    }
} catch (Exception $e) {}

/** Mark spaces reserved or free */
function setSpacesStatus(PDO $pdo, $codesCsv, $status, $guest = null) {
    if (!$codesCsv) return;
    $codes = array_filter(array_map('trim', explode(',', $codesCsv)));
    foreach ($codes as $code) {
        try {
            if ($status === 'free') {
                $pdo->prepare("UPDATE restaurant_tables SET status='free', guest_name=NULL WHERE code=? OR name=?")->execute([$code, $code]);
            } else {
                $pdo->prepare("UPDATE restaurant_tables SET status=?, guest_name=? WHERE code=? OR name=?")->execute([$status, $guest, $code, $code]);
            }
        } catch (Exception $e) {}
    }
    // all salles
    if (in_array('ALL_SALLES', $codes, true) || $codesCsv === 'ALL_SALLES') {
        try {
            if ($status === 'free') {
                $pdo->exec("UPDATE restaurant_tables SET status='free', guest_name=NULL WHERE space_type='salle'");
            } else {
                $st = $pdo->prepare("UPDATE restaurant_tables SET status=?, guest_name=? WHERE space_type='salle'");
                $st->execute([$status, $guest]);
            }
        } catch (Exception $e) {}
    }
}

// ---- RESEED layout (admin) ----
if (isset($_GET['reseed']) && $user['role'] === 'admin') {
    try {
        $pdo->exec("DELETE FROM restaurant_tables");
        header('Location: /pages/reservations.php');
        exit;
    } catch (Exception $e) {}
}


// ---- Quick click actions from visual map ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'map_click') {
    $code = trim($_POST['space_code'] ?? '');
    $act = $_POST['map_action'] ?? '';
    try {
        $st = $pdo->prepare("SELECT * FROM restaurant_tables WHERE code=? LIMIT 1");
        $st->execute([$code]);
        $sp = $st->fetch();
        if (!$sp && $code !== 'ALL_SALLES') throw new Exception('Espace introuvable');

        if ($act === 'free_occupied') {
            // occupied -> free
            if ($code === 'ALL_SALLES') {
                $pdo->exec("UPDATE restaurant_tables SET status='free', guest_name=NULL, current_order_id=NULL");
            } else {
                $pdo->prepare("UPDATE restaurant_tables SET status='free', guest_name=NULL, current_order_id=NULL WHERE code=?")->execute([$code]);
                // if salle: free all tables in zone
                if (($sp['space_type'] ?? '') === 'salle') {
                    $zone = $sp['zone'] ?? 'salle';
                    $codeS = $sp['code'];
                    if ($codeS === 'SALLE1') {
                        $pdo->exec("UPDATE restaurant_tables SET status='free', guest_name=NULL WHERE space_type='table' AND zone='salle' AND CAST(SUBSTRING(code,2) AS UNSIGNED) BETWEEN 1 AND 20");
                    } elseif ($codeS === 'SALLE2') {
                        $pdo->exec("UPDATE restaurant_tables SET status='free', guest_name=NULL WHERE space_type='table' AND zone='salle' AND CAST(SUBSTRING(code,2) AS UNSIGNED) BETWEEN 21 AND 35");
                    } elseif ($codeS === 'TERRASSE') {
                        $pdo->exec("UPDATE restaurant_tables SET status='free', guest_name=NULL WHERE space_type='table' AND zone='terrasse'");
                    }
                }
            }
            $msg = "$code libere.";
        } elseif ($act === 'occupy') {
            $pdo->prepare("UPDATE restaurant_tables SET status='occupied' WHERE code=?")->execute([$code]);
            $msg = "$code marque occupe.";
        } elseif ($act === 'quick_reserve') {
            $name = trim($_POST['client_name'] ?? '');
            $clientType = function_exists('sulaNormalizeClientType') ? sulaNormalizeClientType($_POST['client_type'] ?? 'individu') : 'individu';
            $organization = trim($_POST['organization'] ?? '');
            $phone = trim($_POST['client_phone'] ?? '');
            $guests = max(1, (int)($_POST['guests'] ?? 4));
            $date = $_POST['reservation_date'] ?? date('Y-m-d');
            $time = $_POST['reservation_time'] ?? '19:00';
            $notes = trim($_POST['notes'] ?? '');
            if ($name === '') throw new Exception('Nom client obligatoire pour reserver.');
            $label = $code;
            $rtype = 'table';
            if ($sp) {
                if (($sp['space_type'] ?? '') === 'salle') $rtype = ($code === 'TERRASSE' ? 'salle' : 'salle');
                if (($sp['space_type'] ?? '') === 'partition') $rtype = 'partition';
            }
            try {
                $pdo->prepare('INSERT INTO reservations (client_name,client_phone,guests,reservation_date,reservation_time,table_partition,reserve_type,space_codes,tables_count,payment_status,paid_amount,notes,created_by,status) VALUES (?,?,?,?,?,?,?,?,1,"not_paid",0,?,?,"confirmed")')
                    ->execute([$name, $phone, $guests, $date, $time, $label, $rtype, $code, $notes ?: null, $user['id']]);
            } catch (Exception $ex) {
                $pdo->prepare('INSERT INTO reservations (client_name,client_phone,guests,reservation_date,reservation_time,table_partition,payment_status,paid_amount,notes,created_by,status) VALUES (?,?,?,?,?,?,"not_paid",0,?,?,"confirmed")')
                    ->execute([$name, $phone, $guests, $date, $time, $label, $notes ?: null, $user['id']]);
            }
            setSpacesStatus($pdo, $code, 'reserved', $name);
            sulaNotify($pdo, 'Reservation map #' . $pdo->lastInsertId(), "$name — $code — $date $time", 'reservation');
            $msg = "Table/espace $code reserve pour $name.";
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}


// ---- CREATE ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
    try {
        $name = trim($_POST['client_name'] ?? '');
        $phone = trim($_POST['client_phone'] ?? '');
        $guests = max(1, (int)($_POST['guests'] ?? 2));
        $date = $_POST['reservation_date'] ?? '';
        $time = $_POST['reservation_time'] ?? '';
        $rtype = $_POST['reserve_type'] ?? 'table';
        $tablesCount = max(1, (int)($_POST['tables_count'] ?? 1));
        $notes = trim($_POST['notes'] ?? '');
        $codes = [];

        if ($name === '' || $date === '' || $time === '') {
            throw new Exception('Nom, date et heure obligatoires.');
        }
        if (!in_array($rtype, ['table','multi_table','salle','all_salles','partition'], true)) {
            $rtype = 'table';
        }

        // Capacity: 1 table = 4 a 8 personnes
        if (in_array($rtype, ['table','multi_table','partition'], true)) {
            $minG = $tablesCount * 4;
            $maxG = $tablesCount * 8;
            if ($guests < $minG || $guests > $maxG) {
                throw new Exception("Pour $tablesCount table(s) : entre $minG et $maxG personnes (4 a 8 par table).");
            }
        }

        if ($rtype === 'all_salles') {
            $codes = ['ALL_SALLES'];
            $label = 'Toutes les salles';
        } elseif ($rtype === 'salle') {
            $code = trim($_POST['space_code'] ?? '');
            if ($code === '') throw new Exception('Choisissez une salle.');
            $codes = [$code];
            $label = $code;
        } elseif ($rtype === 'partition') {
            $code = trim($_POST['space_code'] ?? '');
            if ($code === '') throw new Exception('Choisissez une partition.');
            $codes = [$code];
            $label = $code . ' (' . $tablesCount . ' tables)';
        } elseif ($rtype === 'multi_table') {
            $selected = $_POST['table_codes'] ?? [];
            if (!is_array($selected)) $selected = [];
            $selected = array_values(array_filter(array_map('trim', $selected)));
            if (count($selected) < 1) throw new Exception('Selectionnez au moins une table.');
            $codes = $selected;
            $tablesCount = count($selected);
            $minG = $tablesCount * 4;
            $maxG = $tablesCount * 8;
            if ($guests < $minG || $guests > $maxG) {
                throw new Exception("Pour $tablesCount table(s) : entre $minG et $maxG personnes.");
            }
            $label = implode(', ', $codes);
        } else {
            $code = trim($_POST['space_code'] ?? '');
            if ($code === '') throw new Exception('Choisissez une table.');
            $codes = [$code];
            $tablesCount = 1;
            $label = $code;
        }

        $codesCsv = implode(',', $codes);

        // Check free (skip if already reserved that day - soft)
        if ($rtype !== 'all_salles') {
            foreach ($codes as $c) {
                $st = $pdo->prepare("SELECT status, label FROM restaurant_tables WHERE code=? OR name=? LIMIT 1");
                $st->execute([$c, $c]);
                $row = $st->fetch();
                if ($row && $row['status'] === 'reserved') {
                    // still allow pending request; checker decides
                }
            }
        }

        try {
            $pdo->prepare('INSERT INTO reservations (client_name,client_phone,guests,reservation_date,reservation_time,table_partition,reserve_type,space_codes,tables_count,payment_status,paid_amount,notes,created_by,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,"pending")')
                ->execute([
                    $name, $phone, $guests, $date, $time, $label, $rtype, $codesCsv, $tablesCount,
                    $_POST['payment_status'] ?? 'not_paid', (float)($_POST['paid_amount'] ?? 0), $notes ?: null, $user['id']
                ]);
        } catch (Exception $ex) {
            // fallback without new columns
            $pdo->prepare('INSERT INTO reservations (client_name,client_phone,guests,reservation_date,reservation_time,table_partition,payment_status,paid_amount,notes,created_by,status) VALUES (?,?,?,?,?,?,?,?,?,?,"pending")')
                ->execute([$name, $phone, $guests, $date, $time, $label, $_POST['payment_status'] ?? 'not_paid', (float)($_POST['paid_amount'] ?? 0), $notes ?: null, $user['id']]);
        }

        sulaNotify($pdo, 'Nouvelle reservation #' . $pdo->lastInsertId(), "$name — $guests pers. — $date $time — $label", 'reservation');
        try {
            $rid = (int)$pdo->lastInsertId();
            if ($rid > 0) $pdo->prepare('UPDATE reservations SET client_type=? WHERE id=?')->execute([$clientType ?? 'individu', $rid]);
        } catch (Exception $e) {}
        $msg = 'Reservation enregistree (en attente confirmation).';
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}


// ---- Manual status change (checker) ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'set_space_status') {
    $code = trim($_POST['space_code'] ?? '');
    $newStatus = $_POST['new_status'] ?? 'free';
    if ($code !== '' && in_array($newStatus, ['free','occupied','reserved'], true)) {
        try {
            if ($code === 'ALL_SALLES') {
                $pdo->prepare("UPDATE restaurant_tables SET status=?, guest_name=IF(?='free',NULL,guest_name) WHERE space_type='salle'")->execute([$newStatus, $newStatus]);
            } else {
                $pdo->prepare("UPDATE restaurant_tables SET status=?, guest_name=IF(?='free',NULL,guest_name) WHERE code=?")->execute([$newStatus, $newStatus, $code]);
            }
            $msg = "Statut de $code → $newStatus";
        } catch (Exception $e) {
            $error = $e->getMessage();
        }
    }
}

// ---- STATUS UPDATE (approve → reserve spaces) ----
if (isset($_GET['status'], $_GET['id'])) {
    $st = $_GET['status'];
    $id = (int)$_GET['id'];
    if (in_array($st, ['confirmed', 'cancelled', 'completed', 'pending'], true) && $id > 0) {
        $row = $pdo->prepare('SELECT * FROM reservations WHERE id=?');
        $row->execute([$id]);
        $res = $row->fetch();
        if ($res) {
            $pdo->prepare('UPDATE reservations SET status=? WHERE id=?')->execute([$st, $id]);
            $codes = $res['space_codes'] ?? $res['table_partition'] ?? '';
            if ($st === 'confirmed') {
                setSpacesStatus($pdo, $codes, 'reserved', $res['client_name']);
                sulaNotify($pdo, 'Reservation confirmee #' . $id, ($res['client_name'] ?? '') . ' — espaces marques reserves', 'reservation');
            } elseif (in_array($st, ['cancelled', 'completed'], true)) {
                setSpacesStatus($pdo, $codes, 'free', null);
            }
        }
    }
    header('Location: /pages/reservations.php?ok=1');
    exit;
}

// ---- LIST ----
$q = trim($_GET['q'] ?? '');
$dateFilter = $_GET['date'] ?? '';
$statusFilter = $_GET['status_f'] ?? '';
$sql = "SELECT * FROM reservations WHERE 1=1";
$params = [];
if ($q !== '') {
    $sql .= " AND (client_name LIKE ? OR client_phone LIKE ? OR table_partition LIKE ? OR space_codes LIKE ? OR notes LIKE ?)";
    $like = '%' . $q . '%';
    $params = array_merge($params, [$like, $like, $like, $like, $like]);
}
if ($dateFilter !== '') {
    $sql .= " AND reservation_date = ?";
    $params[] = $dateFilter;
} else {
    $sql .= " AND reservation_date >= CURDATE() - INTERVAL 1 DAY";
}
if ($statusFilter !== '') {
    $sql .= " AND status = ?";
    $params[] = $statusFilter;
}
$sql .= " ORDER BY FIELD(status,'pending','confirmed','completed','cancelled'), reservation_date, reservation_time";
try {
    $st = $pdo->prepare($sql);
    $st->execute($params);
    $list = $st->fetchAll();
} catch (Exception $e) {
    // fallback without space_codes
    $sql2 = str_replace(' OR space_codes LIKE ?', '', $sql);
    $st = $pdo->prepare($sql2);
    $params2 = $q !== '' ? array_slice($params, 0, 4) : $params;
    if ($q !== '' && $dateFilter) {
        // messy - simple fallback
        $list = $pdo->query("SELECT * FROM reservations ORDER BY id DESC LIMIT 50")->fetchAll();
    } else {
        try {
            $st = $pdo->prepare($sql2);
            $st->execute($params);
            $list = $st->fetchAll();
        } catch (Exception $e2) {
            $list = [];
            $error = $e2->getMessage();
        }
    }
}

$spaces = [];
try {
    $spaces = $pdo->query("SELECT * FROM restaurant_tables WHERE is_active=1 ORDER BY space_type, zone, code")->fetchAll();
} catch (Exception $e) {
    try {
        $spaces = $pdo->query("SELECT * FROM restaurant_tables WHERE is_active=1 ORDER BY code")->fetchAll();
    } catch (Exception $e2) {
        $spaces = [];
    }
}

$freeTables = array_filter($spaces, fn($s) => ($s['space_type'] ?? 'table') === 'table' && ($s['status'] ?? 'free') === 'free');
$freeSalles = array_filter($spaces, fn($s) => ($s['space_type'] ?? '') === 'salle' && ($s['status'] ?? 'free') === 'free');
$freeParts  = array_filter($spaces, fn($s) => ($s['space_type'] ?? '') === 'partition' && ($s['status'] ?? 'free') === 'free');


// Reservations by space code (next upcoming confirmed)
$resByCode = [];
try {
    $rs = $pdo->query("SELECT * FROM reservations WHERE status='confirmed' AND reservation_date >= CURDATE() ORDER BY reservation_date, reservation_time");
    foreach ($rs->fetchAll() as $r) {
        $csv = $r['space_codes'] ?? '';
        if ($csv === '' && !empty($r['table_partition'])) $csv = $r['table_partition'];
        foreach (preg_split('/[,;]+/', $csv) as $c) {
            $c = trim($c);
            if ($c === '') continue;
            if (preg_match('/\b(T\d+|SALLE\d+|TERRASSE|P[\w\-]+)\b/i', $c, $m)) {
                $c = strtoupper($m[1]) === 'TERRASSE' ? 'TERRASSE' : $m[1];
                // normalize T numbers
                if (preg_match('/^T(\d+)$/i', $c, $tm)) $c = 'T' . (int)$tm[1];
            }
            if (!isset($resByCode[$c])) $resByCode[$c] = $r;
        }
        if (($r['reserve_type'] ?? '') === 'all_salles') {
            $resByCode['SALLE1'] = $r;
            $resByCode['SALLE2'] = $r;
            $resByCode['TERRASSE'] = $r;
        }
    }
} catch (Exception $e) {}

function tableZoneGroup($code) {
    if (!preg_match('/^T(\d+)$/i', $code, $m)) return null;
    $n = (int)$m[1];
    if ($n >= 1 && $n <= 20) return 'SALLE1';
    if ($n >= 21 && $n <= 35) return 'SALLE2';
    if ($n >= 36 && $n <= 50) return 'TERRASSE';
    return null;
}

function salleIsFree(array $spaces, $salleCode) {
    $tables = [];
    foreach ($spaces as $s) {
        if (($s['space_type'] ?? '') !== 'table') continue;
        $g = tableZoneGroup($s['code']);
        if ($g === $salleCode) $tables[] = $s;
    }
    if (!$tables) {
        foreach ($spaces as $s) {
            if ($s['code'] === $salleCode) return ($s['status'] ?? 'free') === 'free';
        }
        return true;
    }
    foreach ($tables as $s) {
        if (($s['status'] ?? 'free') !== 'free') return false;
    }
    return true;
}


$pendingCount = 0;
try { $pendingCount = (int)$pdo->query("SELECT COUNT(*) FROM reservations WHERE status='pending'")->fetchColumn(); } catch (Exception $e) {}

require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3 gap-2">
  <div>
    <p class="text-[11px] uppercase tracking-[0.2em] text-gold-500/80 font-semibold mb-1">Service</p>
    <h2 class="mb-0 font-serif text-2xl md:text-3xl font-bold text-slate-100"><i class="bi bi-calendar-check text-danger"></i> <?= htmlspecialchars(t('reservations')) ?></h2>
    <p class="text-slate-400 text-sm mt-1">Tables · salles · partitions · toutes les salles</p>
    <?php if ($pendingCount > 0): ?>
      <div class="alert alert-warning py-2 mt-2 mb-0"><?= (int)$pendingCount ?> reservation(s) en attente — a confirmer</div>
    <?php endif; ?>
  </div>
</div>

<?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if (!empty($_GET['ok'])): ?><div class="alert alert-success">OK</div><?php endif; ?>


<!-- PLAN INTERACTIF CHECKER -->
<style>
  .space-btn {
    min-width: 4.5rem; min-height: 3.2rem;
    border-radius: 0.65rem; border: 1px solid rgba(255,255,255,0.15);
    font-size: 0.7rem; font-weight: 700; line-height: 1.15;
    padding: 0.35rem 0.4rem; margin: 0.2rem;
    transition: transform .15s, box-shadow .15s;
    cursor: pointer; color: #fff; text-align: center;
  }
  .space-btn:hover { transform: translateY(-2px); box-shadow: 0 4px 14px rgba(0,0,0,.35); }
  .space-btn.free { background: #2563eb; border-color: #3b82f6; }
  .space-btn.occupied { background: #dc2626; border-color: #ef4444; }
  .space-btn.reserved {
    background: #f8fafc; color: #0f172a; border: 2px solid #d4af37;
  }
  .space-btn.salle-wide { min-width: 9rem; min-height: 4rem; font-size: 0.75rem; }
  .space-btn .sub { display:block; font-weight: 500; font-size: 0.62rem; opacity: .9; margin-top: 2px; }
  .map-legend span { display:inline-flex; align-items:center; gap:6px; margin-right:12px; font-size:11px; color:#94a3b8; }
  .map-legend i { width:12px; height:12px; border-radius:3px; display:inline-block; }
</style>

<div class="glass-card rounded-2xl p-4 mb-4 border border-gold-500/20">
  <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div>
      <h3 class="font-serif text-gold-300 text-lg mb-0">Plan des espaces</h3>
      <p class="text-slate-400 text-xs mb-0">Bleu = libre · Rouge = occupe · Blanc = reserve (date/heure)</p>
    </div>
    <div class="map-legend">
      <span><i style="background:#2563eb"></i> Libre</span>
      <span><i style="background:#dc2626"></i> Occupe</span>
      <span><i style="background:#f8fafc;border:1px solid #d4af37"></i> Reserve</span>
    </div>
  </div>

  <?php
    $byType = ['salle'=>[], 'table'=>[], 'partition'=>[]];
    foreach ($spaces as $s) {
      $tp = $s['space_type'] ?? 'table';
      if (!isset($byType[$tp])) $byType[$tp] = [];
      $byType[$tp][] = $s;
    }
    // Effective status for salles: free only if all tables free
    function effectiveStatus($s, $spaces, $resByCode) {
      $code = $s['code'];
      $st = $s['status'] ?? 'free';
      // Occupe = rouge prioritaire
      if ($st === 'occupied') return 'occupied';
      // Reserve (blanc) uniquement si statut DB reserved (active a l heure)
      if ($st === 'reserved') return 'reserved';
      if (($s['space_type'] ?? '') === 'salle') {
        $free = salleIsFree($spaces, $code);
        if (!$free) {
          // si une table occupee dans la salle
          foreach ($spaces as $tb) {
            if (($tb['space_type'] ?? '') !== 'table') continue;
            if (tableZoneGroup($tb['code']) === $code && ($tb['status'] ?? '') === 'occupied') return 'occupied';
            if (tableZoneGroup($tb['code']) === $code && ($tb['status'] ?? '') === 'reserved') return 'reserved';
          }
        }
      }
      // Reservation future : reste LIBRE (bleu) mais on peut afficher l info plus tard
      return 'free';
    }
    function renderSpaceBtn($s, $spaces, $resByCode, $wide = false) {
      $code = $s['code'];
      $st = effectiveStatus($s, $spaces, $resByCode);
      $cls = $st === 'free' ? 'free' : ($st === 'occupied' ? 'occupied' : 'reserved');
      $res = $resByCode[$code] ?? null;
      $sub = '';
      if ($st === 'reserved' && $res) {
        $sub = htmlspecialchars(substr($res['reservation_date'], 5) . ' ' . substr($res['reservation_time'], 0, 5));
      } elseif ($st === 'occupied') {
        $sub = 'Occupee';
      } elseif ($res && $st === 'free') {
        $sub = 'Libre · res. ' . htmlspecialchars(substr($res['reservation_date'], 5) . ' ' . substr($res['reservation_time'], 0, 5));
      } else {
        $sub = 'Libre';
      }
      $label = htmlspecialchars($code);
      if (($s['space_type'] ?? '') === 'salle') {
        $label = htmlspecialchars($s['name'] ?? $s['label'] ?? $code);
      }
      $wideCls = $wide ? ' salle-wide' : '';
      $dataRes = $res ? htmlspecialchars(json_encode([
        'id' => (int)$res['id'],
        'client' => $res['client_name'],
        'phone' => $res['client_phone'] ?? '',
        'date' => $res['reservation_date'],
        'time' => substr($res['reservation_time'],0,5),
        'guests' => (int)$res['guests'],
        'notes' => $res['notes'] ?? '',
        'code' => $code,
      ], JSON_UNESCAPED_UNICODE), ENT_QUOTES) : '';
      echo '<button type="button" class="space-btn '.$cls.$wideCls.'" data-code="'.htmlspecialchars($code).'" data-status="'.$st.'" data-type="'.htmlspecialchars($s['space_type']??'table').'" data-res="'.$dataRes.'">';
      echo $label;
      if ($sub) echo '<span class="sub">'.$sub.'</span>';
      echo '</button>';
    }
  ?>

  <div class="mb-4">
    <h6 class="text-slate-400 text-xs uppercase tracking-wider mb-2">Salles & Terrasse</h6>
    <div class="d-flex flex-wrap">
      <?php foreach ($byType['salle'] as $s) renderSpaceBtn($s, $spaces, $resByCode, true); ?>
    </div>
  </div>

  <div class="mb-4">
    <h6 class="text-slate-400 text-xs uppercase tracking-wider mb-2">Salle 1 — Tables T1–T20</h6>
    <div class="d-flex flex-wrap">
      <?php foreach ($byType['table'] as $s) {
        if (tableZoneGroup($s['code']) === 'SALLE1') renderSpaceBtn($s, $spaces, $resByCode);
      } ?>
    </div>
  </div>
  <div class="mb-4">
    <h6 class="text-slate-400 text-xs uppercase tracking-wider mb-2">Salle 2 — Tables T21–T35</h6>
    <div class="d-flex flex-wrap">
      <?php foreach ($byType['table'] as $s) {
        if (tableZoneGroup($s['code']) === 'SALLE2') renderSpaceBtn($s, $spaces, $resByCode);
      } ?>
    </div>
  </div>
  <div class="mb-4">
    <h6 class="text-slate-400 text-xs uppercase tracking-wider mb-2">Terrasse — Tables T36–T50</h6>
    <div class="d-flex flex-wrap">
      <?php foreach ($byType['table'] as $s) {
        if (tableZoneGroup($s['code']) === 'TERRASSE') renderSpaceBtn($s, $spaces, $resByCode);
      } ?>
    </div>
  </div>
  <div class="mb-2">
    <h6 class="text-slate-400 text-xs uppercase tracking-wider mb-2">Partitions</h6>
    <div class="d-flex flex-wrap">
      <?php foreach ($byType['partition'] as $s) renderSpaceBtn($s, $spaces, $resByCode, true); ?>
    </div>
  </div>
</div>

<!-- Modal reserve (libre) -->
<div class="modal fade" id="modalReserve" tabindex="-1">
  <div class="modal-dialog">
    <form method="post" class="modal-content" style="background:#1a1a1e;color:#e2e8f0;border:1px solid rgba(212,175,55,.3)">
      <div class="modal-header border-secondary">
        <h5 class="modal-title text-gold-300">Reserver <span id="mResCode"></span></h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" name="action" value="map_click">
        <input type="hidden" name="map_action" value="quick_reserve">
        <input type="hidden" name="space_code" id="mResSpace" value="">
        <div class="mb-2"><label class="form-label small">Client *</label><input type="text" name="client_name" class="form-control" required></div>
        <div class="mb-2"><label class="form-label small">Telephone</label><input type="text" name="client_phone" class="form-control"></div>
        <div class="mb-2"><label class="form-label small">Personnes</label><input type="number" name="guests" class="form-control" value="4" min="1"></div>
        <div class="row g-2">
          <div class="col-6"><label class="form-label small">Date</label><input type="date" name="reservation_date" class="form-control" value="<?= date('Y-m-d') ?>" required></div>
          <div class="col-6"><label class="form-label small">Heure</label><input type="time" name="reservation_time" class="form-control" value="19:00" required></div>
        </div>
        <div class="mt-2"><label class="form-label small">Notes</label><textarea name="notes" class="form-control" rows="2"></textarea></div>
      </div>
      <div class="modal-footer border-secondary">
        <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Annuler</button>
        <button class="btn btn-primary btn-sm">Confirmer reservation</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal details reserve -->
<div class="modal fade" id="modalDetails" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content" style="background:#1a1a1e;color:#e2e8f0;border:1px solid rgba(212,175,55,.3)">
      <div class="modal-header border-secondary">
        <h5 class="modal-title text-gold-300">Reservation — <span id="mDetCode"></span></h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body small" id="mDetBody"></div>
      <div class="modal-footer border-secondary">
        <form method="post" class="me-auto" id="mDetFreeForm">
          <input type="hidden" name="action" value="map_click">
          <input type="hidden" name="map_action" value="free_occupied">
          <input type="hidden" name="space_code" id="mDetFreeCode" value="">
          <button class="btn btn-outline-success btn-sm">Liberer</button>
        </form>
        <a href="#" id="mDetApproveLink" class="btn btn-success btn-sm d-none">Voir liste</a>
        <button type="button" class="btn btn-outline-secondary btn-sm" data-bs-dismiss="modal">Fermer</button>
      </div>
    </div>
  </div>
</div>

<form method="post" id="formOccupy" class="d-none">
  <input type="hidden" name="action" value="map_click">
  <input type="hidden" name="map_action" value="occupy">
  <input type="hidden" name="space_code" id="occupyCode" value="">
</form>
<form method="post" id="formFree" class="d-none">
  <input type="hidden" name="action" value="map_click">
  <input type="hidden" name="map_action" value="free_occupied">
  <input type="hidden" name="space_code" id="freeCode" value="">
</form>

<script>
(function(){
  document.querySelectorAll('.space-btn').forEach(function(btn){
    btn.addEventListener('click', function(){
      var code = btn.getAttribute('data-code');
      var st = btn.getAttribute('data-status');
      var resRaw = btn.getAttribute('data-res');
      if (st === 'free') {
        var el = document.getElementById('modalReserve');
        if (el.parentElement !== document.body) document.body.appendChild(el);
        document.getElementById('mResCode').textContent = code;
        document.getElementById('mResSpace').value = code;
        bootstrap.Modal.getOrCreateInstance(el).show();
      } else if (st === 'occupied') {
        if (confirm(code + ' est occupee. Liberer maintenant ?')) {
          document.getElementById('freeCode').value = code;
          document.getElementById('formFree').submit();
        }
      } else if (st === 'reserved') {
        var el = document.getElementById('modalDetails');
        if (el.parentElement !== document.body) document.body.appendChild(el);
        document.getElementById('mDetCode').textContent = code;
        document.getElementById('mDetFreeCode').value = code;
        var html = '<p class="text-muted">Espace reserve.</p>';
        if (resRaw) {
          try {
            var r = JSON.parse(resRaw);
            html = '<p><strong>Client :</strong> ' + (r.client||'-') + '</p>' +
              '<p><strong>Tel :</strong> ' + (r.phone||'-') + '</p>' +
              '<p><strong>Date :</strong> ' + (r.date||'') + ' <strong>Heure :</strong> ' + (r.time||'') + '</p>' +
              '<p><strong>Personnes :</strong> ' + (r.guests||'') + '</p>' +
              '<p><strong>Notes :</strong> ' + (r.notes||'-') + '</p>' +
              '<p class="text-muted">Reservation #' + (r.id||'') + '</p>';
          } catch(e) {}
        }
        document.getElementById('mDetBody').innerHTML = html;
        bootstrap.Modal.getOrCreateInstance(el).show();
      }
    });
  });
})();
</script>

<!-- Controle statut checker -->
<div class="glass-card rounded-2xl p-4 mb-4 border border-gold-500/20">
  <h3 class="font-serif text-gold-300 text-lg mb-2">Changer le statut (Checker)</h3>
  <p class="text-slate-400 text-xs mb-3">Table · partition · salle · toutes les salles</p>
  <form method="post" class="row g-2 align-items-end">
    <input type="hidden" name="action" value="set_space_status">
    <div class="col-md-5">
      <label class="form-label small">Partie</label>
      <select name="space_code" class="form-select form-select-sm" required>
        <option value="">— Choisir —</option>
        <option value="ALL_SALLES">Toutes les salles (Salle 1 + Salle 2 + Terrasse)</option>
        <?php foreach ($spaces as $s): ?>
          <option value="<?= htmlspecialchars($s['code']) ?>">
            [<?= htmlspecialchars($s['space_type'] ?? 'table') ?>]
            <?= htmlspecialchars($s['code']) ?>
            <?= !empty($s['label']) ? ' — '.htmlspecialchars($s['label']) : '' ?>
            · <?= htmlspecialchars($s['status'] ?? 'free') ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3">
      <label class="form-label small">Nouveau statut</label>
      <select name="new_status" class="form-select form-select-sm" required>
        <option value="free">Libre (free)</option>
        <option value="reserved">Reserve</option>
        <option value="occupied">Occupe / prise</option>
      </select>
    </div>
    <div class="col-md-2">
      <button class="btn btn-sm btn-warning text-dark w-100">Appliquer</button>
    </div>
  </form>
</div>

<div class="row g-4">
  <div class="col-lg-4">
    <div class="glass-card rounded-2xl p-4 border border-gold-500/20">
      <h5 class="mb-3">Nouvelle reservation</h5>
      <form method="post">
        <input type="hidden" name="action" value="create">
        <div class="mb-2">
          <label class="form-label small">Type de reservation</label>
          <select name="reserve_type" id="reserveType" class="form-select" required>
            <option value="table">1 table</option>
            <option value="multi_table">Plusieurs tables</option>
            <option value="partition">Partition (groupe de tables)</option>
            <option value="salle">Salle entiere (Salle 1, Salle 2 ou Terrasse)</option>
            <option value="all_salles">Tout l etablissement (2 salles + terrasse)</option>
          </select>
        </div>
        <div class="mb-2" id="boxSpaceCode">
          <label class="form-label small">Salle / Table / Partition</label>
          <select name="space_code" class="form-select">
            <option value="">— Choisir —</option>
            <?php foreach ($spaces as $s): ?>
              <option value="<?= htmlspecialchars($s['code']) ?>" data-type="<?= htmlspecialchars($s['space_type'] ?? 'table') ?>">
                [<?= htmlspecialchars($s['space_type'] ?? 'table') ?>] <?= htmlspecialchars($s['code']) ?> — <?= htmlspecialchars($s['label'] ?? $s['name'] ?? '') ?>
                (<?= ($s['status'] ?? 'free') === 'free' ? 'libre' : ($s['status'] ?? '') ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-2 d-none" id="boxMultiTables">
          <label class="form-label small">Tables (multi)</label>
          <?php foreach ($freeTables as $s): ?>
            <div class="form-check">
              <input class="form-check-input" type="checkbox" name="table_codes[]" value="<?= htmlspecialchars($s['code']) ?>" id="tc<?= (int)$s['id'] ?>">
              <label class="form-check-label small" for="tc<?= (int)$s['id'] ?>">N° <?= htmlspecialchars($s['code']) ?></label>
            </div>
          <?php endforeach; ?>
        </div>
        <div class="mb-2" id="boxTablesCount">
          <label class="form-label small">Nombre de tables (partition)</label>
          <input type="number" name="tables_count" class="form-control" min="1" max="20" value="1">
          <div class="form-text">1 table = 4 a 8 personnes</div>
        </div>
        <div class="mb-2">
          <label class="form-label small">Type de client</label>
          <select name="client_type" class="form-select mb-2">
            <?php foreach (function_exists('sulaClientTypes') ? sulaClientTypes() : ['individu'=>'Individu'] as $c=>$l): ?>
              <option value="<?= htmlspecialchars($c) ?>"><?= htmlspecialchars($l) ?></option>
            <?php endforeach; ?>
          </select>
          <label class="form-label small">Client / contact *</label>
          <input type="text" name="client_name" class="form-control" required>
          <input type="text" name="organization" class="form-control mt-1" placeholder="Organisation / famille">
        </div>
        <div class="mb-2">
          <label class="form-label small">Telephone</label>
          <input type="text" name="client_phone" class="form-control">
        </div>
        <div class="mb-2">
          <label class="form-label small">Personnes *</label>
          <input type="number" name="guests" class="form-control" min="1" value="4" required>
        </div>
        <div class="mb-2">
          <label class="form-label small">Date *</label>
          <input type="date" name="reservation_date" class="form-control" required value="<?= date('Y-m-d') ?>">
        </div>
        <div class="mb-2">
          <label class="form-label small">Heure *</label>
          <input type="time" name="reservation_time" class="form-control" required value="19:00">
        </div>
        <div class="mb-2">
          <label class="form-label small">Notes</label>
          <textarea name="notes" class="form-control" rows="2"></textarea>
        </div>
        <button class="btn btn-danger w-100">Enregistrer</button>
      </form>
    </div>
  </div>

  <div class="col-lg-8">
    <div class="glass-card rounded-2xl p-4 border border-gold-500/20">
      <form class="row g-2 mb-3" method="get">
        <div class="col-md-4"><input type="search" name="q" class="form-control form-control-sm" placeholder="Recherche…" value="<?= htmlspecialchars($q) ?>"></div>
        <div class="col-md-3"><input type="date" name="date" class="form-control form-control-sm" value="<?= htmlspecialchars($dateFilter) ?>"></div>
        <div class="col-md-3">
          <select name="status_f" class="form-select form-select-sm">
            <option value="">Tous statuts</option>
            <?php foreach (['pending','confirmed','completed','cancelled'] as $s): ?>
              <option value="<?= $s ?>" <?= $statusFilter===$s?'selected':'' ?>><?= $s ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="col-md-2"><button class="btn btn-sm btn-outline-secondary w-100">Filtrer</button></div>
      </form>
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th>#</th><th>Client</th><th>Date</th><th>Pers.</th><th>Partie</th><th>Statut</th><th></th>
            </tr>
          </thead>
          <tbody>
          <?php if (!$list): ?>
            <tr><td colspan="7" class="text-muted">Aucune reservation</td></tr>
          <?php endif; ?>
          <?php foreach ($list as $r): ?>
            <tr class="<?= ($r['status']??'')==='pending'?'table-warning':'' ?>">
              <td><?= (int)$r['id'] ?></td>
              <td>
                <strong><?= htmlspecialchars($r['client_name']) ?></strong>
                <?php if (!empty($r['client_type'])): ?>
                  <div class="small text-gold-400"><?= htmlspecialchars(function_exists('sulaClientTypeLabel') ? sulaClientTypeLabel($r['client_type']) : $r['client_type']) ?></div>
                <?php endif; ?>
                <div class="small text-muted"><?= htmlspecialchars($r['client_phone'] ?? '') ?></div>
              </td>
              <td class="text-nowrap"><?= htmlspecialchars($r['reservation_date']) ?><br><span class="small"><?= substr($r['reservation_time'],0,5) ?></span></td>
              <td><?= (int)$r['guests'] ?></td>
              <td class="small">
                <span class="badge bg-secondary"><?= htmlspecialchars($r['reserve_type'] ?? 'table') ?></span>
                <?= htmlspecialchars($r['table_partition'] ?? $r['space_codes'] ?? '') ?>
                <?php if (!empty($r['tables_count']) && (int)$r['tables_count'] > 1): ?>
                  <div class="text-muted"><?= (int)$r['tables_count'] ?> tables</div>
                <?php endif; ?>
              </td>
              <td><span class="badge bg-<?= ($r['status']??'')==='confirmed'?'success':(($r['status']??'')==='pending'?'warning':'secondary') ?>"><?= htmlspecialchars($r['status'] ?? '') ?></span></td>
              <td class="text-nowrap">
                <button type="button" class="btn btn-outline-info btn-sm sula-res-detail"
                  data-id="<?= (int)$r['id'] ?>"
                  data-client="<?= htmlspecialchars($r['client_name'] ?? '', ENT_QUOTES) ?>"
                  data-phone="<?= htmlspecialchars($r['client_phone'] ?? '', ENT_QUOTES) ?>"
                  data-date="<?= htmlspecialchars($r['reservation_date'] ?? '', ENT_QUOTES) ?>"
                  data-time="<?= htmlspecialchars(substr($r['reservation_time'] ?? '', 0, 5), ENT_QUOTES) ?>"
                  data-guests="<?= (int)($r['guests'] ?? 0) ?>"
                  data-type="<?= htmlspecialchars($r['reserve_type'] ?? 'table', ENT_QUOTES) ?>"
                  data-space="<?= htmlspecialchars($r['table_partition'] ?? $r['space_codes'] ?? '', ENT_QUOTES) ?>"
                  data-notes="<?= htmlspecialchars($r['notes'] ?? '', ENT_QUOTES) ?>"
                  data-status="<?= htmlspecialchars($r['status'] ?? '', ENT_QUOTES) ?>"
                  data-client-type="<?= htmlspecialchars(function_exists('sulaClientTypeLabel') ? sulaClientTypeLabel($r['client_type'] ?? '') : ($r['client_type'] ?? ''), ENT_QUOTES) ?>"
                  data-pay="<?= htmlspecialchars($r['payment_status'] ?? '', ENT_QUOTES) ?>"
                >Détails</button>
                <?php if (($r['status'] ?? '') === 'pending'): ?>
                  <a class="btn btn-success btn-sm" href="?status=confirmed&amp;id=<?= (int)$r['id'] ?>" onclick="return confirm('Confirmer la réservation #<?= (int)$r['id'] ?> ?\nClient: <?= htmlspecialchars($r['client_name'] ?? '', ENT_QUOTES) ?>\nEspace: <?= htmlspecialchars($r['table_partition'] ?? $r['space_codes'] ?? '', ENT_QUOTES) ?>\n<?= (int)($r['guests']??0) ?> pers. le <?= htmlspecialchars($r['reservation_date']??'') ?> <?= htmlspecialchars(substr($r['reservation_time']??'',0,5)) ?>');">Approuver</a>
                  <a class="btn btn-outline-danger btn-sm" href="?status=cancelled&amp;id=<?= (int)$r['id'] ?>">Refuser</a>
                <?php elseif (($r['status'] ?? '') === 'confirmed'): ?>
                  <a class="btn btn-outline-secondary btn-sm" href="?status=completed&amp;id=<?= (int)$r['id'] ?>">Terminer</a>
                  <a class="btn btn-outline-danger btn-sm" href="?status=cancelled&amp;id=<?= (int)$r['id'] ?>">Annuler</a>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script>
(function(){
  var type = document.getElementById('reserveType');
  var boxSpace = document.getElementById('boxSpaceCode');
  var boxMulti = document.getElementById('boxMultiTables');
  var boxCnt = document.getElementById('boxTablesCount');
  function sync(){
    var v = type.value;
    boxMulti.classList.toggle('d-none', v !== 'multi_table');
    boxSpace.classList.toggle('d-none', v === 'multi_table' || v === 'all_salles');
    boxCnt.classList.toggle('d-none', v !== 'partition' && v !== 'multi_table');
  }
  type.addEventListener('change', sync);
  sync();
})();
</script>

<!-- Modal détail réservation -->
<div id="sulaResModal" class="fixed inset-0 hidden items-center justify-center p-4" style="background:rgba(0,0,0,0.75);z-index:200000;display:none">
  <div class="w-full max-w-md rounded-2xl border border-gold-500/30 shadow-2xl p-0" style="background:rgba(26,26,30,0.97)">
    <div class="p-4 border-b border-gold-500/20 flex justify-between items-center">
      <h3 class="font-serif text-lg font-bold text-gold-300 mb-0">Réservation <span id="resDetId"></span></h3>
      <button type="button" id="sulaResClose" class="text-slate-400 hover:text-white text-xl">&times;</button>
    </div>
    <div class="p-4 text-sm text-slate-200 space-y-2">
      <p><span class="text-slate-500">Client :</span> <strong id="resDetClient"></strong></p>
      <p><span class="text-slate-500">Type :</span> <span id="resDetClientType"></span></p>
      <p><span class="text-slate-500">Téléphone :</span> <span id="resDetPhone"></span></p>
      <p><span class="text-slate-500">Date / heure :</span> <span id="resDetWhen"></span></p>
      <p><span class="text-slate-500">Personnes :</span> <span id="resDetGuests"></span></p>
      <p><span class="text-slate-500">Type :</span> <span id="resDetType"></span></p>
      <p><span class="text-slate-500">Espace :</span> <span id="resDetSpace"></span></p>
      <p><span class="text-slate-500">Statut :</span> <span id="resDetStatus"></span></p>
      <p><span class="text-slate-500">Paiement :</span> <span id="resDetPay"></span></p>
      <p id="resDetNotesRow" class="hidden"><span class="text-slate-500">Notes :</span> <span id="resDetNotes"></span></p>
    </div>
    <div class="p-4 border-t border-gold-500/20 flex justify-end gap-2" id="resDetActions"></div>
  </div>
</div>
<script>
(function(){
  var modal = document.getElementById('sulaResModal');
  if (!modal) return;
  function openRes(btn) {
    document.getElementById('resDetId').textContent = '#' + btn.getAttribute('data-id');
    document.getElementById('resDetClient').textContent = btn.getAttribute('data-client') || '—';
    var rct = document.getElementById('resDetClientType'); if (rct) rct.textContent = btn.getAttribute('data-client-type') || '—';
    document.getElementById('resDetPhone').textContent = btn.getAttribute('data-phone') || '—';
    document.getElementById('resDetWhen').textContent = (btn.getAttribute('data-date')||'') + ' ' + (btn.getAttribute('data-time')||'');
    document.getElementById('resDetGuests').textContent = btn.getAttribute('data-guests') || '—';
    document.getElementById('resDetType').textContent = btn.getAttribute('data-type') || '—';
    document.getElementById('resDetSpace').textContent = btn.getAttribute('data-space') || '—';
    document.getElementById('resDetStatus').textContent = btn.getAttribute('data-status') || '—';
    document.getElementById('resDetPay').textContent = btn.getAttribute('data-pay') || '—';
    var notes = btn.getAttribute('data-notes') || '';
    var nr = document.getElementById('resDetNotesRow');
    if (notes) { document.getElementById('resDetNotes').textContent = notes; nr.classList.remove('hidden'); }
    else nr.classList.add('hidden');
    var act = document.getElementById('resDetActions');
    var st = btn.getAttribute('data-status');
    var id = btn.getAttribute('data-id');
    act.innerHTML = '';
    if (st === 'pending') {
      act.innerHTML = '<a class="btn btn-success btn-sm" href="?status=confirmed&id='+id+'">Approuver</a>'
        + '<a class="btn btn-outline-danger btn-sm" href="?status=cancelled&id='+id+'">Refuser</a>';
    }
    act.innerHTML += '<button type="button" class="btn btn-outline-secondary btn-sm" id="sulaResClose2">Fermer</button>';
    var c2 = document.getElementById('sulaResClose2');
    if (c2) c2.onclick = closeRes;
    if (modal.parentElement !== document.body) document.body.appendChild(modal);
    modal.classList.remove('hidden');
    modal.style.display = 'flex';
  }
  function closeRes(){ modal.classList.add('hidden'); modal.style.display = 'none'; }
  document.querySelectorAll('.sula-res-detail').forEach(function(btn){
    btn.addEventListener('click', function(){ openRes(btn); });
  });
  var c = document.getElementById('sulaResClose');
  if (c) c.addEventListener('click', closeRes);
  modal.addEventListener('click', function(e){ if (e.target === modal) closeRes(); });
})();
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>

