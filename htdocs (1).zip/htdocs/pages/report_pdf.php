<?php
error_reporting(E_ALL); ini_set('display_errors','0');
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/pdf/SimplePDF.php';
requireRole(['accountant','admin','checker','stock_manager','kitchen','server']);
$pdo=getPDO(); date_default_timezone_set('Indian/Antananarivo');
$type=preg_replace('/[^a-z_]/','',strtolower($_GET['type']??'daily'));
$period=$_GET['period']??'today';
$from=$_GET['from']??date('Y-m-d'); $to=$_GET['to']??date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/',$from)) $from=date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/',$to)) $to=$from;
if (!isset($_GET['from']) && !isset($_GET['to'])) {
 if (in_array($period,['today','daily'],true)) {$from=$to=date('Y-m-d');}
 elseif (in_array($period,['week','weekly'],true)) {$from=date('Y-m-d',strtotime('monday this week'));$to=date('Y-m-d',strtotime('sunday this week'));}
 elseif (in_array($period,['month','monthly'],true)) {$from=date('Y-m-01');$to=date('Y-m-t');}
 elseif (in_array($period,['year','yearly'],true)) {$from=date('Y-01-01');$to=date('Y-12-31');}
}
$label=$from===$to?'Le '.date('d/m/Y',strtotime($from)):'Du '.date('d/m/Y',strtotime($from)).' au '.date('d/m/Y',strtotime($to));
function qRows(PDO $p,string $sql,array $args=[]):array {try{$s=$p->prepare($sql);$s->execute($args);return $s->fetchAll(PDO::FETCH_ASSOC);}catch(Throwable $e){return [];}}
function qVal(PDO $p,string $sql,array $args=[]):float {try{$s=$p->prepare($sql);$s->execute($args);return (float)$s->fetchColumn();}catch(Throwable $e){return 0;}}
function money($n):string{return number_format((float)$n,0,',',' ').' Ar';}
try {
 $pdf=new SimplePDF();
 if($type==='full') {
   // Le CEO reçoit uniquement les six indicateurs demandés et la liste des événements non terminés.
   $income=qVal($pdo,"SELECT COALESCE(SUM(CASE WHEN payment_status='paid' AND paid_amount=0 THEN total ELSE paid_amount END),0) FROM invoices WHERE DATE(created_at) BETWEEN ? AND ? AND payment_status IN ('paid','partial')",[$from,$to]);
   $out=qVal($pdo,"SELECT COALESCE(SUM(amount),0) FROM expenses WHERE expense_date BETWEEN ? AND ?",[$from,$to]);
   $dine=(int)qVal($pdo,"SELECT COUNT(*) FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND order_type='dine_in' AND status<>'cancelled'",[$from,$to]);
   $delivery=(int)qVal($pdo,"SELECT COUNT(*) FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND order_type='delivery' AND status<>'cancelled'",[$from,$to]);
   $reservations=(int)qVal($pdo,"SELECT COUNT(*) FROM reservations WHERE reservation_date BETWEEN ? AND ? AND status<>'cancelled'",[$from,$to]);
   $cols=[];try{$cols=$pdo->query('SHOW COLUMNS FROM events')->fetchAll(PDO::FETCH_COLUMN);}catch(Throwable $e){}
   $endCol=in_array('end_date',$cols,true)?'end_date':'event_date';
   $events=qRows($pdo,"SELECT title,event_date,COALESCE(NULLIF($endCol,''),event_date) AS end_date,status FROM events WHERE status IN ('planned','confirmed') AND COALESCE(NULLIF($endCol,''),event_date)>=CURDATE() ORDER BY event_date");
   $pdf->reportHeader('Rapport complet CEO','SURA — Synthèse de direction',$label);
   $pdf->sectionTitle('Indicateurs de direction');
   $pdf->table(['Indicateur','Valeur'],[
    ['Recettes entrantes (encaissées)',money($income)],['Recettes sortantes (dépenses)',money($out)],['Commandes sur place (dine-in)',(string)$dine],['Commandes en livraison',(string)$delivery],['Réservations sur la période',(string)$reservations],['Événements non terminés',(string)count($events)]
   ],[330,165],['L','R']);
   $pdf->sectionTitle('Événements non terminés');$rows=[];
   foreach($events as $e)$rows[]=[$e['title'],date('d/m/Y',strtotime($e['event_date'])),date('d/m/Y',strtotime($e['end_date'])),($e['status']==='confirmed'?'Confirmé':'Planifié')];
   if(!$rows)$rows[]=['Aucun événement non terminé','—','—','—'];
   $pdf->table(['Événement','Début','Fin','Statut'],$rows,[230,90,90,85],['L','C','C','L']);
   $filename='SURA_Rapport_CEO_'.$from.'_'.$to.'.pdf';
 } else {
   $orders=qRows($pdo,"SELECT id,created_at,order_type,table_no,client_name,total,status,payment_status FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND status<>'cancelled' ORDER BY created_at ASC",[$from,$to]);
   $daily=qRows($pdo,"SELECT DATE(created_at) day,COUNT(*) orders_count,SUM(order_type='dine_in') dine_in_count,SUM(order_type='delivery') delivery_count,COALESCE(SUM(total),0) sales_total FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND status<>'cancelled' GROUP BY DATE(created_at) ORDER BY day ASC",[$from,$to]);
   $map=[];foreach($daily as $d)$map[$d['day']]=$d;$dailyAll=[];
   for($t=strtotime($from);$t<=strtotime($to);$t=strtotime('+1 day',$t)){$d=date('Y-m-d',$t);$dailyAll[]=$map[$d]??['day'=>$d,'orders_count'=>0,'dine_in_count'=>0,'delivery_count'=>0,'sales_total'=>0];}
   $sales=qVal($pdo,"SELECT COALESCE(SUM(total),0) FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND status<>'cancelled'",[$from,$to]);
   $income=qVal($pdo,"SELECT COALESCE(SUM(CASE WHEN payment_status='paid' AND paid_amount=0 THEN total ELSE paid_amount END),0) FROM invoices WHERE DATE(created_at) BETWEEN ? AND ? AND payment_status IN ('paid','partial')",[$from,$to]);
   $out=qVal($pdo,"SELECT COALESCE(SUM(amount),0) FROM expenses WHERE expense_date BETWEEN ? AND ?",[$from,$to]);
   $title=$type==='weekly'?'Rapport hebdomadaire':($type==='monthly'?'Rapport mensuel':($type==='yearly'?'Rapport annuel':'Rapport journalier'));
   $pdf->reportHeader($title,'SURA — Détail des opérations',$label);
   $pdf->kpiRow([['label'=>'Commandes','value'=>(string)count($orders)],['label'=>'Ventes','value'=>money($sales)],['label'=>'Recettes encaissées','value'=>money($income)],['label'=>'Dépenses','value'=>money($out)]]);
   if(in_array($type,['weekly','monthly'],true)) {
     $pdf->sectionTitle('Recettes et commandes jour par jour');$rows=[];
     foreach($dailyAll as $d)$rows[]=[date('d/m/Y',strtotime($d['day'])),(string)$d['orders_count'],(string)$d['dine_in_count'],(string)$d['delivery_count'],money($d['sales_total'])];
     $pdf->table(['Date','Commandes','Sur place','Livraison','Ventes'], $rows?:[['—','0','0','0','0 Ar']],[105,85,85,85,135],['L','R','R','R','R']);
   } elseif($type==='yearly') {
     $pdf->sectionTitle('Synthèse mois par mois');
     $monthly=qRows($pdo, "SELECT DATE_FORMAT(created_at,'%Y-%m') month, COUNT(*) orders_count, SUM(order_type='dine_in') dine_in_count, SUM(order_type='delivery') delivery_count, COALESCE(SUM(total),0) sales_total FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND status<>'cancelled' GROUP BY DATE_FORMAT(created_at,'%Y-%m')",[$from,$to]);
     $mm=[];foreach($monthly as $r)$mm[$r['month']]=$r;$rows=[];
     for($m=1;$m<=12;$m++){ $key=date('Y',strtotime($from)).'-'.sprintf('%02d',$m);$r=$mm[$key]??['orders_count'=>0,'dine_in_count'=>0,'delivery_count'=>0,'sales_total'=>0];$rows[]=[date('F Y',strtotime($key.'-01')),(string)$r['orders_count'],(string)$r['dine_in_count'],(string)$r['delivery_count'],money($r['sales_total'])];}
     $pdf->table(['Mois','Commandes','Sur place','Livraison','Ventes'],$rows,[125,75,75,75,145],['L','R','R','R','R']);
   }
   if($type!=='yearly') {
     $pdf->sectionTitle($type==='daily'?'Liste complète des commandes du jour':'Détail des commandes');$rows=[];
     foreach($orders as $o){$client=$o['order_type']==='dine_in'?'Table '.($o['table_no']??'—'):($o['client_name']??'—');$rows[]=['#'.$o['id'],date('d/m/Y H:i',strtotime($o['created_at'])),$o['order_type']==='dine_in'?'Sur place':'Livraison',$client,money($o['total']),$o['payment_status']??'—'];}
     $pdf->table(['N°','Date/heure','Type','Client/Table','Total','Paiement'],$rows?:[['—','—','—','Aucune commande','0 Ar','—']],[40,95,75,130,85,70],['L','L','L','L','R','L']);
   }
   $filename='SURA_Rapport_'.ucfirst($type).'_'.$from.'_'.$to.'.pdf';
 }
 while(ob_get_level())ob_end_clean();$pdf->output($filename,'D');
} catch(Throwable $e) {while(ob_get_level())ob_end_clean();http_response_code(500);header('Content-Type:text/plain; charset=utf-8');echo 'Erreur generation PDF: '.$e->getMessage();}
