<?php
/**
 * Evenements SURA — date, activites, commandes avance, partie (salle / toutes), responsable
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/notify.php';
requireRole(['admin', 'checker']);

$pageTitle = t('events');
$pdo = getPDO();
$user = currentUser();
$msg = '';
$error = '';

// Schema soft
foreach ([
    "ALTER TABLE events ADD COLUMN activities TEXT NULL",
    "ALTER TABLE events ADD COLUMN advance_orders TEXT NULL",
    "ALTER TABLE events ADD COLUMN space_request VARCHAR(100) NULL",
    "ALTER TABLE events ADD COLUMN responsible VARCHAR(120) NULL",
    "ALTER TABLE events ADD COLUMN client_name VARCHAR(120) NULL",
    "ALTER TABLE events ADD COLUMN client_phone VARCHAR(30) NULL",
    "ALTER TABLE events ADD COLUMN notes TEXT NULL",
    "ALTER TABLE events ADD COLUMN guests INT NULL",
] as $sql) {
    try { $pdo->exec($sql); } catch (Exception $e) {}
}

if (isset($_GET['status'], $_GET['id'])) {
    $st = $_GET['status'];
    if (in_array($st, ['planned', 'confirmed', 'done', 'cancelled'], true)) {
        $pdo->prepare('UPDATE events SET status=? WHERE id=?')->execute([$st, (int)$_GET['id']]);
        if ($st === 'confirmed') {
            $row = $pdo->prepare('SELECT * FROM events WHERE id=?');
            $row->execute([(int)$_GET['id']]);
            $ev = $row->fetch();
            if ($ev) {
                // Reserve salles if requested
                $space = $ev['space_request'] ?? '';
                try {
                    if ($space === 'ALL_SALLES') {
                        $pdo->exec("UPDATE restaurant_tables SET status='reserved' WHERE space_type='salle'");
                    } elseif ($space !== '') {
                        $pdo->prepare("UPDATE restaurant_tables SET status='reserved' WHERE code=? OR space_type='salle' AND code=?")->execute([$space, $space]);
                        $pdo->prepare("UPDATE restaurant_tables SET status='reserved' WHERE code=?")->execute([$space]);
                    }
                } catch (Exception $e) {}
                sulaNotify($pdo, 'Evenement confirme #' . $ev['id'], ($ev['title'] ?? '') . ' — ' . ($ev['event_date'] ?? ''), 'event');
            }
        }
    }
    header('Location: /pages/events.php?ok=1');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
    try {
        $title = trim($_POST['title'] ?? '');
        $date = $_POST['event_date'] ?? '';
        $endDate = $_POST['end_date'] ?? $date;
        if ($title === '' || $date === '') throw new Exception('Titre et date obligatoires.');
        if ($endDate === '' || $endDate < $date) throw new Exception('La date de fin doit être égale ou postérieure à la date de début.');
        $activities = trim($_POST['activities'] ?? '');
        $advance = trim($_POST['advance_orders'] ?? '');
        $space = trim($_POST['space_request'] ?? '');
        $responsible = trim($_POST['responsible'] ?? '');
        $client = trim($_POST['client_name'] ?? '');
        $phone = trim($_POST['client_phone'] ?? '');
        $notes = trim($_POST['notes'] ?? '');
        $capacity = (int)($_POST['capacity'] ?? 0);
        $guests = (int)($_POST['guests'] ?? 0);
        $deposit = $_POST['deposit_status'] ?? 'not_paid';
        $package = trim($_POST['package_desc'] ?? '');

        try {
            $eventColumns = $pdo->query('SHOW COLUMNS FROM events')->fetchAll(PDO::FETCH_COLUMN);
            if (in_array('end_date', $eventColumns, true)) {
                $pdo->prepare('INSERT INTO events (title,event_date,end_date,capacity,package_desc,deposit_status,status,activities,advance_orders,space_request,responsible,client_name,client_phone,notes,guests) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
                    ->execute([$title, $date, $endDate, $capacity ?: null, $package ?: null, $deposit, 'planned', $activities ?: null, $advance ?: null, $space ?: null, $responsible ?: null, $client ?: null, $phone ?: null, $notes ?: null, $guests ?: null]);
            } else {
                $pdo->prepare('INSERT INTO events (title,event_date,capacity,package_desc,deposit_status,status,activities,advance_orders,space_request,responsible,client_name,client_phone,notes,guests) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
                    ->execute([$title, $date, $capacity ?: null, $package ?: null, $deposit, 'planned', $activities ?: null, $advance ?: null, $space ?: null, $responsible ?: null, $client ?: null, $phone ?: null, $notes ?: null, $guests ?: null]);
            }
        } catch (Exception $ex) {
            $pdo->prepare('INSERT INTO events (title,event_date,capacity,package_desc,deposit_status,status) VALUES (?,?,?,?,?,?)')
                ->execute([$title, $date, $capacity ?: null, $package ?: null, $deposit, 'planned']);
        }
        sulaNotify($pdo, 'Nouvel evenement : ' . $title, $date . ' — ' . ($space ?: 'espace a definir') . ' — Resp: ' . ($responsible ?: '-'), 'event');
        header('Location: /pages/events.php?ok=1');
        exit;
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

$events = [];
try {
    $events = $pdo->query('SELECT * FROM events ORDER BY event_date DESC')->fetchAll();
} catch (Exception $e) {
    $error = $e->getMessage();
}

$salles = [];
try {
    $salles = $pdo->query("SELECT code, label, name, status FROM restaurant_tables WHERE space_type='salle' AND is_active=1 ORDER BY code")->fetchAll();
} catch (Exception $e) {
    try {
        $salles = $pdo->query("SELECT code, label, name, status FROM restaurant_tables WHERE zone IN ('salle','vip','terrasse') ORDER BY code")->fetchAll();
    } catch (Exception $e2) {}
}

require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
  <div>
    <p class="text-[11px] uppercase tracking-[0.2em] text-gold-500/80 font-semibold mb-1">Hospitality</p>
    <h2 class="font-serif text-2xl md:text-3xl font-bold text-slate-100 mb-0"><i class="bi bi-stars text-warning"></i> <?= htmlspecialchars(t('events')) ?></h2>
    <p class="text-slate-400 text-sm mt-1">Equivalent a reserver Salle 1, Salle 2, Terrasse ou tout — client ou SURA</p>
  </div>
</div>
<?php if (!empty($error)): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>
<?php if (!empty($_GET['ok'])): ?><div class="alert alert-success">OK</div><?php endif; ?>

<div class="row g-4">
  <div class="col-lg-4">
    <div class="glass-card rounded-2xl p-4 border border-gold-500/20">
      <h5 class="mb-3">Nouvel evenement</h5>
      <p class="small text-muted mb-3">Un evenement reserve une <strong>salle entiere</strong>, la <strong>terrasse</strong>, ou <strong>tout l etablissement</strong>.</p>
      <form method="post">
        <input type="hidden" name="action" value="create">
        <div class="mb-2">
          <label class="form-label small">Titre *</label>
          <input type="text" name="title" class="form-control" required placeholder="Ex: Soiree entreprise">
        </div>
        <div class="mb-2">
          <label class="form-label small">Date *</label>
          <input type="date" name="event_date" class="form-control" required>
        </div>
        <div class="mb-2">
          <label class="form-label small">Date de fin (événement sur plusieurs jours)</label>
          <input type="date" name="end_date" class="form-control">
        </div>
        <div class="mb-2">
          <label class="form-label small">Activites</label>
          <textarea name="activities" class="form-control" rows="2" placeholder="DJ, discours, animations…"></textarea>
        </div>
        <div class="mb-2">
          <label class="form-label small">Commandes en avance (optionnel)</label>
          <textarea name="advance_orders" class="form-control" rows="2" placeholder="Menus, open-bar, quantites…"></textarea>
        </div>
        <div class="mb-2">
          <label class="form-label small">Partie demandee</label>
          <select name="space_request" class="form-select">
            <option value="">— A definir —</option>
            <option value="ALL_SALLES">Toutes les salles</option>
            <?php foreach ($salles as $s): ?>
              <option value="<?= htmlspecialchars($s['code']) ?>">
                Salle <?= htmlspecialchars($s['code']) ?> — <?= htmlspecialchars($s['label'] ?? $s['name'] ?? '') ?>
                (<?= ($s['status'] ?? 'free') === 'free' ? 'libre' : 'prise' ?>)
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="mb-2">
          <label class="form-label small">Responsable</label>
          <input type="text" name="responsible" class="form-control" placeholder="Nom du responsable SURA / client">
        </div>
        <div class="mb-2">
          <label class="form-label small">Client / Organisateur</label>
          <input type="text" name="client_name" class="form-control">
        </div>
        <div class="mb-2">
          <label class="form-label small">Telephone</label>
          <input type="text" name="client_phone" class="form-control">
        </div>
        <div class="mb-2">
          <label class="form-label small">Capacite / Couverts</label>
          <div class="row g-1">
            <div class="col"><input type="number" name="capacity" class="form-control" placeholder="Capacite"></div>
            <div class="col"><input type="number" name="guests" class="form-control" placeholder="Pers."></div>
          </div>
        </div>
        <div class="mb-2">
          <label class="form-label small">Formule / package</label>
          <textarea name="package_desc" class="form-control" rows="2"></textarea>
        </div>
        <div class="mb-2">
          <label class="form-label small">Acompte</label>
          <select name="deposit_status" class="form-select">
            <option value="not_paid">Non paye</option>
            <option value="partial">Partiel</option>
            <option value="paid">Paye</option>
          </select>
        </div>
        <div class="mb-2">
          <label class="form-label small">Notes</label>
          <textarea name="notes" class="form-control" rows="2"></textarea>
        </div>
        <button class="btn btn-danger w-100">Creer evenement</button>
      </form>
    </div>
  </div>
  <div class="col-lg-8">
    <div class="glass-card rounded-2xl p-4 border border-gold-500/20">
      <div class="table-responsive">
        <table class="table table-sm align-middle">
          <thead>
            <tr>
              <th>Titre</th><th>Date</th><th>Partie</th><th>Responsable</th><th>Activites</th><th>Acompte</th><th>Statut</th><th></th>
            </tr>
          </thead>
          <tbody>
          <?php if (!$events): ?>
            <tr><td colspan="8" class="text-muted">Aucun evenement</td></tr>
          <?php endif; ?>
          <?php foreach ($events as $e): ?>
            <tr>
              <td>
                <strong><?= htmlspecialchars($e['title']) ?></strong>
                <?php if (!empty($e['client_name'])): ?>
                  <div class="small text-muted"><?= htmlspecialchars($e['client_name']) ?> <?= htmlspecialchars($e['client_phone'] ?? '') ?></div>
                <?php endif; ?>
              </td>
              <td class="text-nowrap"><?= htmlspecialchars($e['event_date']) ?><?= !empty($e['end_date']) && $e['end_date'] !== $e['event_date'] ? ' → '.htmlspecialchars($e['end_date']) : '' ?></td>
              <td class="small"><?= htmlspecialchars($e['space_request'] ?? '—') ?></td>
              <td class="small"><?= htmlspecialchars($e['responsible'] ?? '—') ?></td>
              <td class="small"><?= htmlspecialchars(mb_substr($e['activities'] ?? $e['package_desc'] ?? '', 0, 60)) ?></td>
              <td><?= htmlspecialchars($e['deposit_status'] ?? '') ?></td>
              <td><span class="badge bg-secondary"><?= htmlspecialchars($e['status'] ?? '') ?></span></td>
              <td class="text-nowrap">
                <?php if (($e['status'] ?? '') === 'planned'): ?>
                  <a class="btn btn-success btn-sm" href="?status=confirmed&amp;id=<?= (int)$e['id'] ?>">Confirmer</a>
                  <a class="btn btn-outline-danger btn-sm" href="?status=cancelled&amp;id=<?= (int)$e['id'] ?>">Annuler</a>
                <?php elseif (($e['status'] ?? '') === 'confirmed'): ?>
                  <a class="btn btn-outline-secondary btn-sm" href="?status=done&amp;id=<?= (int)$e['id'] ?>">Termine</a>
                <?php endif; ?>
              </td>
            </tr>
            <?php if (!empty($e['advance_orders'])): ?>
              <tr><td colspan="8" class="small text-muted border-0 pt-0">Commandes avance : <?= htmlspecialchars($e['advance_orders']) ?></td></tr>
            <?php endif; ?>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
