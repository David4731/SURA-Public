<?php
header('Location: /pages/station.php?type=kitchen');
exit;
