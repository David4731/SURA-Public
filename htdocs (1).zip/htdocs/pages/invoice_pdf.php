<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/pdf/SimplePDF.php';
requireRole(['accountant', 'admin', 'checker', 'server']);

$pdo = getPDO();
$id = (int)($_GET['id'] ?? 0);
if ($id < 1) {
    http_response_code(400);
    die('ID facture manquant');
}

$st = $pdo->prepare('SELECT i.*, o.table_no, o.client_name, o.client_phone, o.order_type, o.created_at AS order_date
  FROM invoices i JOIN orders o ON o.id = i.order_id WHERE i.id = ?');
$st->execute([$id]);
$inv = $st->fetch();
if (!$inv) {
    http_response_code(404);
    die('Facture introuvable');
}

$items = $pdo->prepare('SELECT * FROM order_items WHERE order_id = ?');
$items->execute([$inv['order_id']]);
$lines = $items->fetchAll();

$pdf = new SimplePDF();
$pdf->reportHeader('Facture', 'Document comptable', $inv['invoice_number']);
$pdf->cell('N facture : ' . $inv['invoice_number']);
$pdf->cell('Date : ' . date('d/m/Y H:i', strtotime($inv['created_at'])));
$pdf->cell('Commande #' . $inv['order_id'] . '  |  Type : ' . $inv['order_type']);
if ($inv['order_type'] === 'dine_in') {
    $pdf->cell('Table : ' . ($inv['table_no'] ?? '-'));
} else {
    $pdf->cell('Client : ' . ($inv['client_name'] ?? '-') . '  ' . ($inv['client_phone'] ?? ''));
}
$pdf->ln(0.3);
$pdf->hr();

$rows = [];
foreach ($lines as $it) {
    $rows[] = [
        $it['item_name'],
        (string)(int)$it['quantity'],
        number_format((float)$it['unit_price'], 0, ',', ' ') . ' Ar',
        number_format((float)$it['subtotal'], 0, ',', ' ') . ' Ar',
    ];
}
if (!$rows) $rows[] = ['-', '0', '-', '-'];
$pdf->sectionTitle('Detail');
$pdf->table(['Article', 'Qte', 'P.U.', 'Total'], $rows, [260, 50, 100, 100], ['L','R','R','R']);
$pdf->kpiRow([
    ['label' => 'Total facture', 'value' => number_format((float)$inv['total'], 0, ',', ' ') . ' Ar'],
    ['label' => 'Paiement', 'value' => (string)($inv['payment_status'] ?? '-')],
    ['label' => 'Mode', 'value' => (string)($inv['payment_method'] ?? '-')],
]);
if (!empty($inv['payer_name'])) {
    $pdf->cell('Payeur : ' . $inv['payer_name'] . ' ' . ($inv['payer_phone'] ?? ''));
}
$pdf->ln(1);
$pdf->hr();
$pdf->setFontSize(9);
$pdf->cell('SURA Restaurant - Olympia Tanjombato');
$pdf->cell('MVola : 038 24 541 74  |  WhatsApp : +261 38 24 541 74');
$pdf->cell('Merci de votre visite.');

$fname = 'SURA_Facture_' . preg_replace('/[^A-Za-z0-9_\-]/', '_', $inv['invoice_number']) . '.pdf';
$pdf->output($fname, 'D');
