<?php
/**
 * Admin — Gestion tables / salles / partitions
 * Partition = plage de tables (ex: T1 à T4) dans une zone (salle, terrasse…)
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Tables & Partitions';
$pdo = getPDO();
$msg = '';
$error = '';

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS restaurant_tables (
      id INT AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(50) NULL,
      code VARCHAR(30) NOT NULL UNIQUE,
      label VARCHAR(100) NOT NULL,
      zone ENUM('salle','terrasse','vip','bar','autre') NOT NULL DEFAULT 'salle',
      capacity INT NOT NULL DEFAULT 4,
      space_type ENUM('table','salle','partition') NOT NULL DEFAULT 'table',
      table_from INT NULL,
      table_to INT NULL,
      status ENUM('free','occupied','reserved') NOT NULL DEFAULT 'free',
      current_order_id INT NULL,
      guest_name VARCHAR(100) NULL,
      is_active TINYINT(1) NOT NULL DEFAULT 1,
      notes VARCHAR(255) NULL,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}

// Colonnes table_from / table_to si absentes
foreach (["ALTER TABLE restaurant_tables ADD COLUMN table_from INT NULL AFTER space_type",
          "ALTER TABLE restaurant_tables ADD COLUMN table_to INT NULL AFTER table_from"] as $sql) {
    try { $pdo->exec($sql); } catch (Exception $e) {}
}

// ——— Actions ———
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    try {
        if ($action === 'add_table') {
            $code = strtoupper(trim($_POST['code'] ?? ''));
            $label = trim($_POST['label'] ?? $code);
            $zone = $_POST['zone'] ?? 'salle';
            $cap = max(1, (int)($_POST['capacity'] ?? 4));
            if ($code === '') throw new Exception('Code table obligatoire (ex: T12).');
            $pdo->prepare("INSERT INTO restaurant_tables (code,label,name,zone,space_type,capacity,status) VALUES (?,?,?,?,'table',?,'free')")
                ->execute([$code, $label, $label, $zone, $cap]);
            $msg = "Table $code ajoutée.";
        }
        if ($action === 'add_salle') {
            $code = strtoupper(trim($_POST['code'] ?? ''));
            $label = trim($_POST['label'] ?? $code);
            $zone = $_POST['zone'] ?? 'salle';
            $cap = max(1, (int)($_POST['capacity'] ?? 40));
            if ($code === '') throw new Exception('Code salle obligatoire.');
            $pdo->prepare("INSERT INTO restaurant_tables (code,label,name,zone,space_type,capacity,status) VALUES (?,?,?,?,'salle',?,'free')")
                ->execute([$code, $label, $label, $zone, $cap]);
            $msg = "Salle $code ajoutée.";
        }
        if ($action === 'add_partition') {
            $code = strtoupper(trim($_POST['code'] ?? ''));
            $label = trim($_POST['label'] ?? '');
            $zone = $_POST['zone'] ?? 'salle';
            $from = (int)($_POST['table_from'] ?? 0);
            $to = (int)($_POST['table_to'] ?? 0);
            $cap = max(1, (int)($_POST['capacity'] ?? 0));
            if ($code === '') throw new Exception('Code partition obligatoire (ex: P1-S1).');
            if ($from < 1 || $to < $from) throw new Exception('Plage de tables invalide (N° début → N° fin).');
            if ($label === '') $label = "Partition $zone · T$from-T$to";
            if ($cap < 1) $cap = ($to - $from + 1) * 4;
            // Créer les tables individuelles manquantes dans la plage
            $insT = $pdo->prepare("INSERT IGNORE INTO restaurant_tables (code,label,name,zone,space_type,capacity,status) VALUES (?,?,?,?,'table',4,'free')");
            for ($n = $from; $n <= $to; $n++) {
                $tc = 'T' . $n;
                $insT->execute([$tc, "Table $n", "Table $n", $zone]);
            }
            $pdo->prepare("INSERT INTO restaurant_tables (code,label,name,zone,space_type,table_from,table_to,capacity,status) VALUES (?,?,?,?,'partition',?,?,?,'free')")
                ->execute([$code, $label, $label, $zone, $from, $to, $cap]);
            $msg = "Partition $code (T$from–T$to) créée. Tables individuelles générées si absentes.";
        }
        if ($action === 'edit') {
            $id = (int)($_POST['id'] ?? 0);
            $label = trim($_POST['label'] ?? '');
            $zone = $_POST['zone'] ?? 'salle';
            $cap = max(1, (int)($_POST['capacity'] ?? 4));
            $active = isset($_POST['is_active']) ? 1 : 0;
            $from = $_POST['table_from'] !== '' ? (int)$_POST['table_from'] : null;
            $to = $_POST['table_to'] !== '' ? (int)$_POST['table_to'] : null;
            $pdo->prepare("UPDATE restaurant_tables SET label=?, name=?, zone=?, capacity=?, is_active=?, table_from=?, table_to=? WHERE id=?")
                ->execute([$label, $label, $zone, $cap, $active, $from, $to, $id]);
            $msg = 'Espace mis à jour.';
        }
        if ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            $pdo->prepare("DELETE FROM restaurant_tables WHERE id=?")->execute([$id]);
            $msg = 'Espace supprimé.';
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

$zones = ['salle'=>'Salle','terrasse'=>'Terrasse','vip'=>'VIP','bar'=>'Bar','autre'=>'Autre'];
$spaces = $pdo->query("SELECT * FROM restaurant_tables ORDER BY space_type, zone, CAST(SUBSTRING(code,2) AS UNSIGNED), code")->fetchAll(PDO::FETCH_ASSOC);
$byType = ['table'=>[],'salle'=>[],'partition'=>[]];
foreach ($spaces as $s) {
    $t = $s['space_type'] ?? 'table';
    if (!isset($byType[$t])) $byType[$t] = [];
    $byType[$t][] = $s;
}

require __DIR__ . '/../includes/header.php';
?>
<div class="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4">
  <div>
    <h2 class="font-serif text-2xl font-bold text-slate-100">Tables · Salles · Partitions</h2>
    <p class="text-slate-400 text-sm">Admin — définir les espaces, zones et plages de tables</p>
  </div>
  <a href="/pages/reservations.php" class="text-gold-400 text-sm hover:underline">← Réservations</a>
</div>

<?php if ($msg): ?><div class="alert alert-success"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
  <!-- Ajouter table -->
  <div class="glass-card rounded-2xl p-4">
    <h5 class="text-gold-300 font-serif mb-3">+ Table</h5>
    <form method="post" class="space-y-2">
      <input type="hidden" name="action" value="add_table">
      <input type="text" name="code" class="form-control form-control-sm" placeholder="Code (T12)" required>
      <input type="text" name="label" class="form-control form-control-sm" placeholder="Libellé">
      <select name="zone" class="form-select form-select-sm">
        <?php foreach ($zones as $k=>$v): ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach; ?>
      </select>
      <input type="number" name="capacity" class="form-control form-control-sm" value="4" min="1" placeholder="Places">
      <button class="btn btn-sm btn-success w-100">Ajouter table</button>
    </form>
  </div>
  <!-- Ajouter salle -->
  <div class="glass-card rounded-2xl p-4">
    <h5 class="text-gold-300 font-serif mb-3">+ Salle</h5>
    <form method="post" class="space-y-2">
      <input type="hidden" name="action" value="add_salle">
      <input type="text" name="code" class="form-control form-control-sm" placeholder="Code (S1)" required>
      <input type="text" name="label" class="form-control form-control-sm" placeholder="Libellé (Salle 1)">
      <select name="zone" class="form-select form-select-sm">
        <?php foreach ($zones as $k=>$v): ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach; ?>
      </select>
      <input type="number" name="capacity" class="form-control form-control-sm" value="40" min="1" placeholder="Capacité">
      <button class="btn btn-sm btn-success w-100">Ajouter salle</button>
    </form>
  </div>
  <!-- Ajouter partition -->
  <div class="glass-card rounded-2xl p-4 border border-gold-500/30">
    <h5 class="text-gold-300 font-serif mb-3">+ Partition (plage de tables)</h5>
    <form method="post" class="space-y-2">
      <input type="hidden" name="action" value="add_partition">
      <input type="text" name="code" class="form-control form-control-sm" placeholder="Code (P1-S1)" required>
      <input type="text" name="label" class="form-control form-control-sm" placeholder="Libellé optionnel">
      <select name="zone" class="form-select form-select-sm">
        <?php foreach ($zones as $k=>$v): ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach; ?>
      </select>
      <div class="row g-1">
        <div class="col-6">
          <label class="text-[10px] text-slate-400">Table N° de</label>
          <input type="number" name="table_from" class="form-control form-control-sm" min="1" required placeholder="1">
        </div>
        <div class="col-6">
          <label class="text-[10px] text-slate-400">à N°</label>
          <input type="number" name="table_to" class="form-control form-control-sm" min="1" required placeholder="4">
        </div>
      </div>
      <input type="number" name="capacity" class="form-control form-control-sm" min="0" placeholder="Capacité (auto si vide)">
      <button class="btn btn-sm btn-warning w-100">Créer partition + tables</button>
    </form>
  </div>
</div>

<?php foreach (['partition'=>'Partitions','salle'=>'Salles','table'=>'Tables'] as $type => $title): ?>
<div class="glass-card rounded-2xl p-4 mb-4">
  <h5 class="text-slate-200 font-serif mb-3"><?= $title ?> <span class="text-slate-500 text-sm">(<?= count($byType[$type] ?? []) ?>)</span></h5>
  <div class="table-responsive">
    <table class="table table-sm table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Code</th><th>Libellé</th><th>Zone</th><th>Places</th>
          <?php if ($type==='partition'): ?><th>Tables</th><?php endif; ?>
          <th>Statut</th><th>Actif</th><th></th>
        </tr>
      </thead>
      <tbody>
      <?php foreach (($byType[$type] ?? []) as $s): ?>
        <tr>
          <td><code><?= htmlspecialchars($s['code']) ?></code></td>
          <td>
            <form method="post" class="d-flex flex-wrap gap-1 align-items-center">
              <input type="hidden" name="action" value="edit">
              <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
              <input type="text" name="label" value="<?= htmlspecialchars($s['label']) ?>" class="form-control form-control-sm" style="min-width:120px">
              <select name="zone" class="form-select form-select-sm" style="width:auto">
                <?php foreach ($zones as $k=>$v): ?>
                  <option value="<?= $k ?>" <?= ($s['zone']??'')===$k?'selected':'' ?>><?= $v ?></option>
                <?php endforeach; ?>
              </select>
              <input type="number" name="capacity" value="<?= (int)$s['capacity'] ?>" class="form-control form-control-sm" style="width:70px" min="1">
              <?php if ($type==='partition'): ?>
                <input type="number" name="table_from" value="<?= htmlspecialchars($s['table_from'] ?? '') ?>" class="form-control form-control-sm" style="width:60px" placeholder="de">
                <input type="number" name="table_to" value="<?= htmlspecialchars($s['table_to'] ?? '') ?>" class="form-control form-control-sm" style="width:60px" placeholder="à">
              <?php else: ?>
                <input type="hidden" name="table_from" value="">
                <input type="hidden" name="table_to" value="">
              <?php endif; ?>
              <label class="small text-slate-400 mb-0"><input type="checkbox" name="is_active" <?= !empty($s['is_active'])?'checked':'' ?>> Actif</label>
              <button class="btn btn-sm btn-outline-success">Sauver</button>
            </form>
          </td>
          <td class="small"><?= htmlspecialchars($zones[$s['zone']] ?? $s['zone']) ?></td>
          <td><?= (int)$s['capacity'] ?></td>
          <?php if ($type==='partition'): ?>
            <td class="small text-nowrap">T<?= (int)($s['table_from']??0) ?>–T<?= (int)($s['table_to']??0) ?></td>
          <?php endif; ?>
          <td><span class="badge bg-<?= ($s['status']??'')==='free'?'success':(($s['status']??'')==='reserved'?'warning':'danger') ?>"><?= htmlspecialchars($s['status']??'') ?></span></td>
          <td><?= !empty($s['is_active']) ? '✓' : '—' ?></td>
          <td>
            <form method="post" onsubmit="return confirm('Supprimer <?= htmlspecialchars($s['code']) ?> ?');">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="id" value="<?= (int)$s['id'] ?>">
              <button class="btn btn-sm btn-outline-danger">✕</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (empty($byType[$type])): ?>
        <tr><td colspan="8" class="text-muted text-center">Aucun élément</td></tr>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endforeach; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>
