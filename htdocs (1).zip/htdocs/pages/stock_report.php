<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole(['stock_manager','kitchen','admin','accountant']);
$pageTitle = 'Rapport Stock';
$pdo = getPDO();

$menus = $pdo->query('SELECT * FROM menus ORDER BY category, name')->fetchAll();
$low = array_filter($menus, fn($m) => (int)$m['stock'] <= (int)($m['stock_min'] ?? 5));
$out = array_filter($menus, fn($m) => (int)$m['stock'] <= 0);

$movements = [];
try {
    $movements = $pdo->query("SELECT sm.*, m.name as menu_name, u.name as user_name
      FROM stock_movements sm
      LEFT JOIN menus m ON m.id = sm.menu_id
      LEFT JOIN users u ON u.id = sm.user_id
      ORDER BY sm.id DESC LIMIT 50")->fetchAll();
} catch (Exception $e) {}

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=stock_sula_'.date('Ymd').'.csv');
    $outf = fopen('php://output', 'w');
    fprintf($outf, chr(0xEF).chr(0xBB).chr(0xBF));
    fputcsv($outf, ['Produit','Catégorie','Stock','Stock min','Prix','Disponible'], ';');
    foreach ($menus as $m) {
        fputcsv($outf, [$m['name'], $m['category'], $m['stock'], $m['stock_min'] ?? 5, $m['price'], $m['available'] ? 'Oui' : 'Non'], ';');
    }
    fclose($outf);
    exit;
}

$cats = ['entree'=>'Entrée','plat'=>'Plat','grill'=>'Grill','boisson'=>'Boisson','openbar'=>'Open-Bar','autre'=>'Autre'];
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <h2 class="mb-0"><i class="bi bi-box-seam text-danger"></i> Rapport Stock</h2>
  <div class="action-bar no-print">
    <a href="?export=csv" class="btn btn-outline-success btn-sm"><i class="bi bi-filetype-csv"></i> CSV</a>
    <a href="/pages/report_pdf.php?type=stock" class="btn btn-danger btn-sm"><i class="bi bi-file-earmark-pdf"></i> PDF Stocks</a>
  </div>
</div>

<div class="row g-3 mb-4">
  <div class="col-6 col-md-3">
    <div class="card stat-card p-3 border-0 shadow-sm">
      <div class="text-muted small">Produits</div>
      <div class="fs-3 fw-bold"><?= count($menus) ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card stat-card p-3 border-0 shadow-sm">
      <div class="text-muted small">Stock bas</div>
      <div class="fs-3 fw-bold text-warning"><?= count($low) ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card stat-card p-3 border-0 shadow-sm">
      <div class="text-muted small">Rupture</div>
      <div class="fs-3 fw-bold text-danger"><?= count($out) ?></div>
    </div>
  </div>
  <div class="col-6 col-md-3">
    <div class="card stat-card p-3 border-0 shadow-sm">
      <div class="text-muted small">Valeur stock</div>
      <div class="fs-5 fw-bold"><?php
        $val = 0;
        foreach ($menus as $m) $val += $m['stock'] * $m['price'];
        echo number_format($val, 0, ',', ' ');
      ?> Ar</div>
    </div>
  </div>
</div>

<?php if ($low): ?>
<div class="alert alert-warning">
  <strong><i class="bi bi-exclamation-triangle"></i> Alertes stock bas / rupture</strong>
  <ul class="mb-0 mt-2">
    <?php foreach ($low as $m): ?>
      <li><?= htmlspecialchars($m['name']) ?> — <strong><?= (int)$m['stock'] ?></strong> (min <?= (int)($m['stock_min'] ?? 5) ?>)</li>
    <?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<div class="card p-3 border-0 shadow-sm mb-3">
  <h5 class="mb-3">État du stock</h5>
  <?php
  $categories = [
    'entree'=>'Entrées','plat'=>'Plats','grill'=>'Grillades','pain'=>'Pains','cafe'=>'Cafés',
    'boisson'=>'Boissons','openbar'=>'Open-Bar','dessert'=>'Desserts','autre'=>'Autre',
  ];
  $menuGridMode = 'stock';
  $menuGridShowTable = true;
  require __DIR__ . '/../includes/menu_grid.php';
?>
</div>

<?php if ($movements): ?>
<div class="card p-3 border-0 shadow-sm">
  <h5 class="mb-3">Derniers mouvements</h5>
  <table class="table table-sm">
    <thead><tr><th><?= t('date') ?></th><th>Produit</th><th>Type</th><th>Qté</th><th>Motif</th><th>Par</th></tr></thead>
    <tbody>
    <?php foreach ($movements as $mv): ?>
      <tr>
        <td class="small"><?= date('d/m H:i', strtotime($mv['created_at'])) ?></td>
        <td><?= htmlspecialchars($mv['menu_name'] ?? '-') ?></td>
        <td><span class="badge bg-secondary"><?= htmlspecialchars($mv['type']) ?></span></td>
        <td><?= (int)$mv['quantite'] ?></td>
        <td class="small"><?= htmlspecialchars($mv['motif'] ?? '') ?></td>
        <td class="small"><?= htmlspecialchars($mv['user_name'] ?? '') ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>
