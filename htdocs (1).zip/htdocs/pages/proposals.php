<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole(['checker','admin']);
$pageTitle = 'Propositions de plats';
$pdo = getPDO();
$user = currentUser();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo->prepare('INSERT INTO dish_proposals (proposed_by,name,description,suggested_price) VALUES (?,?,?,?)')
        ->execute([$user['id'], trim($_POST['name']), trim($_POST['description']), (float)$_POST['suggested_price']]);
    header('Location: /pages/proposals.php?ok=1');
    exit;
}

$list = $pdo->query('SELECT p.*, u.name as proposer FROM dish_proposals p LEFT JOIN users u ON u.id=p.proposed_by ORDER BY p.id DESC LIMIT 50')->fetchAll();
require __DIR__ . '/../includes/header.php';
?>
<h2><?= t('proposal_list') ?></h2>
<p class="text-muted">Si un client demande un plat absent du stock, proposez-le. Le Stock Manager approuvera ou rejettera.</p>
<?php if (isset($_GET['ok'])): ?><div class="alert alert-success">Proposition envoyée.</div><?php endif; ?>

<div class="row">
  <div class="col-md-4">
    <div class="card p-3">
      <form method="post">
        <input type="text" name="name" class="form-control mb-2" placeholder="Nom du plat" required>
        <textarea name="description" class="form-control mb-2" placeholder="Description"></textarea>
        <input type="number" name="suggested_price" class="form-control mb-2" placeholder="Prix suggéré (Ar)" step="100">
        <button class="btn btn-danger w-100">Envoyer au Stock Manager</button>
      </form>
    </div>
  </div>
  <div class="col-md-8">
    <div class="card p-3">
      <table class="table table-sm">
        <thead><tr><th>Plat</th><th>Prix suggéré</th><th>Par</th><th><?= t('status') ?></th></tr></thead>
        <tbody>
        <?php foreach ($list as $p): ?>
          <tr>
            <td><?= htmlspecialchars($p['name']) ?></td>
            <td><?= number_format($p['suggested_price']?:0,0,',',' ') ?> Ar</td>
            <td><?= htmlspecialchars($p['proposer']) ?></td>
            <td><span class="badge bg-<?= $p['status']==='approved'?'success':($p['status']==='rejected'?'danger':'warning') ?>"><?= $p['status'] ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
