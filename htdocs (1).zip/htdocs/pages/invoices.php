
<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';

requireRole(['accountant', 'admin', 'checker']);

$pageTitle = t('invoices');
$pdo = getPDO();
$user = currentUser();

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$printMode = isset($_GET['print']);
$thermal = isset($_GET['thermal']) || $printMode;

$invoice = null;
$lines = [];

if ($id > 0) {
    $inv = $pdo->prepare(
        'SELECT i.*, 
                o.table_no,
                o.client_name,
                o.client_phone,
                o.client_address,
                o.order_type,
                o.delivery_date,
                o.created_at AS order_time
         FROM invoices i
         JOIN orders o ON o.id = i.order_id
         WHERE i.id = ?'
    );

    $inv->execute([$id]);
    $invoice = $inv->fetch(PDO::FETCH_ASSOC);

    if ($invoice) {
        $items = $pdo->prepare(
            'SELECT *
             FROM order_items
             WHERE order_id = ?
             ORDER BY id ASC'
        );

        $items->execute([$invoice['order_id']]);
        $lines = $items->fetchAll(PDO::FETCH_ASSOC);
    }
}

$list = $pdo->query(
    'SELECT i.*,
            o.table_no,
            o.client_name,
            o.created_at AS order_time
     FROM invoices i
     JOIN orders o ON o.id = i.order_id
     ORDER BY i.id DESC
     LIMIT 100'
)->fetchAll(PDO::FETCH_ASSOC);


/* =====================================================
   IMPRESSION THERMIQUE CLASSIQUE DU NAVIGATEUR
===================================================== */

if ($printMode && $invoice):
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>
        Facture <?= htmlspecialchars($invoice['invoice_number']) ?>
    </title>

    <style>
        @page {
            margin: 0;
            size: 80mm auto;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Courier New', Courier, monospace;
            font-size: 12px;
            width: 72mm;
            max-width: 72mm;
            margin: 0 auto;
            padding: 4mm;
            color: #000;
            line-height: 1.35;
        }

        .center {
            text-align: center;
        }

        .bold {
            font-weight: bold;
        }

        .title {
            font-size: 16px;
            font-weight: bold;
            margin-bottom: 2px;
        }

        .subtitle {
            font-size: 11px;
            margin-bottom: 6px;
        }

        .line {
            border-top: 1px dashed #000;
            margin: 6px 0;
        }

        .row {
            display: flex;
            justify-content: space-between;
            gap: 5px;
        }

        .item {
            margin: 3px 0;
        }

        .item-name {
            font-weight: bold;
            overflow-wrap: anywhere;
        }

        .total-row {
            font-size: 14px;
            font-weight: bold;
            margin-top: 4px;
        }

        .footer {
            margin-top: 10px;
            font-size: 10px;
            text-align: center;
        }

        .no-print {
            margin-bottom: 10px;
        }

        @media print {
            .no-print {
                display: none !important;
            }

            body {
                width: 72mm;
            }
        }
    </style>
</head>

<body>

    <div class="no-print">
        <button
            onclick="window.print()"
            style="padding:8px 16px;cursor:pointer;font-size:14px;"
        >
            🖨 Imprimer
        </button>

        <a
            href="?id=<?= (int) $invoice['id'] ?>"
            style="margin-left:8px;"
        >
            <?= htmlspecialchars(t('back')) ?>
        </a>
    </div>

    <div class="center">

        <img
            src="/assets/img/sura-logo.png"
            alt="SURA"
            style="width:48px;height:48px;object-fit:contain;margin:0 auto 4px;display:block;"
        >

        <div class="title">SURA</div>

        <div class="subtitle">
            Korean & Malagasy Restaurant
        </div>

        <div>Flavors United · Olympia Tanjombato</div>
        <div>Tel / WhatsApp: +261 38 24 541 74</div>
        <div>MVola: 038 24 541 74</div>

    </div>

    <div class="line"></div>

    <div>
        <span class="bold">Facture :</span>
        <?= htmlspecialchars($invoice['invoice_number']) ?>
    </div>

    <div>
        <span class="bold">Date :</span>
        <?= date('d/m/Y H:i', strtotime($invoice['created_at'])) ?>
    </div>

    <div>
        <span class="bold">Commande :</span>
        <?= date('d/m/Y H:i', strtotime($invoice['order_time'])) ?>
    </div>

    <?php if ($invoice['order_type'] === 'dine_in'): ?>

        <div>
            <span class="bold">Table :</span>
            <?= htmlspecialchars($invoice['table_no'] ?? '-') ?>
        </div>

    <?php else: ?>

        <div>
            <span class="bold">Client :</span>
            <?= htmlspecialchars($invoice['client_name'] ?? '-') ?>
        </div>

        <?php if (!empty($invoice['client_phone'])): ?>
            <div>
                <span class="bold">Téléphone :</span>
                <?= htmlspecialchars($invoice['client_phone']) ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($invoice['delivery_date'])): ?>
            <div>
                <span class="bold">Livraison :</span>
                <?= date('d/m H:i', strtotime($invoice['delivery_date'])) ?>
            </div>
        <?php endif; ?>

    <?php endif; ?>

    <div class="line"></div>

    <?php foreach ($lines as $l): ?>

        <div class="item">

            <div class="item-name">
                <?= htmlspecialchars($l['item_name']) ?>
            </div>

            <div class="row">
                <span>
                    <?= (int) $l['quantity'] ?>
                    x
                    <?= number_format((float) $l['unit_price'], 0, ',', ' ') ?>
                </span>

                <span>
                    <?= number_format((float) $l['subtotal'], 0, ',', ' ') ?>
                    Ar
                </span>
            </div>

        </div>

    <?php endforeach; ?>

    <div class="line"></div>

    <div class="row total-row">
        <span>TOTAL</span>

        <span>
            <?= number_format((float) $invoice['total'], 0, ',', ' ') ?>
            Ar
        </span>
    </div>

    <div class="row">
        <span>Paiement</span>

        <span class="bold">
            <?= strtoupper(
                $invoice['payment_status'] === 'paid'
                    ? 'PAYE'
                    : (
                        $invoice['payment_status'] === 'partial'
                            ? 'PARTIEL'
                            : 'NON PAYE'
                    )
            ) ?>
        </span>
    </div>

    <div class="line"></div>

    <div class="footer">
        Merci de votre visite !<br>
        SURA · Olympia Tanjombato
    </div>

    <script>
        window.onload = function () {
            setTimeout(function () {
                window.print();
            }, 300);
        };
    </script>

</body>
</html>

<?php
exit;
endif;


/* =====================================================
   AFFICHAGE NORMAL DES FACTURES
===================================================== */

require __DIR__ . '/../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">

    <h2 class="mb-0">
        <?= htmlspecialchars(t('invoices')) ?>
    </h2>

</div>

<div class="row">

    <!-- LISTE DES FACTURES -->

    <div class="col-md-5">

        <div class="card p-3 border-0 shadow-sm">

            <div class="table-responsive">

                <table class="table table-sm table-hover">

                    <thead>
                        <tr>
                            <th>N°</th>
                            <th>Heure</th>
                            <th><?= htmlspecialchars(t('total')) ?></th>
                            <th><?= htmlspecialchars(t('status')) ?></th>
                            <th></th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($list as $i): ?>

                        <tr>

                            <td class="small">
                                <?= htmlspecialchars($i['invoice_number']) ?>
                            </td>

                            <td class="small">
                                <?= date('d/m H:i', strtotime($i['order_time'])) ?>
                            </td>

                            <td>
                                <?= number_format((float) $i['total'], 0, ',', ' ') ?>
                            </td>

                            <td>

                                <span class="badge bg-<?=
                                    $i['payment_status'] === 'paid'
                                        ? 'success'
                                        : (
                                            $i['payment_status'] === 'partial'
                                                ? 'warning'
                                                : 'danger'
                                        )
                                ?>">
                                    <?= htmlspecialchars(t($i['payment_status'])) ?>
                                </span>

                            </td>

                            <td class="text-nowrap">

                                <a href="?id=<?= (int) $i['id'] ?>">
                                    Détail
                                </a>

                                ·

                                <a
                                    href="/pages/invoice_pdf.php?id=<?= (int) $i['id'] ?>"
                                    title="PDF"
                                >
                                    PDF
                                </a>

                                ·

                                <button
                                    type="button"
                                    class="btn btn-sm btn-outline-dark sura-cloud-print"
                                    data-invoice-id="<?= (int) $i['id'] ?>"
                                    title="Imprimer sur OKPOS"
                                >
                                    🖨
                                </button>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    <?php if (empty($list)): ?>

                        <tr>
                            <td colspan="5" class="text-center text-muted">
                                Aucune facture disponible.
                            </td>
                        </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </div>


    <!-- DETAIL DE LA FACTURE -->

    <div class="col-md-7">

        <?php if ($invoice): ?>

            <div class="card p-4 border-0 shadow-sm">

                <div class="d-flex flex-wrap justify-content-between align-items-start gap-2 mb-3">

                    <div>

                        <h4>
                            <?= htmlspecialchars(t('invoice')) ?>
                            <?= htmlspecialchars($invoice['invoice_number']) ?>
                        </h4>

                        <p class="mb-0 text-muted small">

                            <?= htmlspecialchars(t('order_time')) ?> :

                            <?= date('d/m/Y H:i', strtotime($invoice['order_time'])) ?>

                        </p>

                    </div>

                    <div class="d-flex flex-wrap gap-2">

                        <a
                            href="/pages/invoice_pdf.php?id=<?= (int) $invoice['id'] ?>"
                            class="btn btn-danger btn-sm"
                        >
                            <i class="bi bi-file-earmark-pdf"></i>
                            Télécharger PDF
                        </a>

                        <button
                            type="button"
                            class="btn btn-outline-secondary btn-sm sura-cloud-print"
                            data-invoice-id="<?= (int) $invoice['id'] ?>"
                        >
                            <i class="bi bi-printer"></i>
                            Imprimer OKPOS
                        </button>

                    </div>

                </div>


                <div class="table-responsive">

                    <table class="table table-sm mt-2">

                        <thead>

                            <tr>
                                <th><?= htmlspecialchars(t('article')) ?></th>
                                <th><?= htmlspecialchars(t('qty')) ?></th>
                                <th><?= htmlspecialchars(t('unit_price')) ?></th>
                                <th><?= htmlspecialchars(t('total')) ?></th>
                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($lines as $l): ?>

                            <tr>

                                <td>
                                    <?= htmlspecialchars($l['item_name']) ?>
                                </td>

                                <td>
                                    <?= (int) $l['quantity'] ?>
                                </td>

                                <td>
                                    <?= number_format((float) $l['unit_price'], 0, ',', ' ') ?>
                                </td>

                                <td>
                                    <?= number_format((float) $l['subtotal'], 0, ',', ' ') ?>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                        <tfoot>

                            <tr>

                                <th colspan="3">
                                    <?= htmlspecialchars(t('total')) ?>
                                </th>

                                <th>
                                    <?= number_format((float) $invoice['total'], 0, ',', ' ') ?>
                                    Ar
                                </th>

                            </tr>

                        </tfoot>

                    </table>

                </div>

                <p>
                    <?= htmlspecialchars(t('payment')) ?> :

                    <strong>
                        <?= htmlspecialchars(t($invoice['payment_status'])) ?>
                    </strong>
                </p>

            </div>

        <?php else: ?>

            <div class="alert alert-secondary">
                <?= htmlspecialchars(t('select_invoice')) ?>
            </div>

        <?php endif; ?>

    </div>

</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>


<!-- =====================================================
     IMPRESSION DISTANTE SURA - OKPOS
===================================================== -->

<script>
(function () {

    'use strict';

    /*
     * Lecture sécurisée des réponses API.
     * Affiche le contenu brut si le serveur ne renvoie
     * pas du JSON valide.
     */

    async function readJson(response, endpoint) {

        const raw = await response.text();

        let data;

        try {

            data = JSON.parse(raw);

        } catch (error) {

            console.error('Erreur API ' + endpoint, {
                httpStatus: response.status,
                response: raw
            });

            const detail = raw.trim()
                ? raw.substring(0, 700)
                : '[Réponse vide]';

            throw new Error(
                endpoint +
                ' — HTTP ' +
                response.status +
                '\nRéponse serveur :\n' +
                detail
            );
        }

        return data;
    }


    /*
     * Création et suivi d'une impression.
     */

    async function printSura(id, btn) {

        const old = btn.innerHTML;

        btn.disabled = true;
        btn.innerHTML = 'Envoi…';

        try {

            // 1. Création du travail d'impression

            const response = await fetch(
                '/api/print/create.php',
                {
                    method: 'POST',

                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },

                    credentials: 'same-origin',

                    body: JSON.stringify({
                        invoice_id: Number(id)
                    })
                }
            );

            const data = await readJson(
                response,
                'create.php'
            );

            if (!response.ok || !data.ok) {

                throw new Error(
                    data.error ||
                    'Impossible de créer le ticket.'
                );

            }

            if (!data.job_id) {

                throw new Error(
                    'Le serveur n’a pas retourné le numéro du travail.'
                );

            }

            btn.innerHTML = 'Dans la file ✓';
            btn.classList.add('btn-success');

            // 2. Suivi de la file d'impression

            let tries = 0;
            let finished = false;

            const timer = setInterval(async function () {

                if (finished) return;

                try {

                    const statusResponse = await fetch(
                        '/api/print/status.php?job_id=' +
                        encodeURIComponent(data.job_id),

                        {
                            method: 'GET',

                            credentials: 'same-origin',

                            headers: {
                                'Accept': 'application/json'
                            }
                        }
                    );

                    const statusData = await readJson(
                        statusResponse,
                        'status.php'
                    );

                    if (!statusResponse.ok || !statusData.ok) {

                        throw new Error(
                            statusData.error ||
                            'Impossible de vérifier le statut.'
                        );

                    }

                    if (!statusData.job) {

                        throw new Error(
                            'Informations du travail introuvables.'
                        );

                    }

                    const status = statusData.job.status;

                    if (status === 'printed') {

                        finished = true;
                        clearInterval(timer);

                        btn.innerHTML = 'Imprimé ✓';
                        btn.classList.remove('btn-outline-dark');
                        btn.classList.add('btn-success');
                        btn.disabled = false;

                        return;
                    }

                    if (status === 'error') {

                        finished = true;
                        clearInterval(timer);

                        btn.innerHTML = 'Erreur — Réessayer';
                        btn.disabled = false;

                        alert(
                            'Échec de l’impression :\n' +
                            (
                                statusData.job.error_message ||
                                'Erreur inconnue'
                            )
                        );

                        return;
                    }

                    if (status === 'queued') {

                        btn.innerHTML = 'En attente…';

                    } else if (status === 'processing') {

                        btn.innerHTML = 'Impression…';

                    }

                } catch (error) {

                    finished = true;
                    clearInterval(timer);

                    console.error('Suivi impression SURA :', error);

                    btn.innerHTML = 'Erreur — Réessayer';
                    btn.disabled = false;

                    alert(error.message);

                    return;
                }

                tries++;

                if (tries >= 90) {

                    finished = true;
                    clearInterval(timer);

                    btn.innerHTML = 'En attente (voir file)';
                    btn.disabled = false;

                }

            }, 2000);

        } catch (error) {

            console.error('Impression SURA :', error);

            alert(error.message);

            btn.innerHTML = old;
            btn.disabled = false;

        }

    }


    /*
     * Détection des clics sur les boutons d'impression.
     */

    document.addEventListener('click', function (event) {

        const btn = event.target.closest('.sura-cloud-print');

        if (!btn || btn.disabled) {
            return;
        }

        const id = Number(btn.dataset.invoiceId);

        if (!Number.isInteger(id) || id <= 0) {

            alert('Numéro de facture invalide.');

            return;
        }

        printSura(id, btn);

    });

})();
</script>
