<?php
/**
 * Vue poste : kitchen | bakery | bar
 * Usage: station.php?type=kitchen
 */
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/stations.php';

$type = $_GET['type'] ?? 'kitchen';
if (!in_array($type, ['kitchen', 'bakery', 'bar'], true)) {
    $type = 'kitchen';
}

$roleMap = [
    'kitchen' => ['kitchen', 'checker', 'admin'],
    'bakery'  => ['kitchen', 'stock_manager', 'checker', 'admin', 'server'],
    'bar'     => ['server', 'checker', 'admin', 'kitchen'],
];
requireRole($roleMap[$type]);

$pageTitle = stationLabel($type);
$pdo = getPDO();

// Mark item / order ready for this station
if (isset($_GET['ready_order'])) {
    $oid = (int)$_GET['ready_order'];
    // If all stations done, mark order ready; else keep preparing
    $pdo->prepare("UPDATE orders SET status='ready' WHERE id=? AND status IN ('approved','preparing')")->execute([$oid]);
    header('Location: /pages/station.php?type=' . urlencode($type) . '&ok=1');
    exit;
}

if (isset($_GET['preparing'])) {
    $pdo->prepare("UPDATE orders SET status='preparing' WHERE id=? AND status='approved'")->execute([(int)$_GET['preparing']]);
    header('Location: /pages/station.php?type=' . urlencode($type));
    exit;
}

// Categories for this station
$catByStation = [
    'kitchen' => ['entree', 'plat', 'grill', 'autre'],
    'bakery'  => ['pain', 'cafe'],
    'bar'     => ['boisson', 'openbar'],
];
$cats = $catByStation[$type];
$in = implode(',', array_fill(0, count($cats), '?'));

// Orders that have items for this station and are active
$sql = "SELECT DISTINCT o.* FROM orders o
  INNER JOIN order_items oi ON oi.order_id = o.id
  LEFT JOIN menus m ON m.id = oi.menu_id
  WHERE o.status IN ('approved','preparing')
    AND (
      oi.station = ?
      OR (oi.station IS NULL AND m.category IN ($in))
      OR (oi.station IS NULL AND m.id IS NULL AND ? = 'kitchen')
    )
  ORDER BY o.approved_at ASC, o.id ASC";
$params = array_merge([$type], $cats, [$type]);
$st = $pdo->prepare($sql);
$st->execute($params);
$orders = $st->fetchAll();

require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-4">
  <h2 class="mb-0">
    <?php if ($type==='kitchen'): ?>🔥<?php elseif ($type==='bakery'): ?>🥖<?php else: ?>🍹<?php endif; ?>
    <?= htmlspecialchars(stationLabel($type)) ?>
  </h2>
  <div class="action-bar">
    <a href="?type=kitchen" class="btn btn-sm <?= $type==='kitchen'?'btn-danger':'btn-outline-danger' ?>">Cuisine</a>
    <a href="?type=bakery" class="btn btn-sm <?= $type==='bakery'?'btn-danger':'btn-outline-danger' ?>">Boulangerie</a>
    <a href="?type=bar" class="btn btn-sm <?= $type==='bar'?'btn-danger':'btn-outline-danger' ?>">Bar véranda</a>
  </div>
</div>

<?php if (isset($_GET['ok'])): ?><div class="alert alert-success">Commande marquée prête.</div><?php endif; ?>

<?php if (!$orders): ?>
  <div class="alert alert-secondary">Aucune commande en attente pour ce poste.</div>
<?php endif; ?>

<div class="row g-3">
<?php foreach ($orders as $o):
  // Items for this station only
  $items = $pdo->prepare("SELECT oi.*, m.category FROM order_items oi
    LEFT JOIN menus m ON m.id = oi.menu_id WHERE oi.order_id=?");
  $items->execute([$o['id']]);
  $allLines = $items->fetchAll();
  $lines = array_filter($allLines, function ($l) use ($type, $cats) {
      if (!empty($l['station'])) return $l['station'] === $type;
      $c = $l['category'] ?? 'plat';
      return in_array($c, $cats, true);
  });
  if (!$lines) continue;
?>
  <div class="col-md-6 col-lg-4">
    <div class="card p-3 border-0 shadow-sm h-100" style="border-left:4px solid #c62828 !important">
      <div class="d-flex justify-content-between align-items-start mb-2">
        <strong class="fs-5">#<?= (int)$o['id'] ?></strong>
        <span class="badge bg-danger">
          <?= $o['order_type']==='dine_in' ? 'Table '.htmlspecialchars($o['table_no']??'-') : 'Livraison' ?>
        </span>
      </div>
      <div class="small text-muted mb-2">
        <?= $o['approved_at'] ? date('H:i', strtotime($o['approved_at'])) : date('H:i', strtotime($o['created_at'])) ?>
        · <?= htmlspecialchars(t($o['status'])) ?>
      </div>
      <ul class="list-unstyled mb-3">
        <?php foreach ($lines as $l): ?>
          <li class="mb-1">
            <strong><?= (int)$l['quantity'] ?>×</strong>
            <?= htmlspecialchars($l['item_name']) ?>
            <?php if (!empty($l['category'])): ?>
              <span class="badge bg-light text-muted border"><?= htmlspecialchars(categoryLabel($l['category'])) ?></span>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
      <?php if ($o['status'] === 'approved'): ?>
        <a href="?type=<?= urlencode($type) ?>&preparing=<?= (int)$o['id'] ?>" class="btn btn-sm btn-outline-warning w-100 mb-1">En préparation</a>
      <?php endif; ?>
      <a href="?type=<?= urlencode($type) ?>&ready_order=<?= (int)$o['id'] ?>" class="btn btn-sm btn-success w-100">Marquer prêt</a>
    </div>
  </div>
<?php endforeach; ?>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
