<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole(['stock_manager','admin']);
$pageTitle = t('menus');
$pdo = getPDO();
$user = currentUser();
$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['add'])) {
            $pdo->prepare('INSERT INTO menus (name,description,category,price,stock,stock_min,available,image) VALUES (?,?,?,?,?,?,?,?)')
                ->execute([
                    trim($_POST['name']), trim($_POST['description'] ?? ''), $_POST['category'],
                    (float)$_POST['price'], (int)$_POST['stock'], (int)($_POST['stock_min'] ?? 5),
                    isset($_POST['available']) ? 1 : 0, trim($_POST['image'] ?? '') ?: null
                ]);
            $msg = 'Plat ajouté.';
        }
        if (isset($_POST['update'])) {
            $pdo->prepare('UPDATE menus SET name=?, description=?, category=?, price=?, stock=?, stock_min=?, available=?, image=? WHERE id=?')
                ->execute([
                    trim($_POST['name']), trim($_POST['description'] ?? ''), $_POST['category'],
                    (float)$_POST['price'], (int)$_POST['stock'], (int)($_POST['stock_min'] ?? 5),
                    isset($_POST['available']) ? 1 : 0, trim($_POST['image'] ?? '') ?: null, (int)$_POST['id']
                ]);
            // log stock adjustment if changed
            $msg = 'Plat modifié.';
        }
        if (isset($_POST['delete'])) {
            $pdo->prepare('DELETE FROM menus WHERE id=?')->execute([(int)$_POST['id']]);
            $msg = 'Plat supprimé.';
        }
        if (isset($_POST['stock_adjust'])) {
            $id = (int)$_POST['id'];
            $qty = (int)$_POST['qty'];
            $type = $_POST['type'] ?? 'ajustement';
            $motif = trim($_POST['motif'] ?? '');
            $pdo->prepare('UPDATE menus SET stock = stock + ? WHERE id=?')->execute([$qty, $id]);
            try {
                $pdo->prepare('INSERT INTO stock_movements (menu_id, type, quantite, motif, user_id) VALUES (?,?,?,?,?)')
                    ->execute([$id, $type, abs($qty), $motif, $user['id']]);
            } catch (Exception $e) {}
            $msg = 'Stock ajusté.';
        }
    } catch (Exception $e) {
        $msg = 'Erreur: ' . $e->getMessage();
    }
    header('Location: /pages/menus.php?msg=' . urlencode($msg));
    exit;
}

if (isset($_GET['prop'])) {
    $id = (int)$_GET['prop'];
    $act = $_GET['act'] ?? '';
    if ($act === 'approve') {
        $p = $pdo->prepare('SELECT * FROM dish_proposals WHERE id=?');
        $p->execute([$id]);
        $pr = $p->fetch();
        if ($pr) {
            $pdo->prepare('INSERT INTO menus (name,description,price,stock,available,category) VALUES (?,?,?,10,1,"autre")')
                ->execute([$pr['name'], $pr['description'], $pr['suggested_price'] ?: 0]);
            $pdo->prepare("UPDATE dish_proposals SET status='approved', reviewed_by=? WHERE id=?")->execute([$user['id'], $id]);
        }
    } elseif ($act === 'reject') {
        $pdo->prepare("UPDATE dish_proposals SET status='rejected', reviewed_by=? WHERE id=?")->execute([$user['id'], $id]);
    }
    header('Location: /pages/menus.php');
    exit;
}

$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$editItem = null;
if ($editId) {
    $st = $pdo->prepare('SELECT * FROM menus WHERE id=?');
    $st->execute([$editId]);
    $editItem = $st->fetch();
}

$filter = $_GET['filter'] ?? '';
if ($filter === 'low_stock') {
    try {
        $menus = $pdo->query('SELECT * FROM menus WHERE stock <= stock_min AND available=1 ORDER BY stock ASC, category, name')->fetchAll();
    } catch (Exception $e) {
        $menus = $pdo->query('SELECT * FROM menus WHERE stock <= 5 AND available=1 ORDER BY stock ASC, category, name')->fetchAll();
    }
} else {
    $menus = $pdo->query('SELECT * FROM menus ORDER BY category, name')->fetchAll();
}
$proposals = $pdo->query("SELECT * FROM dish_proposals WHERE status='pending' ORDER BY id DESC")->fetchAll();
$cats = ['entree'=>'Entrée','plat'=>'Plat','grill'=>'Grill','pain'=>'Pain','cafe'=>'Café','boisson'=>'Boisson','openbar'=>'Alcool / Open-bar','autre'=>'Autre'];
require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
  <h2 class="font-serif text-2xl font-bold mb-3"><?= t('menus') ?></h2>
  <a href="/pages/stock_report.php" class="btn btn-outline-danger btn-sm"><i class="bi bi-box-seam"></i> Rapport stock</a>
</div>

<?php if (isset($_GET['msg'])): ?><div class="alert alert-info"><?= htmlspecialchars($_GET['msg']) ?></div><?php endif; ?>

<?php if ($proposals): ?>
<div class="alert alert-warning">
  <strong>Propositions en attente</strong>
  <?php foreach ($proposals as $p): ?>
    <div class="d-flex justify-content-between align-items-center mt-2">
      <span><?= htmlspecialchars($p['name']) ?> — <?= number_format($p['suggested_price']?:0,0,',',' ') ?> Ar</span>
      <span>
        <a href="?prop=<?= $p['id'] ?>&act=approve" class="btn btn-sm btn-success">Approuver</a>
        <a href="?prop=<?= $p['id'] ?>&act=reject" class="btn btn-sm btn-outline-danger">Rejeter</a>
      </span>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<div class="row">
  <div class="col-md-4 mb-3">
    <div class="card p-3 border-0 shadow-sm">
      <h5><?= $editItem ? 'Modifier le plat' : htmlspecialchars(t('add_dish')) ?></h5>
      <form method="post">
        <?php if ($editItem): ?>
          <input type="hidden" name="update" value="1">
          <input type="hidden" name="id" value="<?= (int)$editItem['id'] ?>">
        <?php else: ?>
          <input type="hidden" name="add" value="1">
        <?php endif; ?>
        <input type="text" name="name" class="form-control mb-2" placeholder="<?= htmlspecialchars(t('name')) ?>" required
               value="<?= htmlspecialchars($editItem['name'] ?? '') ?>">
        <textarea name="description" class="form-control mb-2" placeholder="<?= htmlspecialchars(t('description')) ?>"><?= htmlspecialchars($editItem['description'] ?? '') ?></textarea>
        <select name="category" class="form-select mb-2">
          <?php foreach ($cats as $k=>$v): ?>
            <option value="<?= $k ?>" <?= ($editItem['category'] ?? '') === $k ? 'selected' : '' ?>><?= $v ?></option>
          <?php endforeach; ?>
        </select>
        <input type="number" name="price" class="form-control mb-2" placeholder="Prix (Ar)" step="100" required
               value="<?= htmlspecialchars($editItem['price'] ?? '') ?>">
        <div class="row g-2 mb-2">
          <div class="col-6">
            <input type="number" name="stock" class="form-control" placeholder="Stock" value="<?= (int)($editItem['stock'] ?? 10) ?>">
          </div>
          <div class="col-6">
            <input type="number" name="stock_min" class="form-control" placeholder="Stock min" value="<?= (int)($editItem['stock_min'] ?? 5) ?>">
          </div>
        </div>
        <input type="text" name="image" class="form-control mb-2" placeholder="Fichier image (ex: bibimbap.jpg)"
               value="<?= htmlspecialchars($editItem['image'] ?? '') ?>">
        <div class="form-check mb-2">
          <input type="checkbox" name="available" class="form-check-input" id="av" <?= !isset($editItem) || $editItem['available'] ? 'checked' : '' ?>>
          <label for="av" class="form-check-label"><?= htmlspecialchars(t('available')) ?></label>
        </div>
        <button class="btn btn-danger w-100"><?= $editItem ? 'Enregistrer' : htmlspecialchars(t('add')) ?></button>
        <?php if ($editItem): ?>
          <a href="/pages/menus.php" class="btn btn-outline-secondary w-100 mt-2"><?= t('cancel') ?></a>
        <?php endif; ?>
      </form>
    </div>
  </div>

  <div class="col-md-8">
    <?php
      $categories = $cats ?? [];
      $menuGridMode = 'manage';
      $menuGridShowTable = true;
      require __DIR__ . '/../includes/menu_grid.php';
    ?>
    <?php foreach ($menus as $m): ?>
      <div class="modal fade" id="stockModal<?= (int)$m['id'] ?>" tabindex="-1">
        <div class="modal-dialog modal-sm">
          <div class="modal-content" style="background:#121215;color:#e2e8f0;border:1px solid rgba(212,175,55,.3)">
            <form method="post">
              <div class="modal-header border-secondary">
                <h6 class="modal-title">Stock : <?= htmlspecialchars($m['name']) ?></h6>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body">
                <input type="hidden" name="stock_adjust" value="1">
                <input type="hidden" name="id" value="<?= (int)$m['id'] ?>">
                <select name="type" class="form-select mb-2">
                  <option value="entree">Entrée (+)</option>
                  <option value="sortie">Sortie (−)</option>
                  <option value="ajustement">Ajustement</option>
                </select>
                <input type="number" name="qty" class="form-control mb-2" placeholder="Quantité (+ ou −)" required>
                <input type="text" name="motif" class="form-control" placeholder="Motif">
              </div>
              <div class="modal-footer border-secondary">
                <button class="btn btn-danger btn-sm">Valider</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
