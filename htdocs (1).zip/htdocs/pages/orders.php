<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/stations.php';
requireRole(['server', 'checker', 'admin', 'accountant']);

$pageTitle = t('orders');
$pdo = getPDO();
$user = currentUser();
$msg = '';
$error = '';
require_once __DIR__ . '/../includes/payments.php';
require_once __DIR__ . '/../includes/client_types.php';
if (function_exists('sulaEnsureClientTypeColumn')) { try { sulaEnsureClientTypeColumn(getPDO()); } catch (Exception $e) {} }
require_once __DIR__ . '/../includes/notify.php';

// Ensure change-request table exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS order_change_requests (
      id INT AUTO_INCREMENT PRIMARY KEY,
      order_id INT NOT NULL,
      requested_by INT NOT NULL,
      request_type ENUM('modify','cancel') NOT NULL,
      reason TEXT NULL,
      proposed_data TEXT NULL,
      status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
      reviewed_by INT NULL,
      reviewed_at DATETIME NULL,
      review_note TEXT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      INDEX idx_order_status (order_id, status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}

// ——— Demande modification / annulation (Serveur ou Checker) ———
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'request_change') {
    try {
        if (!in_array($user['role'], ['server', 'checker', 'admin'], true)) {
            throw new Exception('Non autorisé.');
        }
        $oid = (int)($_POST['order_id'] ?? 0);
        $rtype = $_POST['request_type'] ?? 'cancel';
        if (!in_array($rtype, ['modify', 'cancel'], true)) $rtype = 'cancel';
        $reason = trim($_POST['reason'] ?? '');
        $st = $pdo->prepare('SELECT * FROM orders WHERE id=?');
        $st->execute([$oid]);
        $o = $st->fetch(PDO::FETCH_ASSOC);
        if (!$o) throw new Exception('Commande introuvable.');
        if ($o['status'] === 'completed' || $o['status'] === 'cancelled') {
            throw new Exception('Commande déjà clôturée ou annulée — modification impossible.');
        }
        // Empêcher double demande pending
        $chk = $pdo->prepare("SELECT id FROM order_change_requests WHERE order_id=? AND status='pending' LIMIT 1");
        $chk->execute([$oid]);
        if ($chk->fetch()) throw new Exception('Une demande est déjà en attente pour cette commande.');

        $proposed = null;
        if ($rtype === 'modify') {
            $proposed = json_encode([
                'table_no' => trim($_POST['new_table_no'] ?? ''),
                'notes' => trim($_POST['new_notes'] ?? ''),
                'client_name' => trim($_POST['new_client_name'] ?? ''),
                'client_phone' => trim($_POST['new_client_phone'] ?? ''),
            ], JSON_UNESCAPED_UNICODE);
        }

        $pdo->prepare('INSERT INTO order_change_requests (order_id, requested_by, request_type, reason, proposed_data, status) VALUES (?,?,?,?,?,\'pending\')')
            ->execute([$oid, $user['id'], $rtype, $reason ?: null, $proposed]);
        $reqId = (int)$pdo->lastInsertId();

        // Notification à l'autre rôle
        $otherRole = $user['role'] === 'server' ? 'Checker' : 'Serveur';
        $title = ($rtype === 'cancel' ? 'Demande d\'annulation' : 'Demande de modification') . ' #' . $oid;
        $body = 'Par ' . $user['name'] . ' (' . $user['role'] . '). ' . ($reason ? 'Motif: ' . $reason . '. ' : '') . 'En attente validation ' . $otherRole . '.';
        sulaNotify($pdo, $title, $body, 'order_change');

        $msg = 'Demande envoyée. En attente d\'approbation du ' . $otherRole . '.';
        header('Location: /pages/orders.php?ok=1&msg=' . urlencode($msg));
        exit;
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// ——— Approuver / Rejeter une demande (l'autre rôle) ———
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'review_change') {
    try {
        if (!in_array($user['role'], ['server', 'checker', 'admin'], true)) {
            throw new Exception('Non autorisé.');
        }
        $reqId = (int)($_POST['request_id'] ?? 0);
        $decision = $_POST['decision'] ?? '';
        $note = trim($_POST['review_note'] ?? '');
        $st = $pdo->prepare('SELECT r.*, o.status AS order_status, o.payment_status FROM order_change_requests r JOIN orders o ON o.id=r.order_id WHERE r.id=?');
        $st->execute([$reqId]);
        $req = $st->fetch(PDO::FETCH_ASSOC);
        if (!$req || $req['status'] !== 'pending') throw new Exception('Demande introuvable ou déjà traitée.');

        // Règle : le demandeur ne peut pas s'auto-approuver (sauf admin)
        if ((int)$req['requested_by'] === (int)$user['id'] && $user['role'] !== 'admin') {
            throw new Exception('Vous ne pouvez pas valider votre propre demande. Attendez le ' . ($user['role']==='server'?'Checker':'Serveur') . '.');
        }
        // Serveur demande → Checker valide ; Checker demande → Serveur valide ; Admin peut tout
        $requesterRole = null;
        try {
            $ur = $pdo->prepare('SELECT role FROM users WHERE id=?');
            $ur->execute([(int)$req['requested_by']]);
            $requesterRole = $ur->fetchColumn();
        } catch (Exception $e) {}

        if ($user['role'] !== 'admin') {
            if ($requesterRole === 'server' && $user['role'] !== 'checker') {
                throw new Exception('Seul le Checker peut valider une demande du Serveur.');
            }
            if ($requesterRole === 'checker' && $user['role'] !== 'server') {
                throw new Exception('Seul le Serveur peut valider une demande du Checker.');
            }
        }

        if ($decision === 'approve') {
            $pdo->beginTransaction();
            $pdo->prepare("UPDATE order_change_requests SET status='approved', reviewed_by=?, reviewed_at=NOW(), review_note=? WHERE id=?")
                ->execute([$user['id'], $note ?: null, $reqId]);
            if ($req['request_type'] === 'cancel') {
                $pdo->prepare("UPDATE orders SET status='cancelled' WHERE id=? AND status NOT IN ('completed','cancelled')")
                    ->execute([(int)$req['order_id']]);
                try {
                    $pdo->prepare("UPDATE restaurant_tables SET status='free', current_order_id=NULL, guest_name=NULL WHERE current_order_id=?")
                        ->execute([(int)$req['order_id']]);
                } catch (Exception $ex) {}
            } elseif ($req['request_type'] === 'modify' && !empty($req['proposed_data'])) {
                $data = json_decode($req['proposed_data'], true) ?: [];
                $sets = [];
                $params = [];
                foreach (['table_no'=>'new_table_no','notes'=>'notes','client_name'=>'client_name','client_phone'=>'client_phone'] as $col => $key) {
                    // proposed_data keys: table_no, notes, client_name, client_phone
                }
                if (isset($data['table_no']) && $data['table_no'] !== '') {
                    $sets[] = 'table_no=?'; $params[] = $data['table_no'];
                }
                if (isset($data['notes'])) {
                    $sets[] = 'notes=?'; $params[] = $data['notes'];
                }
                if (isset($data['client_name']) && $data['client_name'] !== '') {
                    $sets[] = 'client_name=?'; $params[] = $data['client_name'];
                }
                if (isset($data['client_phone']) && $data['client_phone'] !== '') {
                    $sets[] = 'client_phone=?'; $params[] = $data['client_phone'];
                }
                if ($sets) {
                    $params[] = (int)$req['order_id'];
                    $pdo->prepare('UPDATE orders SET ' . implode(',', $sets) . ' WHERE id=? AND status NOT IN (\'completed\',\'cancelled\')')
                        ->execute($params);
                }
            }
            $pdo->commit();
            sulaNotify($pdo, 'Demande #' . $reqId . ' approuvée', 'Commande #' . $req['order_id'] . ' — ' . $req['request_type'] . ' validée par ' . $user['name'], 'order_change');
            $msg = 'Demande approuvée.';
        } elseif ($decision === 'reject') {
            $pdo->prepare("UPDATE order_change_requests SET status='rejected', reviewed_by=?, reviewed_at=NOW(), review_note=? WHERE id=?")
                ->execute([$user['id'], $note ?: null, $reqId]);
            sulaNotify($pdo, 'Demande #' . $reqId . ' refusée', 'Commande #' . $req['order_id'] . ' — refusée par ' . $user['name'], 'order_change');
            $msg = 'Demande refusée.';
        } else {
            throw new Exception('Décision invalide.');
        }
        header('Location: /pages/orders.php?ok=1');
        exit;
    } catch (Exception $e) {
        if ($pdo->inTransaction()) try { $pdo->rollBack(); } catch (Exception $rb) {}
        $error = $e->getMessage();
    }
}


// Create order
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create') {
    try {
        $type   = $_POST['order_type'] ?? 'dine_in';
        $table  = trim($_POST['table_no'] ?? '');
        if ($type === 'dine_in' && $table === '') {
            throw new Exception('Le numéro de table est obligatoire pour une commande sur place.');
        }

        $cname  = trim($_POST['client_name'] ?? '');
        $ctype  = function_exists('sulaNormalizeClientType') ? sulaNormalizeClientType($_POST['client_type'] ?? 'individu') : 'individu';
        $corg   = trim($_POST['organization'] ?? '');
        $cphone = trim($_POST['client_phone'] ?? '');
        $caddr  = trim($_POST['client_address'] ?? '');
        $ddate  = trim($_POST['delivery_date'] ?? '');
        $items  = isset($_POST['items']) && is_array($_POST['items']) ? $_POST['items'] : [];

        $total = 0;
        $lines = [];
        foreach ($items as $mid => $qty) {
            $qty = (int) $qty;
            if ($qty < 1) continue;
            $stmt = $pdo->prepare('SELECT * FROM menus WHERE id = ? AND available = 1');
            $stmt->execute([(int) $mid]);
            $menu = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$menu) continue;
            $availableStock = (int)($menu['stock'] ?? 0);
            if ($availableStock <= 0) {
                throw new Exception('Le plat « ' . $menu['name'] . ' » est épuisé et ne peut pas être commandé.');
            }
            if ($qty > $availableStock) {
                throw new Exception('Stock insuffisant pour « ' . $menu['name'] . ' ». Quantité disponible : ' . $availableStock . '.');
            }
            $sub = (float)$menu['price'] * $qty;
            $total += $sub;
            $lines[] = [
                'menu_id' => $menu['id'],
                'name'    => $menu['name'],
                'qty'     => $qty,
                'price'   => $menu['price'],
                'sub'     => $sub,
            ];
        }

        if (count($lines) > 0) {
            $pdo->beginTransaction();
            $sql = 'INSERT INTO orders (user_id, order_type, table_no, client_name, client_phone, client_address, delivery_date, total, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, "pending")';
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $user['id'],
                $type,
                $table !== '' ? $table : null,
                $cname !== '' ? $cname : null,
                $cphone !== '' ? $cphone : null,
                $caddr !== '' ? $caddr : null,
                ($type === 'delivery' && $ddate !== '') ? $ddate : null,
                $total,
            ]);
            $oid = $pdo->lastInsertId();
            try {
                if (!empty($ctype)) {
                    $pdo->prepare('UPDATE orders SET client_type=? WHERE id=?')->execute([$ctype, $oid]);
                }
            } catch (Exception $e) {}
            // Table OCCUPEE jusqu a cloture (serveur/checker)
            if ($type === 'dine_in' && $table !== '') {
                try {
                    $code = $table;
                    if (preg_match('/T?(\d+)/i', $table, $m)) $code = 'T' . (int)$m[1];
                    $pdo->prepare("UPDATE restaurant_tables SET status='occupied', current_order_id=?, guest_name=? WHERE code=? OR name=? OR label=?")
                        ->execute([$oid, $cname ?: ('Cmd#'.$oid), $code, $code, $code]);
                } catch (Exception $ex) {}
                try {
                    require_once __DIR__ . '/../includes/notify.php';
                    sulaNotify($pdo, 'Table '.$table.' occupee', 'Commande #'.$oid.' — reste occupee jusqu a cloture', 'order');
                } catch (Exception $ex) {}
            }

            foreach ($lines as &$l) {
                $mc = $pdo->prepare('SELECT category FROM menus WHERE id=?');
                $mc->execute([$l['menu_id']]);
                $cat = $mc->fetchColumn() ?: 'plat';
                $l['station'] = stationForCategory($cat);
            }
            unset($l);
            try {
                $ins = $pdo->prepare('INSERT INTO order_items (order_id, menu_id, item_name, quantity, unit_price, subtotal, station) VALUES (?,?,?,?,?,?,?)');
                foreach ($lines as $l) {
                    $ins->execute([$oid, $l['menu_id'], $l['name'], $l['qty'], $l['price'], $l['sub'], $l['station']]);
                }
            } catch (Exception $exSt) {
                $ins = $pdo->prepare('INSERT INTO order_items (order_id, menu_id, item_name, quantity, unit_price, subtotal) VALUES (?,?,?,?,?,?)');
                foreach ($lines as $l) {
                    $ins->execute([$oid, $l['menu_id'], $l['name'], $l['qty'], $l['price'], $l['sub']]);
                }
            }
            $pdo->commit();
            $msg = t('order_created') . ' #' . $oid . ' — ' . number_format($total, 0, ',', ' ') . ' Ar';
        } else {
            $error = 'Ajoutez au moins un plat.';
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            try { $pdo->rollBack(); } catch (Exception $rb) {}
        }
        $error = $e->getMessage();
    }
}

// Approve (Checker) — with payment method
// --- Approuver commande (Checker + Admin) ---
if ((isset($_POST['approve_order']) || isset($_GET['approve'])) && in_array($user['role'], ['checker', 'admin'], true)) {
    try {
        $oid = (int)($_POST['order_id'] ?? $_GET['approve'] ?? 0);
        if ($oid < 1) throw new Exception('Commande invalide.');

        $pay = $_POST['payment_status'] ?? $_GET['pay'] ?? 'paid';
        $method = $_POST['payment_method'] ?? 'cash';
        $payerName = trim($_POST['payer_name'] ?? '');
        $payerPhone = trim($_POST['payer_phone'] ?? '');
        if (!in_array($pay, ['not_paid', 'partial', 'paid'], true)) $pay = 'not_paid';
        $allowedMethods = ['cash','mvola','orange_money','airtel_money','virement','autre'];
        if (!in_array($method, $allowedMethods, true)) $method = 'cash';

        // Vérifier que la commande est encore pending + forcer mode client si livraison
        $chk = $pdo->prepare("SELECT * FROM orders WHERE id=?");
        $chk->execute([$oid]);
        $orderRow = $chk->fetch(PDO::FETCH_ASSOC);
        if (!$orderRow) throw new Exception('Commande introuvable.');
        if ($orderRow['status'] !== 'pending') throw new Exception('Cette commande est déjà traitée (statut: '.$orderRow['status'].').');

        // Livraison : le mode de paiement = celui choisi par le client (Checker ne choisit pas)
        if (($orderRow['order_type'] ?? '') === 'delivery') {
            $clientMethod = $orderRow['payment_method'] ?? '';
            if (in_array($clientMethod, $allowedMethods, true)) {
                $method = $clientMethod;
            }
            // Envoyeur = client si non renseigné
            if ($payerName === '') $payerName = trim($orderRow['payer_name'] ?? $orderRow['client_name'] ?? '');
            if ($payerPhone === '') $payerPhone = trim($orderRow['payer_phone'] ?? $orderRow['client_phone'] ?? '');
        }
        if ($method === 'cash') { $payerName = ''; $payerPhone = ''; }

        // Mise à jour progressive (tolère colonnes absentes)
        $updated = false;
        $attempts = [
            "UPDATE orders SET status='approved', payment_status=?, payment_method=?, payer_name=?, payer_phone=?, approved_at=NOW() WHERE id=? AND status='pending'",
            "UPDATE orders SET status='approved', payment_status=?, approved_at=NOW() WHERE id=? AND status='pending'",
            "UPDATE orders SET status='approved', payment_status=? WHERE id=? AND status='pending'",
            "UPDATE orders SET status='approved' WHERE id=? AND status='pending'",
        ];
        $paramsList = [
            [$pay, $method, $payerName ?: null, $payerPhone ?: null, $oid],
            [$pay, $oid],
            [$pay, $oid],
            [$oid],
        ];
        foreach ($attempts as $i => $sql) {
            try {
                $st = $pdo->prepare($sql);
                $st->execute($paramsList[$i]);
                if ($st->rowCount() > 0 || true) { // even if 0, status might already match
                    $updated = true;
                    break;
                }
            } catch (Exception $ex) {
                continue;
            }
        }
        if (!$updated) throw new Exception('Impossible de mettre à jour la commande.');

        // Forcer statut + paiement minimal
        try {
            $pdo->prepare("UPDATE orders SET status='approved', payment_status=? WHERE id=?")->execute([$pay, $oid]);
        } catch (Exception $ex) {
            $pdo->prepare("UPDATE orders SET status='approved' WHERE id=?")->execute([$oid]);
        }

        $st = $pdo->prepare('SELECT * FROM orders WHERE id=?');
        $st->execute([$oid]);
        $o = $st->fetch();

        if ($o) {
            $exists = $pdo->prepare('SELECT id FROM invoices WHERE order_id=?');
            $exists->execute([$oid]);
            if (!$exists->fetch()) {
                $num = 'SURA-' . date('Ymd') . '-' . str_pad((string)$oid, 4, '0', STR_PAD_LEFT);
                $paidAmt = ($pay === 'paid') ? (float)$o['total'] : 0;
                $invOk = false;
                try {
                    $pdo->prepare('INSERT INTO invoices (order_id,invoice_number,total,payment_status,payment_method,payer_name,payer_phone,paid_amount) VALUES (?,?,?,?,?,?,?,?)')
                        ->execute([$oid, $num, $o['total'], $pay, $method, $payerName ?: null, $payerPhone ?: null, $paidAmt]);
                    $invOk = true;
                } catch (Exception $ex) {}
                if (!$invOk) {
                    try {
                        $pdo->prepare('INSERT INTO invoices (order_id,invoice_number,total,payment_status,paid_amount) VALUES (?,?,?,?,?)')
                            ->execute([$oid, $num, $o['total'], $pay, $paidAmt]);
                        $invOk = true;
                    } catch (Exception $ex) {}
                }
                if (!$invOk) {
                    $pdo->prepare('INSERT INTO invoices (order_id,invoice_number,total,payment_status) VALUES (?,?,?,?)')
                        ->execute([$oid, $num, $o['total'], $pay]);
                }
            }
        }

        // Décrémenter le stock
        try {
            $items = $pdo->prepare('SELECT menu_id, quantity FROM order_items WHERE order_id=? AND menu_id IS NOT NULL');
            $items->execute([$oid]);
            foreach ($items->fetchAll() as $it) {
                $pdo->prepare('UPDATE menus SET stock = GREATEST(0, stock - ?) WHERE id=?')
                    ->execute([(int)$it['quantity'], (int)$it['menu_id']]);
                try {
                    $pdo->prepare('INSERT INTO stock_movements (menu_id, type, quantite, motif, user_id) VALUES (?,?,?,?,?)')
                        ->execute([(int)$it['menu_id'], 'vente', (int)$it['quantity'], 'Commande #'.$oid, $user['id']]);
                } catch (Exception $e2) {}
            }
        } catch (Exception $eStock) {}

        // Notification
        try {
            $pdo->prepare("INSERT INTO notifications (user_id, type, title, body) VALUES (NULL, 'order', ?, ?)")
                ->execute(['Commande #'.$oid.' approuvée', 'Par '.$user['name'].' · Paiement: '.$pay]);
        } catch (Exception $eN) {}

        header('Location: /pages/orders.php?ok=approved');
        exit;
    } catch (Exception $e) {
        $error = 'Approbation: ' . $e->getMessage();
    }
}

// Complete (Server only + paid only)
if (isset($_GET['complete']) && $user['role'] === 'server') {
    try {
        $oid = (int) $_GET['complete'];
        $st = $pdo->prepare('SELECT payment_status, status FROM orders WHERE id = ?');
        $st->execute([$oid]);
        $o = $st->fetch();
        if ($o && $o['payment_status'] === 'paid' && in_array($o['status'], ['approved', 'ready', 'preparing'], true)) {
            $pdo->prepare("UPDATE orders SET status = 'completed', completed_at = NOW() WHERE id = ?")->execute([$oid]);
            try {
                $pdo->prepare("UPDATE restaurant_tables SET status='free', current_order_id=NULL, guest_name=NULL WHERE current_order_id=?")->execute([$oid]);
                $ot = $pdo->prepare('SELECT table_no FROM orders WHERE id=?');
                $ot->execute([$oid]);
                $tn = $ot->fetchColumn();
                if ($tn) {
                    $code = $tn;
                    if (preg_match('/T?(\d+)/i', $tn, $m)) $code = 'T' . (int)$m[1];
                    $pdo->prepare("UPDATE restaurant_tables SET status='free', current_order_id=NULL, guest_name=NULL WHERE code=? OR name=?")->execute([$code, $code]);
                }
            } catch (Exception $ex) {}

            header('Location: /pages/orders.php?ok=1');
            exit;
        }
        $error = t('error_unpaid_close');
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Mark paid
if (isset($_GET['mark_paid']) && in_array($user['role'], ['checker', 'accountant'], true)) {
    try {
        $oid = (int) $_GET['mark_paid'];
        $pdo->prepare("UPDATE orders SET payment_status = 'paid' WHERE id = ?")->execute([$oid]);
        $pdo->prepare("UPDATE invoices SET payment_status = 'paid', paid_amount = total WHERE order_id = ?")->execute([$oid]);
        header('Location: /pages/orders.php?ok=1');
        exit;
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// CSV export
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=orders_' . date('Ymd_His') . '.csv');
    $out = fopen('php://output', 'w');
    fprintf($out, chr(0xEF) . chr(0xBB) . chr(0xBF));
    fputcsv($out, ['ID', 'Date', 'Type', 'Client', 'Total', 'Statut', 'Paiement'], ';');
    $rows = $pdo->query('SELECT * FROM orders ORDER BY id DESC LIMIT 500')->fetchAll();
    foreach ($rows as $r) {
        fputcsv($out, [
            $r['id'],
            $r['created_at'],
            $r['order_type'],
            $r['order_type'] === 'dine_in' ? ($r['table_no'] ?? '') : ($r['client_name'] ?? ''),
            $r['total'],
            $r['status'],
            $r['payment_status'],
        ], ';');
    }
    fclose($out);
    exit;
}

$menus  = $pdo->query('SELECT * FROM menus WHERE available = 1 ORDER BY category, name')->fetchAll();
$searchQ = trim($_GET['q'] ?? '');
if ($searchQ !== '') {
    $st = $pdo->prepare("SELECT o.*, u.name AS server_name FROM orders o LEFT JOIN users u ON u.id = o.user_id
      WHERE o.id = ? OR o.client_name LIKE ? OR o.client_phone LIKE ? OR o.table_no LIKE ?
      ORDER BY o.id DESC LIMIT 50");
    $like = '%' . $searchQ . '%';
    $st->execute([(int)$searchQ, $like, $like, $like]);
    $orders = $st->fetchAll();
} else {
    $statusFilter = trim($_GET['status'] ?? '');
    if ($statusFilter !== '' && in_array($statusFilter, ['pending','approved','preparing','ready','completed','cancelled'], true)) {
        $st = $pdo->prepare('SELECT o.*, u.name AS server_name FROM orders o LEFT JOIN users u ON u.id = o.user_id WHERE o.status=? ORDER BY o.id DESC LIMIT 50');
        $st->execute([$statusFilter]);
        $orders = $st->fetchAll();
    } else {
        $orders = $pdo->query('SELECT o.*, u.name AS server_name FROM orders o LEFT JOIN users u ON u.id = o.user_id ORDER BY o.id DESC LIMIT 50')->fetchAll();
    }
}

// Détails lignes + preuves paiement pour affichage avant approbation
$orderItemsMap = [];
$orderPayMap = [];
try {
    $oids = array_column($orders, 'id');
    if ($oids) {
        $in = implode(',', array_map('intval', $oids));
        foreach ($pdo->query("SELECT order_id, item_name, quantity, unit_price, subtotal FROM order_items WHERE order_id IN ($in) ORDER BY id") as $it) {
            $orderItemsMap[(int)$it['order_id']][] = $it;
        }
        try {
            foreach ($pdo->query("SELECT * FROM payment_requests WHERE order_id IN ($in) ORDER BY id DESC") as $pr) {
                $oid = (int)$pr['order_id'];
                if (!isset($orderPayMap[$oid])) $orderPayMap[$oid] = $pr;
            }
        } catch (Exception $e) {}
    }
} catch (Exception $e) {}

$invoiceMap = [];
try {
    foreach ($pdo->query('SELECT id, order_id FROM invoices') as $inv) {
        $invoiceMap[$inv['order_id']] = $inv['id'];
    }
} catch (Exception $e) {}

// Demandes de modif/annulation en attente
$pendingChanges = [];
$myPendingChangeByOrder = [];
try {
    $rows = $pdo->query("SELECT r.*, u.name AS requester_name FROM order_change_requests r LEFT JOIN users u ON u.id=r.requested_by WHERE r.status='pending' ORDER BY r.id DESC")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) {
        $pendingChanges[] = $r;
        $myPendingChangeByOrder[(int)$r['order_id']] = $r;
    }
} catch (Exception $e) {}


$categories = [
    'entree'  => 'Entrées',
    'plat'    => 'Plats',
    'grill'   => 'Grillades',
    'pain'    => 'Pains',
    'cafe'    => 'Cafés',
    'boisson' => 'Boissons',
    'openbar' => 'Alcool / Open-bar',
    'autre'   => 'Autre',
];

// Tables libres pour commande (occupees exclues ; reservees futures encore selectionnables)
$freeTables = [];
try {
    $allT = $pdo->query("SELECT * FROM restaurant_tables WHERE is_active=1 AND (space_type='table' OR space_type IS NULL OR space_type='') ORDER BY code")->fetchAll();
    $now = date('Y-m-d H:i:s');
    $blockedNow = [];
    try {
        $st = $pdo->query("SELECT space_codes, table_partition FROM reservations WHERE status='confirmed' AND reservation_date=CURDATE() AND reservation_time <= CURTIME() AND ADDTIME(reservation_time,'02:00:00') >= CURTIME()");
        foreach ($st->fetchAll() as $r) {
            $csv = $r['space_codes'] ?? $r['table_partition'] ?? '';
            foreach (preg_split('/[,;\s]+/', $csv) as $c) {
                $c = trim($c);
                if ($c !== '') $blockedNow[strtoupper($c)] = true;
                if (preg_match('/T(\d+)/i', $c, $m)) $blockedNow['T'.(int)$m[1]] = true;
            }
        }
    } catch (Exception $e) {}
    foreach ($allT as $tb) {
        $st = $tb['status'] ?? 'free';
        $code = $tb['code'] ?? '';
        if ($st === 'occupied') continue;
        if (!empty($blockedNow[strtoupper($code)])) continue;
        $freeTables[] = $tb;
    }
} catch (Exception $e) {}

require __DIR__ . '/../includes/header.php';
?>

<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
  <div>
    <p class="text-[11px] uppercase tracking-[0.2em] text-gold-500/80 font-semibold mb-1"><?= t('service') ?></p>
    <h2 class="font-serif text-2xl md:text-3xl font-bold text-slate-100 mb-0"><?= htmlspecialchars(t('orders')) ?></h2>
  </div>
  <div class="action-bar no-print">
    <a href="?export=csv" class="btn btn-outline-success btn-sm"><i class="bi bi-filetype-csv"></i> <?= htmlspecialchars(t('export_csv')) ?></a>
    <a href="/pages/report_pdf.php?type=sales&period=today" class="btn btn-outline-danger btn-sm"><i class="bi bi-file-earmark-pdf"></i> PDF</a>
  </div>
</div>

<?php if ($msg !== ''): ?>
  <div class="alert alert-info"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>
<?php if ($error !== ''): ?>
  <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<?php if (isset($_GET['ok'])): ?>
  <div class="alert alert-success"><i class="fa-solid fa-circle-check me-2"></i><?= htmlspecialchars(t('success')) ?></div>
<?php endif; ?>

<div class="row">
  <!-- Nouvelle commande -->
  <div class="col-12 mb-4">
    <div class="card p-3">
      <h5 class="mb-3"><?= htmlspecialchars(t('new_order')) ?></h5>
      <form method="post">
        <input type="hidden" name="action" value="create">

        <div class="mb-2">
          <label class="form-label"><?= htmlspecialchars(t('type')) ?></label>
          <select name="order_type" class="form-select" id="orderType">
            <option value="dine_in"><?= htmlspecialchars(t('dine_in')) ?></option>
            <option value="delivery"><?= htmlspecialchars(t('delivery')) ?></option>
          </select>
        </div>

        <div class="mb-2" id="tableField">
          <label class="form-label"><?= htmlspecialchars(t('table_no')) ?> (libres uniquement)</label>
          <select name="table_no" class="form-select" required>
            <option value="">— Choisir une table libre —</option>
            <?php foreach ($freeTables as $tb): ?>
              <option value="<?= htmlspecialchars($tb['code']) ?>">
                <?= htmlspecialchars($tb['code']) ?>
                <?php if (!empty($tb['label'])): ?> — <?= htmlspecialchars($tb['label']) ?><?php endif; ?>
                (<?= (int)($tb['capacity'] ?? 6) ?> p.)
              </option>
            <?php endforeach; ?>
          </select>
          <?php if (!$freeTables): ?>
            <div class="form-text text-warning">Aucune table libre pour le moment.</div>
          <?php endif; ?>
        </div>

        <div class="mb-2 d-none" id="clientFields">
          <label class="form-label"><?= htmlspecialchars(t('client')) ?></label>
          <select name="client_type" class="form-select mb-1">
            <?php foreach (function_exists('sulaClientTypes') ? sulaClientTypes() : ['individu'=>'Individu'] as $c=>$l): ?>
              <option value="<?= htmlspecialchars($c) ?>"><?= htmlspecialchars($l) ?></option>
            <?php endforeach; ?>
          </select>
          <input type="text" name="client_name" class="form-control mb-1" placeholder="<?= htmlspecialchars(t('client_name')) ?>">
          <input type="text" name="organization" class="form-control mb-1" placeholder="Organisation / famille (si applicable)">
          <input type="text" name="client_phone" class="form-control mb-1" placeholder="<?= htmlspecialchars(t('client_phone')) ?>">
          <textarea name="client_address" class="form-control mb-1" rows="2" placeholder="<?= htmlspecialchars(t('client_address')) ?>"></textarea>
          <label class="form-label mt-1"><?= htmlspecialchars(t('delivery_datetime')) ?></label>
          <input type="datetime-local" name="delivery_date" class="form-control">
        </div>

        <hr>
        <label class="form-label fw-bold mb-2"><?= htmlspecialchars(t('menus')) ?></label>
        <div class="mb-2">
        <?php
          $menuGridMode = 'order';
          $menuGridShowTable = false;
          require __DIR__ . '/../includes/menu_grid.php';
        ?>
        </div>
        <?php if (count($menus) === 0): ?>
          <div class="alert alert-secondary small mt-2">Aucun plat disponible.</div>
        <?php endif; ?>

        <button type="submit" class="btn btn-danger w-100 mt-3 btn-lg"><?= htmlspecialchars(t('send_to_checker')) ?></button>
      </form>
    </div>
  </div>
</div>

  <!-- Liste des commandes en bas -->
  <div class="mt-2 mb-4">
    <div class="card p-3 glass-card border border-gold-500/20">
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-2">
        <h5 class="mb-0"><?= htmlspecialchars(t('order_list')) ?></h5>
        <form method="get" class="d-flex gap-1">
          <input type="search" name="q" class="form-control form-control-sm" style="min-width:160px" placeholder="🔍 #, client, table..." value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
          <button class="btn btn-sm btn-outline-danger">OK</button>
        </form>
      </div>
      <div class="table-responsive">
        <table class="table table-sm table-hover align-middle">
          <thead>
            <tr>
              <th>#</th>
              <th><?= htmlspecialchars(t('time')) ?></th>
              <th><?= htmlspecialchars(t('type')) ?></th>
              <th><?= htmlspecialchars(t('total')) ?></th>
              <th><?= htmlspecialchars(t('status')) ?></th>
              <th><?= htmlspecialchars(t('payment')) ?></th>
              <th class="no-print"><?= htmlspecialchars(t('actions')) ?></th>
            </tr>
          </thead>
          <tbody>
            <?php if (count($orders) === 0): ?>
              <tr><td colspan="7" class="text-center text-muted"><?= htmlspecialchars(t('no_data')) ?></td></tr>
            <?php endif; ?>
            <?php foreach ($orders as $o): ?>
              <tr>
                <td><strong><?= (int) $o['id'] ?></strong></td>
                <td class="small text-nowrap"><?= date('d/m H:i', strtotime($o['created_at'])) ?></td>
                <td class="small">
                  <?php if ($o['order_type'] === 'dine_in'): ?>
                    <?= htmlspecialchars(t('dine_in')) ?> <?= htmlspecialchars($o['table_no'] ?? '-') ?>
                  <?php else: ?>
                    <?= htmlspecialchars(t('delivery')) ?>
                    <?php if (!empty($o['delivery_date'])): ?>
                      <br><span class="text-muted"><?= date('d/m H:i', strtotime($o['delivery_date'])) ?></span>
                    <?php endif; ?>
                  <?php endif; ?>
                </td>
                <td class="text-nowrap fw-semibold"><?= number_format((float) $o['total'], 0, ',', ' ') ?> Ar</td>
                <td><span class="badge bg-secondary"><?= htmlspecialchars(t($o['status'])) ?></span></td>
                <td>
                  <?php
                  $cls = 'danger';
                  if ($o['payment_status'] === 'paid') $cls = 'success';
                  elseif ($o['payment_status'] === 'partial') $cls = 'warning';
                  ?>
                  <span class="badge bg-<?= $cls ?>"><?= htmlspecialchars(t($o['payment_status'])) ?></span>
                </td>
                <td class="text-nowrap no-print">
                    <button type="button" class="btn btn-sm btn-outline-info sula-view-order"
                      data-oid="<?= (int)$o['id'] ?>"
                      data-total="<?= number_format((float)$o['total'], 0, ',', ' ') ?>"
                      data-client="<?= htmlspecialchars($o['client_name'] ?? $o['table_no'] ?? '', ENT_QUOTES) ?>"
                      data-phone="<?= htmlspecialchars($o['client_phone'] ?? '', ENT_QUOTES) ?>"
                      data-type="<?= htmlspecialchars($o['order_type'] ?? '') ?>"
                      data-address="<?= htmlspecialchars($o['client_address'] ?? '', ENT_QUOTES) ?>"
                      data-method="<?= htmlspecialchars($o['payment_method'] ?? '', ENT_QUOTES) ?>"
                      data-payer="<?= htmlspecialchars($o['payer_name'] ?? '', ENT_QUOTES) ?>"
                      data-payer-phone="<?= htmlspecialchars($o['payer_phone'] ?? '', ENT_QUOTES) ?>"
                      data-client-type="<?= htmlspecialchars(function_exists('sulaClientTypeLabel') ? sulaClientTypeLabel($o['client_type'] ?? '') : ($o['client_type'] ?? ''), ENT_QUOTES) ?>"
                    >Détails</button>
                  <?php if ($o['status'] === 'pending' && in_array($user['role'], ['checker', 'admin'], true)): ?>
                    <button type="button" class="btn btn-sm btn-success sula-open-approve"
                      data-oid="<?= (int)$o['id'] ?>"
                      data-total="<?= number_format((float)$o['total'], 0, ',', ' ') ?>"
                      data-client="<?= htmlspecialchars($o['client_name'] ?? $o['table_no'] ?? '', ENT_QUOTES) ?>"
                      data-phone="<?= htmlspecialchars($o['client_phone'] ?? '', ENT_QUOTES) ?>"
                      data-type="<?= htmlspecialchars($o['order_type'] ?? '') ?>"
                      data-address="<?= htmlspecialchars($o['client_address'] ?? '', ENT_QUOTES) ?>"
                      data-method="<?= htmlspecialchars($o['payment_method'] ?? '', ENT_QUOTES) ?>"
                      data-payer="<?= htmlspecialchars($o['payer_name'] ?? '', ENT_QUOTES) ?>"
                      data-payer-phone="<?= htmlspecialchars($o['payer_phone'] ?? '', ENT_QUOTES) ?>"
                      data-client-type="<?= htmlspecialchars(function_exists('sulaClientTypeLabel') ? sulaClientTypeLabel($o['client_type'] ?? '') : ($o['client_type'] ?? ''), ENT_QUOTES) ?>"
                    ><?= t('approve') ?></button>
                  <?php endif; ?>

                  <?php if ($o['payment_status'] !== 'paid' && in_array($user['role'], ['checker', 'accountant'], true) && $o['status'] !== 'pending'): ?>
                    <a class="btn btn-sm btn-outline-success" href="?mark_paid=<?= (int) $o['id'] ?>"><?= htmlspecialchars(t('mark_paid')) ?></a>
                  <?php endif; ?>

                  <?php if (isset($invoiceMap[$o['id']]) && in_array($user['role'], ['checker', 'accountant', 'admin'], true)): ?>
                    <a class="btn btn-sm btn-outline-primary" href="/pages/invoice_pdf.php?id=<?= (int)$invoiceMap[$o['id']] ?>" target="_blank"><i class="bi bi-printer"></i></a>
                  <?php endif; ?>

                  <?php if ($user['role'] === 'server' && $o['payment_status'] === 'paid' && in_array($o['status'], ['approved', 'ready', 'preparing'], true)): ?>
                    <a class="btn btn-sm btn-primary" href="?complete=<?= (int) $o['id'] ?>"><?= htmlspecialchars(t('close_order')) ?></a>
                  <?php elseif ($user['role'] === 'server' && $o['payment_status'] !== 'paid' && in_array($o['status'], ['approved', 'ready', 'preparing'], true)): ?>
                    <span class="badge bg-light text-muted border"><?= htmlspecialchars(t('not_paid')) ?></span>
                  <?php endif; ?>

                  <?php
                  // Modifier / Annuler si pas encore clôturée
                  $canRequestChange = in_array($user['role'], ['server','checker','admin'], true)
                    && !in_array($o['status'], ['completed','cancelled'], true);
                  $hasPending = isset($myPendingChangeByOrder[(int)$o['id']]);
                  if ($canRequestChange && !$hasPending):
                  ?>
                    <button type="button" class="btn btn-sm btn-outline-warning sula-req-change" data-oid="<?= (int)$o['id'] ?>" data-type="modify" title="Demander modification">✎</button>
                    <button type="button" class="btn btn-sm btn-outline-danger sula-req-change" data-oid="<?= (int)$o['id'] ?>" data-type="cancel" title="Demander annulation">✕</button>
                  <?php elseif ($hasPending): ?>
                    <span class="badge bg-warning text-dark" title="Demande en attente">⏳</span>
                  <?php endif; ?>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<script>
(function () {
  var typeSelect = document.getElementById('orderType');
  if (typeSelect) {
    typeSelect.addEventListener('change', function () {
      var isDelivery = this.value === 'delivery';
      document.getElementById('tableField').classList.toggle('d-none', isDelivery);
      document.getElementById('clientFields').classList.toggle('d-none', !isDelivery);
    });
  }
  document.querySelectorAll('.add-btn').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var id = this.getAttribute('data-id');
      var input = document.querySelector('.qty-input[data-id="' + id + '"]');
      if (input && !input.disabled) {
        var stock = parseInt(input.getAttribute('data-stock') || input.getAttribute('max') || '0', 10);
        input.value = Math.min(parseInt(input.value || '0', 10) + 1, stock);
      }
    });
  });
})();
</script>



<!-- Modal Approuver (custom, fiable) -->
<div id="sulaApproveModal" class="fixed inset-0 hidden items-center justify-center p-4" style="background:rgba(0,0,0,0.75);backdrop-filter:blur(6px);z-index:200000;pointer-events:auto">
  <div class="w-full max-w-lg rounded-2xl border border-gold-500/30 shadow-2xl" style="background:rgba(26,26,30,0.95)">
    <form method="post" action="/pages/orders.php" id="sulaApproveForm">
      <div class="p-4 border-b border-gold-500/20 flex justify-between items-center">
        <h3 class="font-serif text-lg font-bold text-gold-300"><?= t('approve_order') ?> <span id="sulaApproveOidLabel"></span></h3>
        <button type="button" id="sulaApproveClose" class="text-slate-400 hover:text-white text-xl leading-none">&times;</button>
      </div>
      <div class="p-4 space-y-3 max-h-[70vh] overflow-y-auto">
        <input type="hidden" name="approve_order" value="1">
        <input type="hidden" name="order_id" id="sulaApproveOid" value="">
        <div id="sulaApproveDetails" class="rounded-xl border border-gold-500/20 bg-onyx-900/60 p-3 text-xs space-y-1 text-slate-300">
          <p><span class="text-slate-500">Client :</span> <strong id="sulaDetClient">—</strong></p>
          <p><span class="text-slate-500">Type :</span> <span id="sulaDetClientType">—</span></p>
          <p><span class="text-slate-500">Tél :</span> <strong id="sulaDetPhone">—</strong></p>
          <p><span class="text-slate-500">Type :</span> <span id="sulaDetType">—</span></p>
          <p id="sulaDetAddressRow" class="hidden"><span class="text-slate-500">Adresse :</span> <span id="sulaDetAddress"></span></p>
          <p><span class="text-slate-500">Paiement demandé :</span> <span id="sulaDetMethod">—</span></p>
          <p><span class="text-slate-500">Envoyeur :</span> <span id="sulaDetPayer">—</span></p>
          <div id="sulaDetItems" class="mt-2 pt-2 border-t border-gold-500/10"></div>
          <div id="sulaDetProof" class="mt-2 hidden"></div>
        </div>
        <div>
          <label class="form-label text-slate-400 text-xs uppercase"><?= t('payment') ?></label>
          <select name="payment_status" class="form-select w-full" required>
            <option value="paid">Payé</option>
            <option value="partial">Partiel</option>
            <option value="not_paid">Non payé</option>
          </select>
        </div>
        <div>
          <label class="form-label text-slate-400 text-xs uppercase"><?= t('payment_method') ?></label>
          <input type="hidden" name="payment_method" id="sulaPayMethodHidden" value="cash">
          <select id="sulaPayMethod" class="form-select w-full" required>
            <option value="cash">💵 Cash / Espèces</option>
            <option value="mvola">📱 MVola — 038 24 541 74</option>
            <option value="orange_money">🟠 Orange Money</option>
            <option value="airtel_money">🔴 Airtel Money</option>
            <option value="virement">🏦 Virement bancaire</option>
            <option value="autre">Autre</option>
          </select>
          <p id="sulaPayMethodLocked" class="hidden text-xs text-emerald-400 mt-1">
            <i class="fa-solid fa-lock me-1"></i> Mode choisi par le client (livraison) — non modifiable
          </p>
          <div id="sulaPayBrands" class="flex flex-wrap gap-1.5 mt-2">
            <span class="pay-brand mvola">MVola</span>
            <span class="pay-brand orange">Orange Money</span>
            <span class="pay-brand airtel">Airtel Money</span>
            <span class="pay-brand cash">Cash</span>
            <span class="pay-brand bank">Virement</span>
          </div>
        </div>
        <div id="sulaPayerFields" class="hidden space-y-3">
          <div>
            <label class="form-label text-slate-400 text-xs uppercase"><?= t('payer_name') ?></label>
            <input type="text" name="payer_name" id="sulaPayerName" class="form-control w-full" placeholder="Nom complet">
          </div>
          <div>
            <label class="form-label text-slate-400 text-xs uppercase"><?= t('payer_phone') ?></label>
            <input type="text" name="payer_phone" id="sulaPayerPhone" class="form-control w-full" placeholder="03X XX XXX XX">
          </div>
        </div>
        <p class="text-sm text-slate-300">Total : <strong class="text-gold-400" id="sulaApproveTotal">—</strong> Ar</p>
        <p class="text-xs text-slate-500">MVola SURA : <span class="text-gold-400 font-semibold">038 24 541 74</span></p>
      </div>
      <div class="p-4 border-t border-gold-500/20 flex justify-end gap-2">
        <button type="button" id="sulaApproveCancel" class="btn btn-outline-secondary btn-sm"><?= t('cancel') ?></button>
        <button type="submit" class="btn btn-success btn-sm"><?= t('validate_approve') ?></button>
      </div>
    </form>
  </div>
</div>
<script>
(function(){
  var modal = document.getElementById('sulaApproveModal');
  var oidInput = document.getElementById('sulaApproveOid');
  var oidLabel = document.getElementById('sulaApproveOidLabel');
  var totalEl = document.getElementById('sulaApproveTotal');
  var methodSel = document.getElementById('sulaPayMethod');
  var payerFields = document.getElementById('sulaPayerFields');
  function fillDetails(btn, oid) {
    var dClient = document.getElementById('sulaDetClient');
    var dPhone = document.getElementById('sulaDetPhone');
    var dType = document.getElementById('sulaDetType');
    var dAddr = document.getElementById('sulaDetAddress');
    var dAddrRow = document.getElementById('sulaDetAddressRow');
    var dMethod = document.getElementById('sulaDetMethod');
    var dPayer = document.getElementById('sulaDetPayer');
    var dItems = document.getElementById('sulaDetItems');
    var dProof = document.getElementById('sulaDetProof');
    if (!dClient) return;
    dClient.textContent = (btn && btn.getAttribute('data-client')) || '—';
    var dCT = document.getElementById('sulaDetClientType');
    if (dCT) dCT.textContent = (btn && btn.getAttribute('data-client-type')) || '—';
    dPhone.textContent = (btn && btn.getAttribute('data-phone')) || '—';
    dType.textContent = (btn && btn.getAttribute('data-type')) || '—';
    var addr = (btn && btn.getAttribute('data-address')) || '';
    if (addr) { dAddr.textContent = addr; dAddrRow.classList.remove('hidden'); } else { dAddrRow.classList.add('hidden'); }
    dMethod.textContent = (btn && btn.getAttribute('data-method')) || '—';
    var pn = (btn && btn.getAttribute('data-payer')) || '';
    var pp = (btn && btn.getAttribute('data-payer-phone')) || '';
    dPayer.textContent = (pn || pp) ? (pn + ' · ' + pp) : '—';
    var items = (window.SURA_ORDER_ITEMS && window.SURA_ORDER_ITEMS[oid]) || [];
    if (items.length) {
      var html = '<p class="text-gold-400 font-semibold mb-1">Articles</p><ul class="mb-0 pl-3">';
      items.forEach(function(it){
        html += '<li>' + (it.quantity||1) + '× ' + (it.item_name||'') + ' — ' + Number(it.subtotal||0).toLocaleString('fr-FR') + ' Ar</li>';
      });
      html += '</ul>';
      dItems.innerHTML = html;
    } else {
      dItems.innerHTML = '<p class="text-slate-500 mb-0">Aucun détail article</p>';
    }
    var pay = (window.SURA_ORDER_PAY && window.SURA_ORDER_PAY[oid]) || null;
    if (pay && pay.proof_image) {
      dProof.classList.remove('hidden');
      dProof.innerHTML = '<p class="text-gold-400 font-semibold mb-1">Preuve de paiement</p><a href="/uploads/' + pay.proof_image + '" target="_blank"><img src="/uploads/' + pay.proof_image + '" alt="preuve" style="max-height:160px;border-radius:8px;border:1px solid rgba(212,175,55,.3)"></a><p class="text-slate-500 mt-1">Réf: ' + (pay.reference||'') + '</p>';
    } else if (pay && pay.reference) {
      dProof.classList.remove('hidden');
      dProof.innerHTML = '<p class="text-slate-400">Réf paiement: <code>' + pay.reference + '</code> · statut: ' + (pay.status||'') + '</p>';
    } else {
      dProof.classList.add('hidden');
      dProof.innerHTML = '';
    }
  }
  function openModal(oid, total, btn) {
    oidInput.value = oid;
    oidLabel.textContent = '#' + oid;
    totalEl.textContent = total;
    fillDetails(btn, oid);

    var orderType = (btn && btn.getAttribute('data-type')) || '';
    var clientMethod = (btn && btn.getAttribute('data-method')) || 'cash';
    var payerName = (btn && btn.getAttribute('data-payer')) || '';
    var payerPhone = (btn && btn.getAttribute('data-payer-phone')) || '';
    var clientName = (btn && btn.getAttribute('data-client')) || '';
    var clientPhone = (btn && btn.getAttribute('data-phone')) || '';

    var methodSel = document.getElementById('sulaPayMethod');
    var methodHidden = document.getElementById('sulaPayMethodHidden');
    var lockedMsg = document.getElementById('sulaPayMethodLocked');
    var payerFields = document.getElementById('sulaPayerFields');
    var payerNameEl = document.getElementById('sulaPayerName');
    var payerPhoneEl = document.getElementById('sulaPayerPhone');

    if (!clientMethod) clientMethod = 'cash';
    if (methodSel) {
      methodSel.value = clientMethod;
      if (methodHidden) methodHidden.value = clientMethod;
      // Livraison : mode verrouillé = choix client
      if (orderType === 'delivery' && clientMethod) {
        methodSel.disabled = true;
        methodSel.classList.add('opacity-70');
        if (lockedMsg) lockedMsg.classList.remove('hidden');
      } else {
        methodSel.disabled = false;
        methodSel.classList.remove('opacity-70');
        if (lockedMsg) lockedMsg.classList.add('hidden');
      }
    }
    if (payerFields) {
      payerFields.classList.toggle('hidden', clientMethod === 'cash');
    }
    if (payerNameEl) {
      payerNameEl.value = payerName || (clientMethod !== 'cash' ? clientName : '');
      if (orderType === 'delivery' && clientMethod !== 'cash') payerNameEl.readOnly = true;
      else payerNameEl.readOnly = false;
    }
    if (payerPhoneEl) {
      payerPhoneEl.value = payerPhone || (clientMethod !== 'cash' ? clientPhone : '');
      if (orderType === 'delivery' && clientMethod !== 'cash') payerPhoneEl.readOnly = true;
      else payerPhoneEl.readOnly = false;
    }

    if (modal.parentElement !== document.body) document.body.appendChild(modal);
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    modal.style.display = 'flex';
    modal.style.pointerEvents = 'auto';
  }
  function closeModal() {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    modal.style.display = 'none';
  }
  document.querySelectorAll('.sula-open-approve').forEach(function(btn){
    btn.addEventListener('click', function(){
      openModal(btn.getAttribute('data-oid'), btn.getAttribute('data-total') || '—', btn);
    });
  });
  document.querySelectorAll('.sula-view-order').forEach(function(btn){
    btn.addEventListener('click', function(){
      openModal(btn.getAttribute('data-oid'), '—', btn);
      // Mode lecture seule: on peut laisser le formulaire, l'utilisateur ferme sans valider
    });
  });
  document.getElementById('sulaApproveClose').addEventListener('click', closeModal);
  document.getElementById('sulaApproveCancel').addEventListener('click', closeModal);
  modal.addEventListener('click', function(e){ if (e.target === modal) closeModal(); });
  if (methodSel) {
    methodSel.addEventListener('change', function(){
      var h = document.getElementById('sulaPayMethodHidden');
      if (h) h.value = this.value;
      var pf = document.getElementById('sulaPayerFields');
      if (pf) pf.classList.toggle('hidden', this.value === 'cash');
    });
  }
  // Avant submit: s'assurer que le hidden a la bonne valeur (select disabled n'est pas posté)
  var form = document.getElementById('sulaApproveForm');
  if (form) {
    form.addEventListener('submit', function(){
      var sel = document.getElementById('sulaPayMethod');
      var h = document.getElementById('sulaPayMethodHidden');
      if (sel && h) h.value = sel.value;
    });
  }
})();
</script>




<!-- Demandes de modification / annulation en attente -->
<?php if (!empty($pendingChanges) && in_array($user['role'], ['server','checker','admin'], true)): ?>
<div class="card p-3 mt-3 border border-warning">
  <h5 class="text-warning mb-2"><i class="fa-solid fa-code-pull-request me-1"></i> Demandes en attente d'approbation mutuelle</h5>
  <div class="table-responsive">
    <table class="table table-sm align-middle mb-0">
      <thead><tr><th>#Cmd</th><th>Type</th><th>Par</th><th>Motif</th><th>Action</th></tr></thead>
      <tbody>
      <?php foreach ($pendingChanges as $pr): ?>
        <tr>
          <td><strong>#<?= (int)$pr['order_id'] ?></strong></td>
          <td><?= $pr['request_type']==='cancel' ? 'Annulation' : 'Modification' ?></td>
          <td class="small"><?= htmlspecialchars($pr['requester_name'] ?? '') ?></td>
          <td class="small"><?= htmlspecialchars($pr['reason'] ?? '—') ?></td>
          <td class="text-nowrap">
            <?php if ((int)$pr['requested_by'] !== (int)$user['id'] || $user['role']==='admin'): ?>
            <form method="post" class="d-inline">
              <input type="hidden" name="action" value="review_change">
              <input type="hidden" name="request_id" value="<?= (int)$pr['id'] ?>">
              <button name="decision" value="approve" class="btn btn-sm btn-success" onclick="return confirm('Approuver cette demande ?')">✓</button>
              <button name="decision" value="reject" class="btn btn-sm btn-outline-danger" onclick="return confirm('Refuser ?')">✗</button>
            </form>
            <?php else: ?>
              <span class="text-muted small">En attente de l'autre rôle</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- Modal demande modification / annulation -->
<div id="sulaChangeModal" class="hidden fixed inset-0 z-[9999] items-center justify-center bg-black/60" style="display:none">
  <form method="post" class="glass-card rounded-2xl border border-gold-500/30 w-full max-w-md mx-4 shadow-2xl" style="background:#121215">
    <input type="hidden" name="action" value="request_change">
    <input type="hidden" name="order_id" id="sulaChangeOid" value="">
    <input type="hidden" name="request_type" id="sulaChangeType" value="cancel">
    <div class="p-4 border-b border-gold-500/20 flex justify-between items-center">
      <h5 class="font-serif text-gold-300 mb-0" id="sulaChangeTitle">Demande</h5>
      <button type="button" id="sulaChangeClose" class="text-slate-400 hover:text-white">&times;</button>
    </div>
    <div class="p-4 space-y-3">
      <p class="text-xs text-slate-400">La demande doit être approuvée par l'autre rôle (Serveur ↔ Checker).</p>
      <div>
        <label class="form-label text-slate-400 text-xs uppercase">Motif *</label>
        <textarea name="reason" class="form-control" rows="2" required placeholder="Pourquoi modifier / annuler ?"></textarea>
      </div>
      <div id="sulaChangeModifyFields" class="d-none space-y-2">
        <div>
          <label class="form-label text-slate-400 text-xs">Nouvelle table</label>
          <input type="text" name="new_table_no" class="form-control" placeholder="ex: T5">
        </div>
        <div>
          <label class="form-label text-slate-400 text-xs">Nom client</label>
          <input type="text" name="new_client_name" class="form-control">
        </div>
        <div>
          <label class="form-label text-slate-400 text-xs">Téléphone</label>
          <input type="text" name="new_client_phone" class="form-control">
        </div>
        <div>
          <label class="form-label text-slate-400 text-xs">Notes</label>
          <input type="text" name="new_notes" class="form-control">
        </div>
      </div>
    </div>
    <div class="p-4 border-t border-gold-500/20 flex justify-end gap-2">
      <button type="button" id="sulaChangeCancelBtn" class="btn btn-outline-secondary btn-sm">Fermer</button>
      <button type="submit" class="btn btn-warning btn-sm">Envoyer la demande</button>
    </div>
  </form>
</div>
<script>
(function(){
  var modal = document.getElementById('sulaChangeModal');
  if (!modal) return;
  function openChange(oid, type) {
    document.getElementById('sulaChangeOid').value = oid;
    document.getElementById('sulaChangeType').value = type;
    document.getElementById('sulaChangeTitle').textContent = type === 'cancel' ? ('Annuler commande #' + oid) : ('Modifier commande #' + oid);
    document.getElementById('sulaChangeModifyFields').classList.toggle('d-none', type !== 'modify');
    if (modal.parentElement !== document.body) document.body.appendChild(modal);
    modal.classList.remove('hidden');
    modal.style.display = 'flex';
  }
  function closeChange() {
    modal.classList.add('hidden');
    modal.style.display = 'none';
  }
  document.querySelectorAll('.sula-req-change').forEach(function(btn){
    btn.addEventListener('click', function(){
      openChange(btn.getAttribute('data-oid'), btn.getAttribute('data-type'));
    });
  });
  var c1 = document.getElementById('sulaChangeClose');
  var c2 = document.getElementById('sulaChangeCancelBtn');
  if (c1) c1.addEventListener('click', closeChange);
  if (c2) c2.addEventListener('click', closeChange);
  modal.addEventListener('click', function(e){ if (e.target === modal) closeChange(); });
})();
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>

