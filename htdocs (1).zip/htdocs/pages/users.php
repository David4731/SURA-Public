<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole(['admin']);
$pageTitle = 'Utilisateurs';
$pdo = getPDO();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    $hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $pdo->prepare('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)')
        ->execute([trim($_POST['name']), trim($_POST['email']), $hash, $_POST['role']]);
    header('Location: /pages/users.php');
    exit;
}
if (isset($_GET['toggle'])) {
    $pdo->prepare('UPDATE users SET status = 1 - status WHERE id=?')->execute([(int)$_GET['toggle']]);
    header('Location: /pages/users.php');
    exit;
}

$users = $pdo->query('SELECT id,name,email,role,status,created_at FROM users ORDER BY id')->fetchAll();
$roles = ['admin','stock_manager','checker','accountant','server','kitchen'];
require __DIR__ . '/../includes/header.php';
?>
<h2><?= t('user_list') ?></h2>
<div class="row">
  <div class="col-md-4">
    <div class="card p-3">
      <h5>Nouvel utilisateur</h5>
      <form method="post">
        <input type="hidden" name="add" value="1">
        <input type="text" name="name" class="form-control mb-2" placeholder="Nom" required>
        <input type="email" name="email" class="form-control mb-2" placeholder="Email" required>
        <input type="password" name="password" class="form-control mb-2" placeholder="Mot de passe" required>
        <select name="role" class="form-select mb-2">
          <?php foreach ($roles as $r): ?><option value="<?= $r ?>"><?= roleLabel($r) ?></option><?php endforeach; ?>
        </select>
        <button class="btn btn-danger w-100">Créer</button>
      </form>
    </div>
  </div>
  <div class="col-md-8">
    <div class="card p-3">
      <table class="table table-sm">
        <thead><tr><th><?= t('name') ?></th><th>Email</th><th>Rôle</th><th>Actif</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($users as $u): ?>
          <tr>
            <td><?= htmlspecialchars($u['name']) ?></td>
            <td><?= htmlspecialchars($u['email']) ?></td>
            <td><?= roleLabel($u['role']) ?></td>
            <td><?= $u['status'] ? 'Oui' : 'Non' ?></td>
            <td><a href="?toggle=<?= $u['id'] ?>" class="btn btn-sm btn-outline-secondary">Activer/Désactiver</a></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
