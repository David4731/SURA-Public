<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole(['accountant', 'admin']);
$pageTitle = 'Rapports';
$pdo = getPDO();
date_default_timezone_set('Indian/Antananarivo');

// Expire les réservations et événements dont la date de fin est passée.
// Le même contrôle est exécuté à chaque consultation; pour une exécution pile à minuit,
// programmer sql/expire_schedules.sql ou le script documenté dans README.
try {
    $pdo->exec("UPDATE reservations SET status='completed' WHERE reservation_date < CURDATE() AND status IN ('pending','confirmed')");
    $eventCols = $pdo->query("SHOW COLUMNS FROM events")->fetchAll(PDO::FETCH_COLUMN);
    $eventEnd = in_array('end_date', $eventCols, true) ? 'end_date' : 'event_date';
    $pdo->exec("UPDATE events SET status='done' WHERE COALESCE(NULLIF($eventEnd,''), event_date) < CURDATE() AND status IN ('planned','confirmed')");
} catch (Throwable $e) { /* les rapports restent consultables si une migration manque */ }

$period = $_GET['period'] ?? 'today';
$view = $_GET['view'] ?? '';
$selectedDate = $_GET['date'] ?? date('Y-m-d');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) $selectedDate = date('Y-m-d');
if ($view === 'day') { $dateFrom = $dateTo = $selectedDate; $period = 'today'; }
elseif ($period === 'week' || $view === 'week') { $period = 'week'; $dateFrom = date('Y-m-d', strtotime('monday this week', strtotime($selectedDate))); $dateTo = date('Y-m-d', strtotime('sunday this week', strtotime($selectedDate))); }
elseif ($period === 'month' || $view === 'month') { $period = 'month'; $dateFrom = date('Y-m-01', strtotime($selectedDate)); $dateTo = date('Y-m-t', strtotime($selectedDate)); }
elseif ($period === 'year' || $view === 'year') { $year = (int)date('Y', strtotime($selectedDate)); $dateFrom = sprintf('%04d-01-01', $year); $dateTo = sprintf('%04d-12-31', $year); }
else { $dateFrom = $dateTo = date('Y-m-d'); $period = 'today'; }

function reportRows(PDO $pdo, string $sql, array $params = []): array { try { $s=$pdo->prepare($sql); $s->execute($params); return $s->fetchAll(PDO::FETCH_ASSOC); } catch(Throwable $e) { return []; } }
function reportScalar(PDO $pdo, string $sql, array $params = []): float { try { $s=$pdo->prepare($sql); $s->execute($params); return (float)$s->fetchColumn(); } catch(Throwable $e) { return 0; } }
function ar($n): string { return number_format((float)$n, 0, ',', ' ') . ' Ar'; }

$orders = reportRows($pdo, "SELECT id, created_at, order_type, table_no, client_name, client_phone, total, status, payment_status FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND status <> 'cancelled' ORDER BY created_at DESC", [$dateFrom,$dateTo]);
$daily = reportRows($pdo, "SELECT DATE(o.created_at) AS day, COUNT(*) AS orders_count, COALESCE(SUM(o.total),0) AS sales_total, SUM(o.order_type='dine_in') AS dine_in_count, SUM(o.order_type='delivery') AS delivery_count, COALESCE((SELECT SUM(i.paid_amount) FROM invoices i WHERE DATE(i.created_at)=DATE(o.created_at) AND i.payment_status='paid'),0) AS paid_total FROM orders o WHERE DATE(o.created_at) BETWEEN ? AND ? AND o.status <> 'cancelled' GROUP BY DATE(o.created_at) ORDER BY day DESC", [$dateFrom,$dateTo]);
// Remplit aussi les jours sans commande pour les vues semaine/mois.
$dailyMap=[]; foreach($daily as $d) $dailyMap[$d['day']]=$d;
$dailyFull=[]; for($ts=strtotime($dateTo); $ts>=strtotime($dateFrom); $ts=strtotime('-1 day',$ts)) { $d=date('Y-m-d',$ts); $dailyFull[]=$dailyMap[$d] ?? ['day'=>$d,'orders_count'=>0,'sales_total'=>0,'dine_in_count'=>0,'delivery_count'=>0,'paid_total'=>0]; }
// Rapport annuel : toujours afficher les 12 mois de l'année sélectionnée, même sans activité ou à venir.
$monthlyFull=[];
if ($period === 'year') {
  $monthlyRows=reportRows($pdo, "SELECT DATE_FORMAT(o.created_at,'%Y-%m') AS month, COUNT(*) AS orders_count, COALESCE(SUM(o.total),0) AS sales_total, SUM(o.order_type='dine_in') AS dine_in_count, SUM(o.order_type='delivery') AS delivery_count FROM orders o WHERE DATE(o.created_at) BETWEEN ? AND ? AND o.status <> 'cancelled' GROUP BY DATE_FORMAT(o.created_at,'%Y-%m')", [$dateFrom,$dateTo]);
  $monthMap=[]; foreach($monthlyRows as $mr) $monthMap[$mr['month']]=$mr;
  for($m=1;$m<=12;$m++){ $key=sprintf('%04d-%02d',(int)date('Y',strtotime($dateFrom)),$m); $monthlyFull[]=$monthMap[$key] ?? ['month'=>$key,'orders_count'=>0,'sales_total'=>0,'dine_in_count'=>0,'delivery_count'=>0]; }
}

$income = reportScalar($pdo, "SELECT COALESCE(SUM(CASE WHEN payment_status='paid' AND paid_amount=0 THEN total ELSE paid_amount END),0) FROM invoices WHERE DATE(created_at) BETWEEN ? AND ? AND payment_status IN ('paid','partial')", [$dateFrom,$dateTo]);
$expenses = reportScalar($pdo, "SELECT COALESCE(SUM(amount),0) FROM expenses WHERE expense_date BETWEEN ? AND ?", [$dateFrom,$dateTo]);
$dineCount = (int)reportScalar($pdo, "SELECT COUNT(*) FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND order_type='dine_in' AND status <> 'cancelled'", [$dateFrom,$dateTo]);
$deliveryCount = (int)reportScalar($pdo, "SELECT COUNT(*) FROM orders WHERE DATE(created_at) BETWEEN ? AND ? AND order_type='delivery' AND status <> 'cancelled'", [$dateFrom,$dateTo]);
$resCount = (int)reportScalar($pdo, "SELECT COUNT(*) FROM reservations WHERE reservation_date BETWEEN ? AND ? AND status <> 'cancelled'", [$dateFrom,$dateTo]);
$eventCols = []; try {$eventCols=$pdo->query('SHOW COLUMNS FROM events')->fetchAll(PDO::FETCH_COLUMN);}catch(Throwable $e){}
$eventEndCol = in_array('end_date',$eventCols,true) ? 'end_date' : 'event_date';
$unfinishedEvents = reportRows($pdo, "SELECT * FROM events WHERE status IN ('planned','confirmed') AND COALESCE(NULLIF($eventEndCol,''),event_date) >= CURDATE() ORDER BY event_date", []);
$eventCount = count($unfinishedEvents);

if (isset($_GET['export']) && $_GET['export']==='csv') {
    header('Content-Type: text/csv; charset=utf-8'); header('Content-Disposition: attachment; filename=rapport_sula_'.$dateFrom.'_'.$dateTo.'.csv');
    $out=fopen('php://output','w'); fprintf($out, chr(0xEF).chr(0xBB).chr(0xBF));
    fputcsv($out,['Date','Commandes','Sur place','Livraison','Ventes (Ar)','Recettes encaissées (Ar)'],';');
    foreach($dailyFull as $d) fputcsv($out,[$d['day'],$d['orders_count'],$d['dine_in_count'],$d['delivery_count'],$d['sales_total'],$d['paid_total']],';');
    fclose($out); exit;
}
require __DIR__ . '/../includes/header.php';
$q = 'from='.urlencode($dateFrom).'&to='.urlencode($dateTo);
?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
 <div><h2 class="mb-1"><i class="bi bi-graph-up-arrow text-danger"></i> Rapports SURA</h2><p class="text-muted mb-0 small"><?= htmlspecialchars($dateFrom) ?> → <?= htmlspecialchars($dateTo) ?></p></div>
 <div class="d-flex flex-wrap gap-2 no-print">
  <a href="?period=today" class="btn btn-sm <?= $period==='today'?'btn-danger':'btn-outline-danger' ?>">Journalier</a>
  <a href="?period=week" class="btn btn-sm <?= $period==='week'?'btn-danger':'btn-outline-danger' ?>">Semaine</a>
  <a href="?period=month&date=<?= urlencode($selectedDate) ?>" class="btn btn-sm <?= $period==='month'?'btn-danger':'btn-outline-danger' ?>">Mois</a>
  <a href="?period=year&date=<?= urlencode($selectedDate) ?>" class="btn btn-sm <?= $period==='year'?'btn-danger':'btn-outline-danger' ?>">Année</a>
  <a href="?export=csv&period=<?= urlencode($period) ?>&date=<?= urlencode($selectedDate) ?>" class="btn btn-sm btn-outline-success">CSV</a>
  <button onclick="window.print()" class="btn btn-sm btn-outline-secondary"><i class="bi bi-printer"></i> Imprimer</button>
 </div>
</div>
<div class="row g-3 mb-4">
 <?php foreach ([['Recettes encaissées',ar($income),'success'],['Dépenses',ar($expenses),'danger'],['Commandes sur place',(string)$dineCount,'primary'],['Commandes livraison',(string)$deliveryCount,'info'],['Réservations',$resCount,'warning'],['Événements non terminés',$eventCount,'dark']] as $k): ?>
 <div class="col-6 col-lg-2"><div class="card border-0 shadow-sm h-100 p-3"><div class="text-muted small"><?= htmlspecialchars($k[0]) ?></div><div class="fw-bold fs-5 text-<?= $k[2] ?>"><?= htmlspecialchars((string)$k[1]) ?></div></div></div>
 <?php endforeach; ?>
</div>
<div class="card p-3 border-0 shadow-sm mb-4">
 <div class="d-flex flex-wrap justify-content-between align-items-center gap-2"><h5 class="mb-0"><?= $view==='day'?'Détails du jour':($period==='week'?'Détails de la semaine':($period==='month'?'Détails du mois':($period==='year'?'Détails de l’année':'Commandes du jour'))) ?></h5>
 <div class="no-print d-flex gap-2"><form method="get" class="d-flex gap-2"><input type="date" class="form-control form-control-sm" name="date" value="<?= htmlspecialchars($selectedDate) ?>"><button class="btn btn-sm btn-outline-danger">Afficher</button></form><a class="btn btn-sm btn-danger" href="/pages/report_pdf.php?type=<?= $period==='week'?'weekly':($period==='month'?'monthly':($period==='year'?'yearly':'daily')) ?>&period=<?= urlencode($period) ?>&from=<?= urlencode($dateFrom) ?>&to=<?= urlencode($dateTo) ?>">PDF</a></div></div>
 <?php if ($period==='today' || $view==='day'): ?>
 <div class="table-responsive mt-3"><table class="table table-sm table-hover"><thead><tr><th>#</th><th>Heure</th><th>Type</th><th>Client / Table</th><th>Statut</th><th>Paiement</th><th class="text-end">Total</th><th class="no-print">Détails</th></tr></thead><tbody>
 <?php foreach($orders as $o): ?><tr><td><?= (int)$o['id'] ?></td><td><?= htmlspecialchars(date('H:i',strtotime($o['created_at']))) ?></td><td><?= $o['order_type']==='dine_in'?'Sur place':'Livraison' ?></td><td><?= htmlspecialchars($o['order_type']==='dine_in'?'Table '.($o['table_no']??'—'):($o['client_name']??'—')) ?></td><td><?= htmlspecialchars($o['status']) ?></td><td><?= htmlspecialchars($o['payment_status']) ?></td><td class="text-end"><?= ar($o['total']) ?></td><td class="no-print"><a href="/pages/orders.php" class="btn btn-sm btn-outline-secondary">Ouvrir</a></td></tr><?php endforeach; ?>
 <?php if(!$orders): ?><tr><td colspan="8" class="text-center text-muted py-4">Aucune commande pour cette date.</td></tr><?php endif; ?></tbody></table></div>
 <?php elseif ($period === 'year'): ?>
 <div class="table-responsive mt-3"><table class="table table-sm table-hover"><thead><tr><th>Mois</th><th>Commandes</th><th>Sur place</th><th>Livraison</th><th class="text-end">Ventes</th><th class="no-print">Détails du mois</th></tr></thead><tbody>
 <?php foreach($monthlyFull as $m): ?><tr><td><?= htmlspecialchars(date('F Y',strtotime($m['month'].'-01'))) ?></td><td><?= (int)$m['orders_count'] ?></td><td><?= (int)$m['dine_in_count'] ?></td><td><?= (int)$m['delivery_count'] ?></td><td class="text-end"><?= ar($m['sales_total']) ?></td><td class="no-print"><a class="btn btn-sm btn-outline-danger" href="?view=month&date=<?= urlencode($m['month'].'-01') ?>">Voir détails</a> <a class="btn btn-sm btn-outline-secondary" href="/pages/report_pdf.php?type=monthly&from=<?= urlencode($m['month'].'-01') ?>&to=<?= urlencode(date('Y-m-t',strtotime($m['month'].'-01'))) ?>">PDF</a></td></tr><?php endforeach; ?>
 </tbody><tfoot><tr class="fw-bold"><td>Total annuel</td><td><?= array_sum(array_column($monthlyFull,'orders_count')) ?></td><td><?= array_sum(array_column($monthlyFull,'dine_in_count')) ?></td><td><?= array_sum(array_column($monthlyFull,'delivery_count')) ?></td><td class="text-end"><?= ar(array_sum(array_column($monthlyFull,'sales_total'))) ?></td><td></td></tr></tfoot></table></div>
 <?php else: ?>
 <div class="table-responsive mt-3"><table class="table table-sm table-hover"><thead><tr><th>Date</th><th>Commandes</th><th>Sur place</th><th>Livraison</th><th class="text-end">Ventes</th><th class="text-end">Recettes encaissées*</th><th class="no-print">Détails du jour</th></tr></thead><tbody>
 <?php foreach($dailyFull as $d): ?><tr><td><?= htmlspecialchars(date('d/m/Y',strtotime($d['day']))) ?></td><td><?= (int)$d['orders_count'] ?></td><td><?= (int)$d['dine_in_count'] ?></td><td><?= (int)$d['delivery_count'] ?></td><td class="text-end"><?= ar($d['sales_total']) ?></td><td class="text-end"><?= ar($d['paid_total']) ?></td><td class="no-print"><a class="btn btn-sm btn-outline-danger" href="?view=day&date=<?= urlencode($d['day']) ?>">Voir détails</a> <a class="btn btn-sm btn-outline-secondary" href="/pages/report_pdf.php?type=daily&from=<?= urlencode($d['day']) ?>&to=<?= urlencode($d['day']) ?>&period=custom">PDF</a></td></tr><?php endforeach; ?>
 </tbody><tfoot><tr class="fw-bold"><td>Total période</td><td><?= array_sum(array_column($dailyFull,'orders_count')) ?></td><td><?= array_sum(array_column($dailyFull,'dine_in_count')) ?></td><td><?= array_sum(array_column($dailyFull,'delivery_count')) ?></td><td class="text-end"><?= ar(array_sum(array_column($dailyFull,'sales_total'))) ?></td><td class="text-end"><?= ar(array_sum(array_column($dailyFull,'paid_total'))) ?></td><td></td></tr></tfoot></table></div><p class="small text-muted mb-0">*Les recettes encaissées sont calculées à partir des factures payées, regroupées par date de création de facture.</p>
 <?php endif; ?>
</div>
<div class="card p-3 border-0 shadow-sm mb-4"><h5>Rapport complet CEO</h5><p class="text-muted small">Synthèse uniquement : recettes entrantes/sortantes, commandes sur place/livraison, réservations et événements non terminés.</p><div class="d-flex flex-wrap gap-2 no-print"><a class="btn btn-warning" href="/pages/report_pdf.php?type=full&from=<?= urlencode($dateFrom) ?>&to=<?= urlencode($dateTo) ?>&period=<?= urlencode($period) ?>"><i class="bi bi-file-pdf"></i> Exporter le rapport CEO en PDF</a><button class="btn btn-outline-secondary" onclick="window.print()"><i class="bi bi-printer"></i> Imprimer</button></div>
 <div class="table-responsive mt-3"><table class="table table-sm"><tbody><tr><th>Recettes entrantes</th><td><?= ar($income) ?></td></tr><tr><th>Recettes sortantes (dépenses)</th><td><?= ar($expenses) ?></td></tr><tr><th>Commandes sur place</th><td><?= $dineCount ?></td></tr><tr><th>Commandes livraison</th><td><?= $deliveryCount ?></td></tr><tr><th>Réservations</th><td><?= $resCount ?></td></tr><tr><th>Événements non terminés</th><td><?= $eventCount ?></td></tr></tbody></table>
 <?php if($unfinishedEvents): ?><h6>Événements à venir / en cours</h6><table class="table table-sm"><thead><tr><th>Événement</th><th>Date début</th><th>Date fin</th><th>Statut</th></tr></thead><tbody><?php foreach($unfinishedEvents as $ev): ?><tr><td><?= htmlspecialchars($ev['title']) ?></td><td><?= htmlspecialchars($ev['event_date']) ?></td><td><?= htmlspecialchars($ev['end_date']??$ev['event_date']) ?></td><td><?= htmlspecialchars($ev['status']) ?></td></tr><?php endforeach; ?></tbody></table><?php endif; ?></div>
</div>
<style>@media print {.no-print, nav, .sidebar, header, footer {display:none!important}.card{break-inside:avoid;box-shadow:none!important}.container,.container-fluid{width:100%!important;max-width:none!important}}</style>
<?php require __DIR__ . '/../includes/footer.php'; ?>
