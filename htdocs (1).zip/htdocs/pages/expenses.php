<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireRole(['accountant','admin']);
$pageTitle = 'Dépenses';
$pdo = getPDO();
$user = currentUser();
$msg = '';

// Ensure table exists
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS expenses (
      id INT AUTO_INCREMENT PRIMARY KEY,
      title VARCHAR(200) NOT NULL,
      amount DECIMAL(12,2) NOT NULL DEFAULT 0,
      category ENUM('achat_stock','salaires','loyer','utilities','autre') NOT NULL DEFAULT 'autre',
      expense_date DATE NOT NULL,
      notes TEXT NULL,
      created_by INT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Exception $e) {}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add'])) {
    try {
        $pdo->prepare('INSERT INTO expenses (title, amount, category, expense_date, notes, created_by) VALUES (?,?,?,?,?,?)')
            ->execute([
                trim($_POST['title']),
                (float)$_POST['amount'],
                $_POST['category'],
                $_POST['expense_date'],
                trim($_POST['notes'] ?? ''),
                $user['id']
            ]);
        $msg = 'Dépense enregistrée.';
    } catch (Exception $e) {
        $msg = 'Erreur: ' . $e->getMessage();
    }
}
if (isset($_GET['delete'])) {
    $pdo->prepare('DELETE FROM expenses WHERE id=?')->execute([(int)$_GET['delete']]);
    header('Location: /pages/expenses.php');
    exit;
}

$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');
$list = $pdo->prepare('SELECT * FROM expenses WHERE expense_date BETWEEN ? AND ? ORDER BY expense_date DESC');
$list->execute([$from, $to]);
$list = $list->fetchAll();
$total = array_sum(array_column($list, 'amount'));
$cats = ['achat_stock'=>'Achat stock','salaires'=>'Salaires','loyer'=>'Loyer','utilities'=>'Charges','autre'=>'Autre'];

require __DIR__ . '/../includes/header.php';
?>
<div class="d-flex flex-wrap justify-content-between align-items-center mb-3">
  <h2 class="mb-0"><i class="bi bi-wallet2 text-danger"></i> Dépenses</h2>
<div class="mb-3 no-print">
  <a href="/pages/report_pdf.php?type=expenses&period=month" class="btn btn-danger btn-sm"><i class="bi bi-file-earmark-pdf"></i> PDF Depenses</a>
</div>
</div>
<?php if ($msg): ?><div class="alert alert-info"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

<div class="row">
  <div class="col-md-4 mb-3">
    <div class="card p-3 border-0 shadow-sm">
      <h5>Nouvelle dépense</h5>
      <form method="post">
        <input type="hidden" name="add" value="1">
        <input type="text" name="title" class="form-control mb-2" placeholder="Libellé" required>
        <input type="number" name="amount" class="form-control mb-2" placeholder="Montant (Ar)" step="100" required>
        <select name="category" class="form-select mb-2">
          <?php foreach ($cats as $k=>$v): ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach; ?>
        </select>
        <input type="date" name="expense_date" class="form-control mb-2" value="<?= date('Y-m-d') ?>" required>
        <textarea name="notes" class="form-control mb-2" placeholder="Notes" rows="2"></textarea>
        <button class="btn btn-danger w-100"><?= t('save') ?></button>
      </form>
    </div>
  </div>
  <div class="col-md-8">
    <div class="card p-3 border-0 shadow-sm">
      <div class="d-flex justify-content-between mb-2">
        <h5 class="mb-0">Liste</h5>
        <strong class="text-danger"><?= number_format($total, 0, ',', ' ') ?> Ar</strong>
      </div>
      <form class="row g-2 mb-3" method="get">
        <div class="col-auto"><input type="date" name="from" class="form-control form-control-sm" value="<?= htmlspecialchars($from) ?>"></div>
        <div class="col-auto"><input type="date" name="to" class="form-control form-control-sm" value="<?= htmlspecialchars($to) ?>"></div>
        <div class="col-auto"><button class="btn btn-sm btn-outline-danger">Filtrer</button></div>
      </form>
      <table class="table table-sm">
        <thead><tr><th><?= t('date') ?></th><th>Libellé</th><th><?= t('category') ?></th><th>Montant</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($list as $e): ?>
          <tr>
            <td><?= htmlspecialchars($e['expense_date']) ?></td>
            <td><?= htmlspecialchars($e['title']) ?></td>
            <td class="small"><?= $cats[$e['category']] ?? $e['category'] ?></td>
            <td><?= number_format((float)$e['amount'],0,',',' ') ?> Ar</td>
            <td><a href="?delete=<?= (int)$e['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Supprimer ?')">×</a></td>
          </tr>
        <?php endforeach; ?>
        <?php if (!$list): ?><tr><td colspan="5" class="text-muted text-center">Aucune dépense</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php require __DIR__ . '/../includes/footer.php'; ?>
