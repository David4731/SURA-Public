<?php
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
requireLogin();
$pageTitle = t('dashboard');
$pdo = getPDO();
$user = currentUser();

$stats = [
    'orders_today' => 0,
    'pending' => 0,
    'revenue_today' => 0,
    'reservations' => 0,
    'low_stock' => 0,
];
$menuPreview = [];
try {
    $stats['orders_today'] = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE DATE(created_at)=CURDATE()")->fetchColumn();
    $stats['pending'] = (int)$pdo->query("SELECT COUNT(*) FROM orders WHERE status='pending'")->fetchColumn();
    $stats['revenue_today'] = (float)$pdo->query("SELECT COALESCE(SUM(total),0) FROM invoices WHERE DATE(created_at)=CURDATE() AND payment_status='paid'")->fetchColumn();
    $stats['reservations'] = (int)$pdo->query("SELECT COUNT(*) FROM reservations WHERE reservation_date >= CURDATE() AND status IN ('pending','confirmed')")->fetchColumn();
    try {
        $stats['low_stock'] = (int)$pdo->query("SELECT COUNT(*) FROM menus WHERE stock <= stock_min AND available=1")->fetchColumn();
    } catch (Exception $e) {
        $stats['low_stock'] = (int)$pdo->query("SELECT COUNT(*) FROM menus WHERE stock <= 5 AND available=1")->fetchColumn();
    }
    $menuPreview = $pdo->query("SELECT name, category, price, stock FROM menus WHERE available=1 ORDER BY stock ASC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {}

require __DIR__ . '/../includes/header.php';
?>

<!-- DASHBOARD HEADER -->
<div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
  <div>
    <p class="text-[11px] uppercase tracking-[0.2em] text-gold-500/80 font-semibold mb-1"><?= t('ops_center') ?></p>
    <h2 class="font-serif text-2xl md:text-3xl font-bold text-slate-100"><?= t('overview') ?></h2>
    <p class="text-slate-400 text-sm mt-1"><?= t('overview_sub') ?></p>
  </div>
  <div class="flex items-center space-x-3">
    <?php if (in_array($user['role'], ['server','checker','admin'])): ?>
    <a href="/pages/orders.php" class="bg-gradient-to-r from-gold-600 to-gold-400 text-onyx-950 font-bold px-4 py-2.5 rounded-xl hover:brightness-110 transition-all flex items-center space-x-2 shadow-lg shadow-gold-500/10 text-sm">
      <i class="fa-solid fa-plus"></i>
      <span><?= t('new_order') ?></span>
    </a>
    <?php endif; ?>
  </div>
</div>

<!-- KPI Cards (cliquables → détails) -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
  <a href="/pages/reports.php" class="glass-card p-5 rounded-2xl border-l-4 border-l-gold-500 block hover:border-gold-400/60 hover:bg-gold-500/5 transition-all no-underline group">
    <div class="flex justify-between items-start">
      <div>
        <p class="text-xs uppercase tracking-wider text-slate-400"><?= t('revenue_label') ?></p>
        <h3 class="text-2xl font-bold text-slate-100 mt-1 group-hover:text-gold-300 transition-colors"><?= number_format($stats['revenue_today'], 0, ',', ' ') ?> Ar</h3>
      </div>
      <div class="p-3 bg-gold-500/10 text-gold-400 rounded-xl group-hover:bg-gold-500/20">
        <i class="fa-solid fa-coins text-xl"></i>
      </div>
    </div>
    <p class="text-xs text-emerald-400 mt-3 flex items-center"><i class="fa-solid fa-arrow-trend-up mr-1"></i> <?= $stats['orders_today'] ?> <?= t('orders_today_count') ?> · <span class="text-gold-400 ml-1">Voir →</span></p>
  </a>

  <a href="/pages/menus.php?filter=low_stock" class="glass-card p-5 rounded-2xl border-l-4 border-l-amber-500 block hover:border-amber-400/60 hover:bg-amber-500/5 transition-all no-underline group">
    <div class="flex justify-between items-start">
      <div>
        <p class="text-xs uppercase tracking-wider text-slate-400"><?= t('stock_alerts') ?></p>
        <h3 class="text-2xl font-bold text-amber-400 mt-1"><?= $stats['low_stock'] ?> Plat(s)</h3>
      </div>
      <div class="p-3 bg-amber-500/10 text-amber-400 rounded-xl group-hover:bg-amber-500/20">
        <i class="fa-solid fa-boxes-stacked text-xl"></i>
      </div>
    </div>
    <p class="text-xs text-amber-300 mt-3"><?= t('adjust_stock') ?> →</p>
  </a>

  <a href="/pages/reservations.php" class="glass-card p-5 rounded-2xl border-l-4 border-l-sky-500 block hover:border-sky-400/60 hover:bg-sky-500/5 transition-all no-underline group">
    <div class="flex justify-between items-start">
      <div>
        <p class="text-xs uppercase tracking-wider text-slate-400"><?= t('reservations_label') ?></p>
        <h3 class="text-2xl font-bold text-slate-100 mt-1 group-hover:text-sky-300 transition-colors"><?= $stats['reservations'] ?></h3>
      </div>
      <div class="p-3 bg-sky-500/10 text-sky-400 rounded-xl group-hover:bg-sky-500/20">
        <i class="fa-solid fa-wine-glass text-xl"></i>
      </div>
    </div>
    <p class="text-xs text-slate-400 mt-3"><?= t('upcoming_confirmed') ?> · <span class="text-sky-400">Voir →</span></p>
  </a>

  <a href="/pages/orders.php?status=pending" class="glass-card p-5 rounded-2xl border-l-4 border-l-purple-500 block hover:border-purple-400/60 hover:bg-purple-500/5 transition-all no-underline group">
    <div class="flex justify-between items-start">
      <div>
        <p class="text-xs uppercase tracking-wider text-slate-400"><?= t('pending_orders_label') ?></p>
        <h3 class="text-2xl font-bold text-slate-100 mt-1 group-hover:text-purple-300 transition-colors"><?= $stats['pending'] ?></h3>
      </div>
      <div class="p-3 bg-purple-500/10 text-purple-400 rounded-xl group-hover:bg-purple-500/20">
        <i class="fa-solid fa-hourglass-half text-xl"></i>
      </div>
    </div>
    <p class="text-xs text-purple-300 mt-3"><?= t('view_orders') ?> →</p>
  </a>
</div>

<!-- Quick Stock & Activity -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
  <!-- Menu Preview -->
  <div class="glass-card p-6 rounded-2xl lg:col-span-2 space-y-4">
    <div class="flex justify-between items-center pb-3 border-b border-gold-500/15">
      <h3 class="font-serif text-lg font-bold text-gold-300"><?= t('menu_status') ?></h3>
      <?php if (in_array($user['role'], ['stock_manager','admin'])): ?>
        <a href="/pages/menus.php" class="text-xs text-gold-400 hover:underline"><?= t('manage_menu') ?></a>
      <?php endif; ?>
    </div>
    <div class="overflow-x-auto">
      <table class="w-full text-left text-sm">
        <thead class="text-xs uppercase text-slate-400 border-b border-onyx-800">
          <tr>
            <th class="pb-3"><?= t('dish') ?></th>
            <th class="pb-3"><?= t('category') ?></th>
            <th class="pb-3"><?= t('price') ?></th>
            <th class="pb-3"><?= t('stock_qty') ?></th>
            <th class="pb-3"><?= t('state') ?></th>
          </tr>
        </thead>
        <tbody class="divide-y divide-onyx-800/50">
          <?php if (empty($menuPreview)): ?>
            <tr><td colspan="5" class="py-4 text-slate-500 text-center"><?= t('no_dishes') ?></td></tr>
          <?php else: ?>
            <?php foreach ($menuPreview as $item):
              $isLow = (int)$item['stock'] <= 5;
            ?>
            <tr>
              <td class="py-3 font-semibold text-slate-200"><?= htmlspecialchars($item['name']) ?></td>
              <td class="py-3 text-slate-400"><?= htmlspecialchars($item['category'] ?? '—') ?></td>
              <td class="py-3 font-bold text-gold-400"><?= number_format((float)$item['price'], 0, ',', ' ') ?> Ar</td>
              <td class="py-3"><?= (int)$item['stock'] ?> <?= t('units') ?></td>
              <td class="py-3">
                <span class="px-2 py-0.5 text-[10px] rounded-full border <?= $isLow ? 'bg-red-500/20 text-red-400 border-red-500/30' : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' ?>">
                  <?= $isLow ? t('stock_alert') : t('available') ?>
                </span>
              </td>
            </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Quick Access -->
  <div class="glass-card p-6 rounded-2xl space-y-4">
    <div class="flex justify-between items-center pb-3 border-b border-gold-500/15">
      <h3 class="font-serif text-lg font-bold text-gold-300"><?= t('quick_access') ?></h3>
    </div>
    <div class="space-y-2">
      <?php if (in_array($user['role'], ['server','checker','admin'])): ?>
        <a href="/pages/orders.php" class="flex items-center space-x-3 p-3 rounded-xl bg-onyx-900/80 border border-gold-500/20 hover:border-gold-400/40 transition-all">
          <i class="fa-solid fa-plus text-gold-400"></i>
          <span class="text-sm text-slate-200"><?= t('new_order') ?></span>
        </a>
      <?php endif; ?>
      <?php if (in_array($user['role'], ['checker','admin'])): ?>
        <a href="/pages/reservations.php" class="flex items-center space-x-3 p-3 rounded-xl bg-onyx-900/80 border border-gold-500/20 hover:border-gold-400/40 transition-all">
          <i class="fa-solid fa-calendar-check text-gold-400"></i>
          <span class="text-sm text-slate-200">Réservations</span>
        </a>
      <?php endif; ?>
      <?php if (in_array($user['role'], ['stock_manager','admin'])): ?>
        <a href="/pages/menus.php" class="flex items-center space-x-3 p-3 rounded-xl bg-onyx-900/80 border border-gold-500/20 hover:border-gold-400/40 transition-all">
          <i class="fa-solid fa-utensils text-gold-400"></i>
          <span class="text-sm text-slate-200">Menu & Stocks</span>
        </a>
        <a href="/pages/stock_report.php" class="flex items-center space-x-3 p-3 rounded-xl bg-onyx-900/80 border border-gold-500/20 hover:border-gold-400/40 transition-all">
          <i class="fa-solid fa-boxes-stacked text-gold-400"></i>
          <span class="text-sm text-slate-200"><?= t('stock') ?></span>
        </a>
      <?php endif; ?>
      <?php if (in_array($user['role'], ['kitchen','admin'])): ?>
        <a href="/pages/station.php?type=kitchen" class="flex items-center space-x-3 p-3 rounded-xl bg-onyx-900/80 border border-gold-500/20 hover:border-gold-400/40 transition-all">
          <i class="fa-solid fa-fire text-gold-400"></i>
          <span class="text-sm text-slate-200"><?= t('post_kitchen') ?></span>
        </a>
      <?php endif; ?>
      <?php if (in_array($user['role'], ['accountant','admin'])): ?>
        <a href="/pages/invoices.php" class="flex items-center space-x-3 p-3 rounded-xl bg-onyx-900/80 border border-gold-500/20 hover:border-gold-400/40 transition-all">
          <i class="fa-solid fa-file-invoice text-gold-400"></i>
          <span class="text-sm text-slate-200"><?= t('invoices') ?></span>
        </a>
        <a href="/pages/reports.php" class="flex items-center space-x-3 p-3 rounded-xl bg-onyx-900/80 border border-gold-500/20 hover:border-gold-400/40 transition-all">
          <i class="fa-solid fa-chart-line text-gold-400"></i>
          <span class="text-sm text-slate-200"><?= t('reports') ?></span>
        </a>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
